# 3D Enclosure Designer

A browser-based, parametric CAD tool for designing 3D-printable electronic
enclosures. Built with Next.js 16, TypeScript, Tailwind CSS 4, and Three.js
(React Three Fiber + Drei). Geometry is generated parametrically from a set
of dimensions, cutouts, PCBs, and features; boolean operations use the
fast [three-bvh-csg](https://github.com/gkjohnson/three-bvh-csg) library.

> **Important:** This is a **design and visualization tool**, not a
> mechanical-engineering or printability-guarantee tool. All volume and
> printability numbers are heuristic estimates — always verify with your
> slicer before printing.

---

## Table of Contents

1. [Installation](#installation)
2. [Development](#development)
3. [Build](#build)
4. [Architecture](#architecture)
5. [Creating Templates](#creating-templates)
6. [Adding New Cutout Presets](#adding-new-cutout-presets)
7. [Adding New Export Formats](#adding-new-export-formats)
8. [Geometry Engine](#geometry-engine-explanation)
9. [Testing](#testing)
10. [Troubleshooting](#troubleshooting)

---

## Installation

Requirements:
- Node.js 20+ (or Bun 1.1+)
- A modern browser with WebGL 2

```bash
# Clone the repo
git clone <repo>
cd 3d-enclosure-designer

# Install with bun (preferred)
bun install

# OR install with npm
npm install
```

## Development

```bash
bun run dev     # starts Next.js dev server on http://localhost:3000
# OR
npm run dev
```

Open the preview panel (or `http://localhost:3000` if you're on the same
machine). The app loads with the **ESP32 enclosure** sample by default.

## Build

> ⚠️ In the sandbox environment we use `bun run lint` instead of
> `bun run build` (which is forbidden in this environment). For your own
> deployment, run `bun run build` (or `npm run build`) which produces a
> production `.next/standalone` server.

```bash
bun run lint         # ESLint + Next.js type-aware linting
bun run test:enclosure  # run the unit tests (Bun test runner)
```

## Architecture

The project is split into independent modules under `src/enclosure/`:

```
src/enclosure/
├── types/             — All TypeScript types and presets (single source of truth)
├── geometry/          — Geometry engine (primitives, CSG, parts)
│   ├── primitives.ts      — box, roundedBox, cylinder, slot, polygon, disk
│   ├── csg.ts             — three-bvh-csg wrapper (subtract, union, intersect)
│   ├── enclosureGeometry.ts — generateBottom, generateLid (the orchestrator)
│   ├── cutouts.ts         — buildCutoutBrush per face
│   ├── ventilation.ts     — slot/circle/honeycomb/grid vent patterns
│   ├── standoffs.ts       — PCB standoffs at hole positions
│   ├── screws.ts          — screw bosses, through holes, counterbores
│   ├── feet.ts            — rubber feet at corners
│   ├── labels.ts          — text labels via CanvasTexture
│   └── index.ts           — generateEnclosureGeometry orchestrator + stats
├── templates/         — 12 templates + 5 sample projects
│   ├── index.ts           — TEMPLATES + defaultProject
│   └── samples.ts         — SAMPLE_PROJECTS (ESP32, Pi, Arduino, Sensor, WallMount)
├── validation/        — Heuristic printability validator
│   └── validator.ts       — validate(project) → ValidationIssue[]
├── export/            — File exporters
│   ├── stl.ts             — binary + ASCII STL
│   ├── obj.ts             — OBJ + MTL
│   ├── 3mf.ts             — 3MF (ZIP + XML)
│   ├── ply.ts             — binary + ASCII PLY
│   ├── zip.ts             — multi-part ZIP
│   └── index.ts           — dispatcher + extensionFor
├── project/           — Project file (.enclosure) IO
│   └── projectFile.ts     — serialize, deserialize, validate
├── store/             — Zustand store (single source of UI state)
│   └── enclosureStore.ts
├── components/        — React UI (R3F + shadcn/ui)
│   ├── Viewer.tsx         — R3F Canvas with OrbitControls, Grid, Gizmo
│   ├── Toolbar.tsx        — top toolbar (New, Open, Save, Undo, Redo, …)
│   ├── ParameterPanel.tsx — left panel (Dimensions, Lid, Cutouts, …)
│   ├── InspectorPanel.tsx — right panel (Tree, Validate, Orientation, Stats)
│   ├── StatusBar.tsx      — bottom bar (dims, tri count, volumes)
│   ├── ViewportControls.tsx — view presets + view modes
│   ├── ExportDialog.tsx
│   └── SettingsDialog.tsx
└── utils/             — id, debounce, download, format helpers
```

The state model is a single `EnclosureProject` object (defined in
`src/enclosure/types/index.ts`) held in the Zustand store. Every UI action
mutates the project (via `commit()`-first history) which triggers geometry
regeneration in the Viewer (debounced via `setTimeout`).

### Data flow

```
User input → ParameterPanel/Toolbar → store action (commit + mutate)
                                          ↓
                                     project change
                                          ↓
                              Viewer.useEffect (debounced 60ms)
                                          ↓
                       generateEnclosureGeometry({ project })
                                          ↓
                            GeometryResult { parts, stats }
                                          ↓
                            <primitive object={mesh} /> rendered
                                          ↓
                  StatusBar / InspectorPanel show stats + validation
```

## Creating Templates

A template is a function `() => Partial<EnclosureProject>` that returns
overrides applied on top of the default project. Add a new template by
extending `src/enclosure/templates/index.ts`:

1. Pick a new `EnclosureShape` id (add it to the union in
   `src/enclosure/types/index.ts`).
2. Add a function to `TEMPLATES`:

```ts
'my-shape': () => ({
  shape: 'my-shape',
  name: 'My Custom Shape',
  dimensions: { width: 100, depth: 60, height: 30, wallThickness: 2, cornerRadius: 3, floorThickness: 2 },
  lid: { ...DEFAULT_LID, type: 'snap-fit' },
  cutouts: [ cutoutFrom('usb-c', 'back', -10, 0) ],
  ventilation: { ...DEFAULT_VENTILATION, pattern: 'honeycomb', face: 'top' },
}),
```

3. Add an entry to `TEMPLATE_LIST` for the Templates dropdown.

The store's `loadTemplate(shape)` merges the template with defaults, then
runs validation.

## Adding New Cutout Presets

Cutout presets live in `CUTOUT_PRESETS` in `src/enclosure/types/index.ts`.
Add a new preset:

```ts
{
  id: 'd-sub-9',
  name: 'D-Sub 9',
  shape: 'rectangle',
  width: 24.9,
  height: 11.1,
  diameter: 0,
  cornerRadius: 0,
},
```

The Parameter panel's "Add preset" grid will list it automatically. Cutouts
created from presets are fully editable — preset values are just defaults.

## Adding New Export Formats

Exporters live in `src/enclosure/export/`. To add a new format:

1. Create a new module `myformat.ts` with an `exportMyFormat(meshes, ...)`
   function that returns a `Blob`.
2. Register it in the dispatcher `src/enclosure/export/index.ts`:
   - Add the format id to `ExportFormat` in `src/enclosure/types/index.ts`.
   - Add a case in `exportMeshes` returning your exporter's output.
   - Add the format id to `extensionFor`.
3. Add a `<SelectItem value="myformat">` entry in
   `ExportDialog.tsx` and the Settings dialog.

Each exporter walks the mesh's BufferGeometry, applies the mesh's
`matrixWorld` to the vertices, and writes vertices/triangles in the
format's syntax. STL/OBJ/PLY/3MF implementations are all in this repo as
reference.

## Geometry Engine Explanation

### Primitives

`primitives.ts` provides centered-at-origin helpers:

- `boxGeometry(w, h, d)` — THREE.BoxGeometry (centered at origin).
- `roundedBoxGeometry(w, h, d, r, segments)` — uses three-stdlib's
  `RoundedBoxGeometry` for manifold rounded corners.
- `cylinderGeometry(r, h, segments, openEnded, axis)` — Three's
  CylinderGeometry rotated so its axis is along the chosen X/Y/Z axis.
- `slotGeometry(w, h, d, cornerRadius)` — extruded rounded-rectangle
  (a slot/pill shape).
- `polygonGeometry(points, d)` — extruded arbitrary polygon.
- `diskGeometry(r, d, segments)` — extruded filled circle.

All primitives return `THREE.BufferGeometry`. The caller translates the
geometry into world space.

### CSG (three-bvh-csg)

`csg.ts` wraps `three-bvh-csg`'s `Brush` and `Evaluator`. The evaluator
reads each brush's `matrixWorld`, so we call `updateMatrixWorld()` before
passing brushes in. The evaluator writes the result in the TARGET's local
frame; we transfer the target's matrixWorld to the returned `Mesh` so the
geometry stays positioned correctly.

Operations:
- `subtract(target, ...brushes)` — drill a hole
- `union(target, ...brushes)` — add features (bosses, snap-fit hooks)
- `intersect(target, ...brushes)` — boolean intersection

### Enclosure build (`enclosureGeometry.ts`)

`generateBottom(project)`:
1. Build outer shell (roundedBox or box, translated so floor is at z=0).
2. Subtract interior cavity (smaller box inset by wall thickness).
3. For each visible cutout on a non-top face, build a brush
   (`buildCutoutBrush`) and subtract.
4. Apply ventilation (slot/circle/honeycomb pattern brushes) by subtracting.
5. For screw-lid enclosures, add screw bosses at the four interior corners
   (using `generateScrewBoss` or `generateCountersinkBoss`).
6. If snap-fit is enabled, add cylindrical hooks on the rim (count and
   direction per `snapFit`).
7. If internal supports are enabled, add a grid of posts.
8. Render labels (CanvasTexture plate).

`generateLid(project)` varies by lid type:
- `flat-removable` / `sliding`: a thin plate on top with optional cutouts.
- `screw`: lid + counterbore holes at the screw boss positions.
- `captive-screw`: lid + countersinks (cone shape) at the screw positions.
- `snap-fit`: lid + cylindrical bumps on the underside.
- `hinged`: identical geometry to flat for now (hinge visual only).
- `none`: returns no mesh.

### Volume calculation

`meshVolume` uses the divergence theorem: for each triangle (v0, v1, v2),
add `(v0 · (v1 × v2)) / 6`. Take the absolute value at the end. The result
is accurate for manifold, watertight, consistently-wound meshes; CSG output
from three-bvh-csg is generally manifold but the volumes are labeled as
"estimates" because non-manifold edges or numerical noise may produce small
errors.

### Cutout brush placement

Cutouts are positioned relative to the face CENTER (positionX, positionY
are face-local offsets). `faceBasis(face, dims)` returns the face's center
in world coords plus two orthonormal in-plane axes `u`, `v` and the outward
normal `n`. The cutout geometry is built along its own Z axis, then rotated
so its Z aligns with `n`, then translated to `center + positionX*u + positionY*v`.

### Performance notes

- Geometry regeneration is debounced (60ms) to avoid re-runs on rapid
  parameter changes.
- BVH computation in `three-bvh-csg` is internally cached per-geometry.
- Standoffs and feet use simple primitives (no CSG) where possible.
- The Viewer reuses materials across parts via a material cache.

## Testing

Tests live in `tests/enclosure/`. Run them with:

```bash
bun run test:enclosure
# OR
bun test tests/enclosure
```

Test files:
- `validation.test.ts` — parameter checks (negative dims, thin walls, etc.)
- `geometry.test.ts` — generateEnclosureGeometry returns sensible bbox / volumes
- `cutouts.test.ts` — cutout brush placement for each face
- `pcb.test.ts` — standoffs placed at PCB hole positions
- `screws.test.ts` — boss hole < boss diameter invariant
- `lid.test.ts` — lid generation for each LidType
- `project.test.ts` — .enclosure JSON round-trip
- `stl.test.ts` — binary STL header / triangle count / ASCII content
- `undo.test.ts` — undo/redo history stacks

The test runner is **Bun's built-in `bun:test`** — no separate test framework
install is needed.

## Troubleshooting

### "Cannot find package 'three'" / require() async module error

This is a Bun strict-mode issue with `three-bvh-csg`'s UMD build. The repo
imports from `three-bvh-csg/src/index.js` (the ESM build) to avoid the CJS
bridge. If you change the import, you'll see this error in tests.

### "BVH: 'maxLeafSize' option has been deprecated"

A harmless deprecation warning from `three-mesh-bvh`. It does not affect
geometry output.

### Geometry appears at origin / position is wrong

The CSG evaluator writes the result in the target's LOCAL frame; the result
mesh carries the target's world matrix. If you set `mesh.matrixAutoUpdate =
true` after a CSG op, the position may snap back to (0,0,0). Use the result
mesh as-is, or clone its `matrixWorld` before further transforms.

### Labels don't show in exported STL

Labels use `CanvasTexture` — they're flat plates with a texture, not real
geometry. The plate IS exported (a thin box); the text is just a texture
and won't appear in the STL. (Use a different label strategy if you need
embossed text — e.g., TextGeometry with helvetiker.)

### Printability validator shows "no issues" but my print failed

The validator checks project PARAMETERS, not the actual mesh. It cannot
detect non-manifold edges or numerical CSG artifacts. Always verify with
your slicer's mesh-repair tools.

### Ventilation produces no holes

Check:
- Ventilation `visible` is true.
- The pattern is not `none`.
- The face you selected isn't fully covered by the ventilation's `borderDistance` (which insets the area).
- The slot/cell dimensions aren't larger than the available area.

### Snap-fit hooks aren't visible

The hooks are very small (1.5mm radius). Make sure the wall thickness and
enclosure height leave room for them. Use the `wireframe` view mode to
see them more clearly.

---

## License

MIT — see [LICENSE](./LICENSE).
