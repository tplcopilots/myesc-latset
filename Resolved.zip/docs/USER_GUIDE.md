# 3D Enclosure Designer — User Guide

This guide walks you through using the **3D Enclosure Designer** to design a
custom 3D-printable electronic enclosure from start to finish. It assumes you
have the app running (see the main [README](../README.md) for installation).

---

## 1. The Interface at a Glance

When you open the app, you see a four-region CAD-style layout:

```
┌───────────────────────────  Toolbar  ────────────────────────────┐
│ New | Open | Save | Undo | Redo | Generate | Validate | Preview │
│ Export | Settings | Templates ▾ | Samples ▾                    │
├──────────────┬───────────────────────────────┬──────────────────┤
│              │                              │                  │
│  Parameter   │      3D Viewer (Three.js)    │   Inspector       │
│  Panel       │   ┌──┐ Front Back L R T B Iso│   (Tree | Validate│
│  (left)      │   │  │ Solid Wire Trans Sect │    | Orient | Stats)│
│              │   └──┘                        │   (right)         │
│              │                              │                  │
├──────────────┴──────────────────────────────┴──────────────────┤
│ Status bar: dims | units | objects | triangles | volume | warnings │
└────────────────────────────────────────────────────────────────┘
```

- **Toolbar (top):** file ops, undo/redo, generate, validate, preview, export,
  settings, plus Templates (12 presets) and Samples (5 full projects).
- **Parameter Panel (left):** collapsible sections for every dimension and
  feature of the enclosure (Dimensions, Lid, Screw, Cutouts, PCBs, Ventilation,
  Snap Fit, Hinge, Feet, Internal Support, Labels, Material, Settings).
- **3D Viewer (center):** real-time Three.js viewport. Mouse: orbit (drag),
  pan (right-drag), zoom (wheel). The toolbar above the viewer has standard
  view presets (Front/Back/Left/Right/Top/Bottom/Iso) and view modes
  (Solid/Wireframe/Transparent/Section) plus bounding-box and grid toggles.
- **Inspector (right):** tabbed panel showing the object tree, validation
  issues, print orientation, and live stats (volume, triangle count).
- **Status bar (bottom):** live readout of dimensions, units, object count,
  triangle count, estimated material volume, and warnings.

When the app first opens, it loads the **ESP32 DevKit Enclosure** sample so
you can see all the major features in action immediately.

---

## 2. Your First Enclosure (5 minutes)

The fastest way to learn the app is to modify the loaded ESP32 sample.

1. **Expand the Dimensions section** in the left panel (it's expanded by
   default). You'll see: Width=60, Depth=28, Height=15, Wall=1.6, Floor=1.6,
   Corner Radius=3. The 3D model updates immediately when you change any
   value (debounced by ~80ms).
2. **Change Width to 80**. Notice the model widens and the status bar dims
   update. Also notice the Validate tab in the right panel may show new
   warnings (or clear existing ones) as the model changes.
3. **Try a different template:** click the **Templates ▾** button in the
   toolbar and pick **Raspberry Pi**. The model reloads with Pi-sized
   dimensions (95×60×30) and Pi-style cutouts on the back face.
4. **Switch view modes:** in the toolbar above the 3D viewer, click
   **Wireframe**. The model is now shown as a wireframe — useful for
   inspecting internal features like standoffs and screw bosses. Click
   **Solid** to return.
5. **Try a different view preset:** click **Top** to look straight down on
   the enclosure. Click **Iso** (isometric) to return.
6. **Save the project:** press `Ctrl/Cmd+S` (or click the Save button in
   the toolbar). The browser downloads a `.enclosure` file (JSON with a
   custom extension) that you can reopen later with `Ctrl/Cmd+O`.

---

## 3. Working with Cutouts

Cutouts are holes cut through enclosure walls for connectors, buttons,
displays, fans, etc.

1. Expand the **Cutouts** section in the left panel.
2. Click **Add Cutout**. A new cutout appears in the list with default
   values (a 10×10 mm rectangle on the back face).
3. Click the new cutout to expand it. You'll see: Name, Face (front/back/
   left/right/top/bottom), Shape (rectangle/rounded-rectangle/circle/slot/
   polygon), Position X/Y, Width, Height, Diameter, Corner Radius, Rotation,
   Depth, and a Visible toggle.
4. **Use a preset:** instead of manually sizing the cutout, click the
   **Preset** dropdown and pick **USB-C**. The cutout's shape, width,
   height, and corner radius are set to standard USB-C dimensions (9.0 ×
   3.2 mm with 1.5 mm corner radius). You can still tweak the values after.
5. **Move the cutout:** change Position X to position the cutout along
   the face. Position X/Y are relative to the face's center, so 0 puts
   the cutout dead center.
6. **Remove a cutout:** click the small trash icon next to the cutout name.

Available cutout presets: USB-A, USB-C, HDMI, RJ45, DC Barrel, Toggle Switch,
Push Button, OLED 0.96", LCD 16x2, Fan 30mm, Fan 40mm, Cable Gland,
LED 3mm, LED 5mm.

---

## 4. Working with PCBs

You can add one or more PCBs to the enclosure. The app auto-generates
standoffs and bosses for each PCB's mounting holes.

1. Expand the **PCBs** section in the left panel.
2. Click **Add PCB**. A new PCB appears with default values.
3. Set Width to e.g. 85, Height to 56, Thickness to 1.6 (these are the
   Raspberry Pi 4 PCB dimensions).
4. **Add mounting holes:** under the PCB's Mounting Holes section, click
   **Add Hole**. Each hole has X, Y (in mm, relative to PCB center) and
   Diameter. For a Pi 4, add four holes at (±29, ±24.5) with diameter 2.7 mm.
5. The app auto-generates a standoff cylinder at each hole's position,
   extending from the floor up to `positionZ + standoffHeight` (default 5mm).
6. To add a second PCB, click **Add PCB** again. Each PCB has independent
   dimensions and mounting holes.

---

## 5. Ventilation

Add ventilation holes/patterns to any face.

1. Expand the **Ventilation** section.
2. Toggle Visible on.
3. Choose a Pattern: Horizontal Slots, Vertical Slots, Circular Holes,
   Honeycomb, Grid, or None.
4. Set Face (front/back/left/right/top/bottom).
5. For slot patterns, set Slot Width, Slot Height, Spacing, Rows, Columns,
   and Border Distance (the inset from the face edges).
6. For honeycomb, set Cell Radius.
7. The vents are cut into the chosen face in real time. Use the Wireframe
   view mode to see them clearly.

---

## 6. Lid Types

The lid sits on top of the enclosure. Six lid types are supported:

- **Flat removable** — a simple flat plate that drops onto the enclosure.
- **Screw** — has screw holes at the corners; screw bosses on the bottom
  half accept M2/M2.5/M3/M4/M5 screws.
- **Hinged** — has a hinge cylinder on the back; the lid swings open.
- **Snap-fit** — uses small snap hooks that flex to clip into the wall.
- **Sliding** — slides into grooves in the side walls.
- **Captive-screw** — has countersunk holes; the screws stay captive in
  the lid.

Choose a type in the **Lid** section. Set Thickness (default 2.5 mm),
Clearance (FDM-friendly default 0.2 mm — controls the gap between the lid
and walls), Screw Spacing (for screw lids), Hinge Size, and Snap-fit
Tolerance.

---

## 7. Screw System

The Screw section lets you pick from common metric screw sizes
(M2, M2.5, M3, M4, M5) or define a custom one. For each size, the
presets define: thread diameter, clearance hole diameter, head diameter,
head height, countersink angle. These are used to:
- Generate screw bosses on the floor (for screw lids)
- Drill through-holes in the lid (for screw and captive-screw lids)
- Add countersinks (for captive-screw lids)

> **Note:** The app does NOT generate true threaded holes — only clearance
> holes. Threaded inserts or self-tapping screws are required for actual
> assembly.

---

## 8. Snap-fit Lids

Snap-fit lids use small flexible hooks that clip into the wall. The Snap Fit
section lets you configure:

- **Arm Length** — how far the hook extends. Long arms may sag; the
  validator warns if > 5 mm.
- **Arm Thickness** — should be at least 1.2 mm for FDM, else the hook
  will be brittle.
- **Hook Height** — the height of the catch. At least 0.5 mm recommended.
- **Clearance** — gap between hook and wall when unclipped.
- **Flex Direction** — X or Y. Pick the direction perpendicular to the
  wall grain for best flex.
- **Count** — number of hooks per side.

---

## 9. Feet

Add rubber-like feet to the bottom of the enclosure.

- Toggle **Enabled**.
- Set Diameter (default 8 mm) and Height (default 3 mm).
- Set Count (number of feet, evenly spaced around the bottom).

---

## 10. Labels

Add text labels (e.g., "ESP32", "POWER", project name) on any face.

Labels are rendered as flat plates with a CanvasTexture showing the text.
The plate IS exported in STL/OBJ/etc.; the text texture is NOT exported
(it's only visible in the viewer). If you need embossed text in the
exported file, see the Geometry Engine section in the main README for how
to extend the labels module to use TextGeometry.

---

## 11. Material Presets

Pure visualization — the Material section lets you preview the enclosure
in PLA (blue), PETG (green), ABS (gray), ASA (yellow), or TPU (pink). These
only affect the color and roughness/metalness/opacity of the rendered
material — they do NOT affect any mechanical or print-property calculation.
Use them only to visualize how the enclosure might look in different
filaments.

---

## 12. Validation

Click the **Validate** button in the toolbar, or open the **Validate** tab
in the right inspector panel. The validator checks:

- Negative or zero dimensions
- Wall thickness too thin (< 0.8 mm) or too thick (> half the smallest dim)
- Cutouts outside face bounds
- Cutout diameter too small (< 1 mm)
- Snap-fit arms too long or hooks too short
- Screw boss hole larger than the boss
- PCB mounting hole diameter larger than the standoff
- Other sanity checks

Issues are color-coded: GREEN = OK, YELLOW = Warning, RED = Error. Click an
issue to select the affected part in the object tree.

> **Important:** The validator checks PARAMETERS, not the actual mesh. It
> cannot detect non-manifold edges or numerical CSG artifacts. Always
> verify with your slicer's mesh-repair tools.

---

## 13. Print Orientation

Open the **Orientation** tab in the right inspector. Set the print
orientation by dragging the X/Y/Z rotation sliders (in degrees). The
enclosure rotates in the viewport to match. The stats below show the
bounding box dimensions, model volume, bounding-box volume, and material
volume (in mm³ and cm³).

> Print-time and material-usage estimates are intentionally NOT shown —
> they depend on your slicer's settings (layer height, infill, speed) and
> cannot be accurately predicted from geometry alone. Use your slicer's
> built-in estimator after exporting the STL.

---

## 14. Exporting

Click the **Export** button in the toolbar (or press `Ctrl/Cmd+E`) to open
the export dialog.

- **Format:** STL (Binary, mandatory), STL (ASCII), OBJ, 3MF, or PLY.
  - STL Binary is the recommended default — works with every slicer.
  - 3MF is a ZIP archive containing a valid 3MF XML model. Use this if
    your slicer supports 3MF (PrusaSlicer, Cura, Bambu Studio).
  - OBJ is a simple text format. Useful for game engines and DCC tools.
  - PLY is a simple binary/text format. Useful for point-cloud tools.
- **Multi-part export:** if enabled, each part (bottom, lid, standoffs,
  feet) is exported as a separate file and bundled into a ZIP. File names
  follow the convention `enclosure_bottom.stl`, `enclosure_lid.stl`, etc.
- **Include lid / standoffs / feet:** toggle which parts to include in
  the export.

The downloaded file is saved to your browser's Downloads folder.

---

## 15. Project Files

A "project" is the full state of your enclosure design — dimensions, lid,
screw, all cutouts, all PCBs, ventilation, snap-fit, hinge, feet, internal
supports, labels, material, and settings.

- **New:** start from a blank custom enclosure.
- **Open (`Ctrl/Cmd+O`):** load a previously saved `.enclosure` file.
- **Save (`Ctrl/Cmd+S`):** download the current project as a `.enclosure`
  file (JSON internally, custom extension).
- **Save As:** same as Save, but you can rename the file before downloading.

The `.enclosure` file is a JSON file with a custom extension. You can
rename it to `.json` and open it in any text editor to inspect the
contents.

---

## 16. Object Tree

The right inspector's **Tree** tab shows a hierarchical view of the
enclosure:

```
Enclosure
├── Bottom
├── Lid
├── PCB
│   ├── PCB 1
│   └── PCB 2
├── Mounting
│   ├── Boss 1
│   └── Boss 2
├── Cutouts
│   ├── USB-C
│   ├── HDMI
│   └── Power
├── Ventilation
└── Feet
```

Click any item to select it. The selected part is highlighted in the 3D
viewer with an amber emissive color. The part's properties are also shown
in the inspector below the tree.

---

## 17. Keyboard Shortcuts

| Shortcut | Action |
|---|---|
| `W` | Move tool (selects/moves current object) |
| `E` | Rotate tool (rotates current object) |
| `R` | Scale tool (scales current object) |
| `F` | Focus the camera on the selected object |
| `Delete` | Delete the selected cutout/PCB |
| `Ctrl/Cmd+Z` | Undo |
| `Ctrl/Cmd+Shift+Z` | Redo |
| `Ctrl/Cmd+S` | Save project |
| `Ctrl/Cmd+O` | Open project |
| `Ctrl/Cmd+E` | Export |

---

## 18. Settings

Click the **Settings** button in the toolbar (or expand the Settings
section in the left panel) to configure:

- **Units:** mm (default), cm, or inch. Affects only display — internal
  storage is always in mm.
- **Grid size:** the size of the grid in the 3D viewer (in mm).
- **Snap size:** grid-snap increment when dragging values.
- **Default wall thickness:** applied to new enclosures.
- **Default clearance:** applied to new lids.
- **Default screw type:** applied to new screw bosses.
- **Default export format:** applied to new export sessions.
- **Theme:** dark (default) or light.

---

## 19. Sample Projects

Click the **Samples ▾** button in the toolbar to load one of five
pre-configured sample projects:

1. **ESP32 Enclosure** — 60×28×15 mm with USB-C and button cutouts. The
   default project loaded on app startup.
2. **Raspberry Pi Enclosure** — 95×60×30 mm with Pi 4 mounting holes
   and Pi cutouts (USB-C, USB-A, Ethernet, HDMI, audio).
3. **Arduino Enclosure** — 80×55×25 mm with Arduino Uno mounting holes
   and cutouts (USB-B, power jack, header slot).
4. **Sensor Box** — 40×30×15 mm small box with one cable-gland cutout.
5. **Wall Mount Box** — 80×50×30 mm with two keyhole slots on the back
   for wall mounting.

---

## 20. Tips and Tricks

- **Slow on big changes?** When you change many parameters at once, the
  viewer debounces regeneration. Wait a beat between edits if the model
  takes a moment to catch up.
- **CSG artifacts?** If you see weird triangles or z-fighting after a
  complex cutout, try slightly increasing the cutout depth (e.g., from
  2.5 mm to 3 mm) to ensure it cuts all the way through the wall.
- **Standoffs not visible?** Make sure the PCB's `visible` flag is on,
  and that `positionZ + standoffHeight` is less than the enclosure's
  interior height.
- **Want a part not in the list?** The geometry engine is modular. See
  the "Creating Templates" and "Geometry Engine Explanation" sections in
  the main [README](../README.md) for how to add new part generators.
- **Always verify with your slicer.** This app is a design tool, not a
  printability-guarantee tool. Always open the exported STL in your
  slicer (PrusaSlicer, Cura, Bambu Studio, etc.) and run its mesh-repair
  tools before printing.
