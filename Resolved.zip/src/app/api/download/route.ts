/**
 * API route: POST /api/download
 *
 * Receives a file (blob) from the client and saves it to /home/z/my-project/download/
 * so the user can access it from the project's download folder.
 *
 * Body: { filename: string, data: string (base64), mime: string }
 * Response: { success: boolean, path: string }
 */
import { NextRequest, NextResponse } from 'next/server';
import { writeFile, mkdir } from 'fs/promises';
import { join } from 'path';
import { existsSync } from 'fs';

export const runtime = 'nodejs';

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const { filename, data, mime } = body;

    if (!filename || !data) {
      return NextResponse.json({ success: false, error: 'Missing filename or data' }, { status: 400 });
    }

    // Ensure download directory exists.
    const downloadDir = join(process.cwd(), 'download');
    if (!existsSync(downloadDir)) {
      await mkdir(downloadDir, { recursive: true });
    }

    // Sanitize filename — only allow alphanumeric, dash, underscore, dot.
    const safeName = filename.replace(/[^a-zA-Z0-9_\-\.]/g, '_');
    const filePath = join(downloadDir, safeName);

    // Decode base64 data and write to file.
    const buffer = Buffer.from(data, 'base64');
    await writeFile(filePath, buffer);

    return NextResponse.json({
      success: true,
      path: `/download/${safeName}`,
      filename: safeName,
      size: buffer.length,
    });
  } catch (err) {
    console.error('Download API error:', err);
    return NextResponse.json({
      success: false,
      error: err instanceof Error ? err.message : String(err),
    }, { status: 500 });
  }
}
