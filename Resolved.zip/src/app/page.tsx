'use client';

/**
 * 3D Enclosure Designer — main application page.
 *
 * Layout:
 *   ┌────────────────── Toolbar ──────────────────┐
 *   │ Param │   3D Viewer + Viewport Controls    │ Inspector │
 *   │ Panel │                                    │   Panel   │
 *   ├────────────────── StatusBar ───────────────┴───────────┘
 *
 * Keyboard shortcuts are handled here.
 */
import React, { useEffect, useState } from 'react';
import dynamic from 'next/dynamic';
import Toolbar from '@/enclosure/components/Toolbar';
import ParameterPanel from '@/enclosure/components/ParameterPanel';
import InspectorPanel from '@/enclosure/components/InspectorPanel';
import StatusBar from '@/enclosure/components/StatusBar';
import ViewportControls from '@/enclosure/components/ViewportControls';
import ExportDialog from '@/enclosure/components/ExportDialog';
import SettingsDialog from '@/enclosure/components/SettingsDialog';
import RenderDialog from '@/enclosure/components/RenderDialog';
import SmartSafetyDeviceDialog from '@/enclosure/components/SmartSafetyDeviceDialog';
import { useEnclosureStore } from '@/enclosure/store/enclosureStore';

// Load the 3D Viewer dynamically (client-only, no SSR for Three.js).
const Viewer = dynamic(() => import('@/enclosure/components/Viewer'), {
  ssr: false,
  loading: () => (
    <div className="w-full h-full flex items-center justify-center text-slate-500">
      Loading 3D viewer...
    </div>
  ),
});

export default function Home() {
  const [exportOpen, setExportOpen] = useState(false);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [renderOpen, setRenderOpen] = useState(false);
  const [smartSafetyOpen, setSmartSafetyOpen] = useState(false);

  // ---- Keyboard shortcuts ----
  const undo = useEnclosureStore(s => s.undo);
  const redo = useEnclosureStore(s => s.redo);
  const newProject = useEnclosureStore(s => s.newProject);
  const runValidation = useEnclosureStore(s => s.runValidation);

  useEffect(() => {
    const onKey = (e: KeyboardEvent) => {
      // Ignore when typing in inputs.
      const target = e.target as HTMLElement | null;
      const tag = target?.tagName?.toLowerCase();
      if (tag === 'input' || tag === 'textarea' || target?.isContentEditable) return;

      const meta = e.ctrlKey || e.metaKey;
      const shift = e.shiftKey;
      const key = e.key.toLowerCase();
      if (meta && key === 'z') {
        e.preventDefault();
        if (shift) redo(); else undo();
      } else if (meta && key === 'y') {
        e.preventDefault();
        redo();
      } else if (meta && key === 's') {
        e.preventDefault();
        // Trigger Save button — but we can't access Toolbar internals from
        // here, so trigger via custom event.
        window.dispatchEvent(new CustomEvent('enc:save'));
      } else if (meta && key === 'o') {
        e.preventDefault();
        window.dispatchEvent(new CustomEvent('enc:open'));
      } else if (meta && key === 'e') {
        e.preventDefault();
        setExportOpen(true);
      } else if (meta && key === 'n') {
        e.preventDefault();
        newProject();
      } else if (key === 'f') {
        // Focus selected — snap camera to iso view.
        useEnclosureStore.getState().setCurrentView('iso');
      } else if (key === 'delete' || key === 'backspace') {
        // Delete selected cutout.
        const sel = useEnclosureStore.getState().selectedCutoutId;
        if (sel) useEnclosureStore.getState().removeCutout(sel);
      } else if (key === 'v') {
        runValidation();
      } else if (key === 'w' || key === 'e' || key === 'r') {
        // Move/Rotate/Scale — set viewport mode (approximation).
        // W = solid, E = wireframe, R = transparent (toggle).
        const store = useEnclosureStore.getState();
        if (key === 'w') store.setViewMode('solid');
        else if (key === 'e' && !meta) store.setViewMode('wireframe');
        else if (key === 'r') store.setViewMode(store.viewMode === 'transparent' ? 'solid' : 'transparent');
      }
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [undo, redo, newProject, runValidation]);

  return (
    <div className="h-screen w-screen flex flex-col bg-slate-950 overflow-hidden">
      <Toolbar
        onExportClick={() => setExportOpen(true)}
        onSettingsClick={() => setSettingsOpen(true)}
        onRenderClick={() => setRenderOpen(true)}
        onSmartSafetyClick={() => setSmartSafetyOpen(true)}
      />
      <div className="flex-1 flex min-h-0">
        <div className="w-80 shrink-0 hidden md:block">
          <ParameterPanel />
        </div>
        <div className="flex-1 relative min-w-0 bg-slate-950">
          <Viewer />
          <ViewportControls />
        </div>
        <div className="w-72 shrink-0 hidden lg:block">
          <InspectorPanel />
        </div>
      </div>
      <StatusBar />
      <ExportDialog open={exportOpen} onClose={() => setExportOpen(false)} />
      <SettingsDialog open={settingsOpen} onClose={() => setSettingsOpen(false)} />
      <RenderDialog open={renderOpen} onClose={() => setRenderOpen(false)} />
      <SmartSafetyDeviceDialog open={smartSafetyOpen} onClose={() => setSmartSafetyOpen(false)} />
    </div>
  );
}
