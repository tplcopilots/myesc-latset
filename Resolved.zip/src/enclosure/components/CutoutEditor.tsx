'use client';

/**
 * Cutout editor — full controls for each cutout including dimensions,
 * position, shape, face, rotation, depth.
 *
 * Clicking a cutout in the list selects it and highlights it.
 * All property changes update the 3D model immediately.
 */
import React, { useState } from 'react';
import { Plus, Trash2, ChevronDown, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { useEnclosureStore } from '../store/enclosureStore';
import { CUTOUT_PRESETS } from '../types';
import type { Cutout, CutoutFace, CutoutShape } from '../types';

function NumInput({
  label, value, step = 0.1, min, onChange, placeholder,
}: {
  label: string; value: number | null | undefined; step?: number; min?: number;
  onChange: (v: number | null) => void; placeholder?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <Label className="text-[10px] text-slate-300 w-20 shrink-0">{label}</Label>
      <Input
        type="number" value={value ?? ''} step={step} min={min}
        onChange={e => { const v = parseFloat(e.target.value); onChange(isNaN(v) ? null : v); }}
        placeholder={placeholder ?? 'auto'}
        className="h-6 text-[10px] bg-slate-900 border-slate-700 px-1"
      />
    </div>
  );
}

function CutoutCard({ cutout, index, isSelected, onSelect }: {
  cutout: Cutout; index: number; isSelected: boolean; onSelect: () => void;
}) {
  const [expanded, setExpanded] = useState(index === 0);
  const updateCutout = useEnclosureStore(s => s.updateCutout);
  const removeCutout = useEnclosureStore(s => s.removeCutout);
  const update = (partial: Partial<Cutout>) => updateCutout(cutout.id, partial);

  return (
    <div
      className={`rounded border p-1.5 cursor-pointer transition-colors ${
        isSelected
          ? 'bg-amber-900/20 border-amber-600'
          : 'bg-slate-800/50 border-slate-700/50 hover:bg-slate-800/70'
      }`}
      onClick={(e) => {
        if (e.target === e.currentTarget) { onSelect(); }
      }}
    >
      <div
        className="cutout-header flex items-center justify-between cursor-pointer"
        onClick={(e) => { e.stopPropagation(); setExpanded(!expanded); onSelect(); }}
      >
        <div className="flex items-center gap-1.5">
          {expanded ? <ChevronDown size={10} /> : <ChevronRight size={10} />}
          <Input
            value={cutout.name}
            onChange={e => update({ name: e.target.value })}
            onClick={e => e.stopPropagation()}
            className="h-5 w-24 text-[10px] bg-slate-900 border-slate-700 px-1"
          />
          <span className="text-[9px] text-slate-500 uppercase">{cutout.shape}</span>
        </div>
        <Button
          variant="ghost" size="icon"
          className="size-5 text-slate-400 hover:text-red-400"
          onClick={(e) => { e.stopPropagation(); removeCutout(cutout.id); }}
        >
          <Trash2 size={10} />
        </Button>
      </div>

      {expanded && (
        <div className="mt-2 space-y-1.5" onClick={e => e.stopPropagation()}>
          <div className="flex items-center gap-2">
            <Label className="text-[10px] text-slate-300 w-20 shrink-0">Face</Label>
            <Select value={cutout.face} onValueChange={v => update({ face: v as CutoutFace })}>
              <SelectTrigger className="h-6 text-[10px] bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="front">Front</SelectItem>
                <SelectItem value="back">Back</SelectItem>
                <SelectItem value="left">Left</SelectItem>
                <SelectItem value="right">Right</SelectItem>
                <SelectItem value="top">Top</SelectItem>
                <SelectItem value="bottom">Bottom</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-2">
            <Label className="text-[10px] text-slate-300 w-20 shrink-0">Shape</Label>
            <Select value={cutout.shape} onValueChange={v => update({ shape: v as CutoutShape })}>
              <SelectTrigger className="h-6 text-[10px] bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="rectangle">Rectangle</SelectItem>
                <SelectItem value="rounded-rectangle">Rounded Rect</SelectItem>
                <SelectItem value="circle">Circle</SelectItem>
                <SelectItem value="slot">Slot</SelectItem>
                <SelectItem value="polygon">Polygon</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="pl-2 border-l border-slate-700/50 space-y-1">
            <div className="text-[9px] text-slate-500 italic">Dimensions</div>
            <NumInput label="Width" value={cutout.width} step={0.5} onChange={v => update({ width: v ?? 0 })} />
            <NumInput label="Height" value={cutout.height} step={0.5} onChange={v => update({ height: v ?? 0 })} />
            <NumInput label="Diameter" value={cutout.diameter} step={0.5} onChange={v => update({ diameter: v ?? 0 })} />
            <NumInput label="Corner r" value={cutout.cornerRadius} step={0.5} onChange={v => update({ cornerRadius: v ?? 0 })} />
            <NumInput label="Depth" value={cutout.depth} step={0.1} onChange={v => update({ depth: v ?? 1.6 })} />
            <NumInput label="Rotation°" value={cutout.rotation} step={5} onChange={v => update({ rotation: v ?? 0 })} />
          </div>

          <div className="pl-2 border-l border-slate-700/50 space-y-1">
            <div className="text-[9px] text-slate-500 italic">Position (mm)</div>
            <NumInput label="Pos X" value={cutout.positionX} step={0.5} onChange={v => update({ positionX: v ?? 0 })} />
            <NumInput label="Pos Y" value={cutout.positionY} step={0.5} onChange={v => update({ positionY: v ?? 0 })} />
          </div>

          <div className="flex items-center gap-2 pt-1">
            <Label className="text-[10px] text-slate-300 w-20 shrink-0">Visible</Label>
            <Switch checked={cutout.visible} onCheckedChange={b => update({ visible: b })} />
          </div>
        </div>
      )}
    </div>
  );
}

export function CutoutEditor() {
  const project = useEnclosureStore(s => s.project);
  const addCutout = useEnclosureStore(s => s.addCutout);
  const selectedCutoutId = useEnclosureStore(s => s.selectedCutoutId);
  const setSelectedCutoutId = useEnclosureStore(s => s.setSelectedCutoutId);

  return (
    <div className="space-y-2">
      <div>
        <Label className="text-[10px] text-slate-400">Add preset</Label>
        <div className="grid grid-cols-2 gap-1 max-h-32 overflow-y-auto pr-1 mt-1">
          {CUTOUT_PRESETS.map(p => (
            <Button
              key={p.id}
              variant="outline"
              size="sm"
              className="h-6 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
              onClick={() =>
                addCutout({
                  name: p.name, face: 'back', shape: p.shape,
                  width: p.width, height: p.height, diameter: p.diameter,
                  cornerRadius: p.cornerRadius, preset: p.id,
                })
              }
            >
              {p.name}
            </Button>
          ))}
        </div>
      </div>
      <Button
        variant="outline"
        size="sm"
        className="w-full h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
        onClick={() => addCutout({ shape: 'rectangle' })}
      >
        <Plus size={12} className="mr-1" /> Custom Cutout
      </Button>

      <div className="space-y-1.5">
        {project.cutouts.length === 0 && (
          <div className="text-[10px] text-slate-500 italic text-center py-2">
            No cutouts yet. Add one above.
          </div>
        )}
        {project.cutouts.map((c, idx) => (
          <CutoutCard
            key={c.id}
            cutout={c}
            index={idx}
            isSelected={selectedCutoutId === c.id}
            onSelect={() => setSelectedCutoutId(c.id)}
          />
        ))}
      </div>
    </div>
  );
}
