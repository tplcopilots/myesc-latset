'use client';

/**
 * Decorations editor — lets the user add Text, Logo, or Shape decorations
 * on any face of the enclosure, with CSS-style margin positioning
 * (left / right / top / bottom), border, corner radius, rotation, etc.
 *
 * All changes update the store immediately; the geometry engine regenerates
 * the mesh (debounced) and the 3D viewer reflects the change in real time.
 */
import React, { useRef } from 'react';
import { Plus, Trash2, Type, Image as ImageIcon, Shapes } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { useEnclosureStore } from '../store/enclosureStore';
import type {
  Decoration,
  TextDecoration,
  LogoDecoration,
  ShapeDecoration,
  DecorationShapeKind,
  FontFamily,
  TextAlign,
  CutoutFace,
} from '../types';

// ---------------------------------------------------------------------------
// Helpers
// ---------------------------------------------------------------------------

function NumInput({
  label,
  value,
  step = 0.1,
  min,
  onChange,
  placeholder,
}: {
  label: string;
  value: number | null | undefined;
  step?: number;
  min?: number;
  onChange: (v: number | null) => void;
  placeholder?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <Label className="text-[10px] text-slate-300 w-20 shrink-0">{label}</Label>
      <Input
        type="number"
        value={value ?? ''}
        step={step}
        min={min}
        onChange={e => {
          const v = parseFloat(e.target.value);
          onChange(isNaN(v) ? null : v);
        }}
        placeholder={placeholder ?? 'auto'}
        className="h-6 text-[10px] bg-slate-900 border-slate-700"
      />
    </div>
  );
}

function ColorInput({
  label,
  value,
  onChange,
  allowEmpty,
}: {
  label: string;
  value: string | null;
  onChange: (v: string | null) => void;
  allowEmpty?: boolean;
}) {
  return (
    <div className="flex items-center gap-2">
      <Label className="text-[10px] text-slate-300 w-20 shrink-0">{label}</Label>
      <input
        type="color"
        value={value || '#000000'}
        onChange={e => onChange(e.target.value)}
        className="h-6 w-8 bg-slate-900 border border-slate-700 rounded cursor-pointer"
      />
      {allowEmpty && (
        <Button
          variant="ghost"
          size="sm"
          className="h-6 text-[10px] text-slate-400 px-1"
          onClick={() => onChange(null)}
        >
          clear
        </Button>
      )}
      <span className="text-[10px] text-slate-400">{value || 'none'}</span>
    </div>
  );
}

function FaceSelect({
  value,
  onChange,
}: {
  value: CutoutFace;
  onChange: (v: CutoutFace) => void;
}) {
  return (
    <Select value={value} onValueChange={v => onChange(v as CutoutFace)}>
      <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
        <SelectValue />
      </SelectTrigger>
      <SelectContent>
        <SelectItem value="front">Front</SelectItem>
        <SelectItem value="back">Back</SelectItem>
        <SelectItem value="left">Left</SelectItem>
        <SelectItem value="right">Right</SelectItem>
        <SelectItem value="top">Top</SelectItem>
        <SelectItem value="bottom">Bottom</SelectItem>
      </SelectContent>
    </Select>
  );
}

// ---------------------------------------------------------------------------
// Common fields (visible on all decoration kinds)
// ---------------------------------------------------------------------------

function CommonFields({
  dec,
  update,
}: {
  dec: Decoration;
  update: (partial: Partial<Decoration>) => void;
}) {
  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Face</Label>
        <FaceSelect
          value={dec.face}
          onChange={v => update({ face: v } as Partial<Decoration>)}
        />
      </div>

      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Position</Label>
        <Select
          value={dec.positionMode}
          onValueChange={v =>
            update({ positionMode: v as 'center' | 'margins' } as Partial<Decoration>)
          }
        >
          <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="margins">Margins (L/R/T/B)</SelectItem>
            <SelectItem value="center">Center + Offset</SelectItem>
          </SelectContent>
        </Select>
      </div>

      {dec.positionMode === 'margins' ? (
        <div className="space-y-1.5 pl-2 border-l border-slate-700/50">
          <div className="text-[10px] text-slate-400 italic">
            Margins in mm. Leave empty = auto (centered on that axis).
          </div>
          <NumInput
            label="Left"
            value={dec.marginLeft}
            step={0.5}
            onChange={v => update({ marginLeft: v } as Partial<Decoration>)}
          />
          <NumInput
            label="Right"
            value={dec.marginRight}
            step={0.5}
            onChange={v => update({ marginRight: v } as Partial<Decoration>)}
          />
          <NumInput
            label="Top"
            value={dec.marginTop}
            step={0.5}
            onChange={v => update({ marginTop: v } as Partial<Decoration>)}
          />
          <NumInput
            label="Bottom"
            value={dec.marginBottom}
            step={0.5}
            onChange={v => update({ marginBottom: v } as Partial<Decoration>)}
          />
        </div>
      ) : (
        <div className="space-y-1.5 pl-2 border-l border-slate-700/50">
          <div className="text-[10px] text-slate-400 italic">
            Center + manual offset (mm).
          </div>
          <NumInput
            label="Offset X"
            value={dec.positionOffsetX}
            step={0.5}
            onChange={v => update({ positionOffsetX: v ?? 0 } as Partial<Decoration>)}
          />
          <NumInput
            label="Offset Y"
            value={dec.positionOffsetY}
            step={0.5}
            onChange={v => update({ positionOffsetY: v ?? 0 } as Partial<Decoration>)}
          />
        </div>
      )}

      <NumInput
        label="Depth (mm)"
        value={dec.depth}
        step={0.1}
        min={0}
        onChange={v => update({ depth: v ?? 0.4 } as Partial<Decoration>)}
      />
      <NumInput
        label="Rotation°"
        value={dec.rotation}
        step={5}
        onChange={v => update({ rotation: v ?? 0 } as Partial<Decoration>)}
      />
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Visible</Label>
        <Switch
          checked={dec.visible}
          onCheckedChange={b => update({ visible: b } as Partial<Decoration>)}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Text decoration editor
// ---------------------------------------------------------------------------

function TextEditor({ dec }: { dec: TextDecoration }) {
  const updateDecoration = useEnclosureStore(s => s.updateDecoration);
  const update = (partial: Partial<TextDecoration>) =>
    updateDecoration(dec.id, partial);

  return (
    <div className="space-y-2">
      <Input
        value={dec.text}
        onChange={e => update({ text: e.target.value })}
        className="h-7 text-xs bg-slate-900 border-slate-700"
        placeholder="Text content"
      />
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Font</Label>
        <Select
          value={dec.fontFamily}
          onValueChange={v => update({ fontFamily: v as FontFamily })}
        >
          <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="sans">Sans</SelectItem>
            <SelectItem value="serif">Serif</SelectItem>
            <SelectItem value="mono">Mono</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <NumInput
        label="Size (mm)"
        value={dec.fontSize}
        step={0.5}
        min={1}
        onChange={v => update({ fontSize: v ?? 5 })}
      />
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Bold</Label>
        <Switch checked={dec.bold} onCheckedChange={b => update({ bold: b })} />
        <Label className="text-[10px] text-slate-300 ml-2">Italic</Label>
        <Switch checked={dec.italic} onCheckedChange={b => update({ italic: b })} />
      </div>
      <ColorInput
        label="Text color"
        value={dec.textColor}
        onChange={v => update({ textColor: v || '#000000' })}
      />
      <ColorInput
        label="Background"
        value={dec.backgroundColor}
        onChange={v => update({ backgroundColor: v })}
        allowEmpty
      />
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Align</Label>
        <Select
          value={dec.textAlign}
          onValueChange={v => update({ textAlign: v as TextAlign })}
        >
          <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="left">Left</SelectItem>
            <SelectItem value="center">Center</SelectItem>
            <SelectItem value="right">Right</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">AutoSize</Label>
        <Switch
          checked={dec.autoSize}
          onCheckedChange={b => update({ autoSize: b })}
        />
      </div>
      {!dec.autoSize && (
        <div className="pl-2 border-l border-slate-700/50 space-y-1.5">
          <NumInput
            label="Width"
            value={dec.width}
            step={1}
            onChange={v => update({ width: v ?? 20 })}
          />
          <NumInput
            label="Height"
            value={dec.height}
            step={1}
            onChange={v => update({ height: v ?? 8 })}
          />
        </div>
      )}
      <NumInput
        label="Pad X"
        value={dec.paddingX}
        step={0.1}
        onChange={v => update({ paddingX: v ?? 1 })}
      />
      <NumInput
        label="Pad Y"
        value={dec.paddingY}
        step={0.1}
        onChange={v => update({ paddingY: v ?? 1 })}
      />
      <div className="pt-1 border-t border-slate-700/50 space-y-1.5">
        <div className="text-[10px] text-slate-400 italic">Border / Curve</div>
        <NumInput
          label="Border w"
          value={dec.borderWidth}
          step={0.1}
          min={0}
          onChange={v => update({ borderWidth: v ?? 0 })}
        />
        <ColorInput
          label="Border c"
          value={dec.borderColor}
          onChange={v => update({ borderColor: v || '#000000' })}
        />
        <NumInput
          label="Corner r"
          value={dec.borderRadius}
          step={0.5}
          min={0}
          onChange={v => update({ borderRadius: v ?? 0 })}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Logo decoration editor
// ---------------------------------------------------------------------------

function LogoEditor({ dec }: { dec: LogoDecoration }) {
  const updateDecoration = useEnclosureStore(s => s.updateDecoration);
  const update = (partial: Partial<LogoDecoration>) =>
    updateDecoration(dec.id, partial);
  const fileRef = useRef<HTMLInputElement>(null);

  const onFile = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    const reader = new FileReader();
    reader.onload = () => {
      const src = reader.result as string;
      update({ imageSrc: src });
    };
    reader.readAsDataURL(file);
  };

  return (
    <div className="space-y-2">
      <input
        ref={fileRef}
        type="file"
        accept="image/png,image/jpeg,image/svg+xml,image/webp"
        onChange={onFile}
        className="hidden"
      />
      <div className="flex items-center gap-2">
        <Button
          variant="outline"
          size="sm"
          className="h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700 flex-1"
          onClick={() => fileRef.current?.click()}
        >
          <ImageIcon size={10} className="mr-1" /> Upload Image
        </Button>
      </div>
      {dec.imageSrc ? (
        <div className="rounded bg-slate-900 border border-slate-700 p-1 flex items-center justify-center">
          <img
            src={dec.imageSrc}
            alt="logo"
            className="max-h-16 max-w-full object-contain"
          />
        </div>
      ) : (
        <div className="text-[10px] text-slate-500 italic text-center py-2">
          No image uploaded
        </div>
      )}
      <NumInput
        label="Width (mm)"
        value={dec.width}
        step={1}
        min={1}
        onChange={v => update({ width: v ?? 20 })}
      />
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Keep ratio</Label>
        <Switch
          checked={dec.keepAspect}
          onCheckedChange={b => update({ keepAspect: b })}
        />
      </div>
      {!dec.keepAspect && (
        <NumInput
          label="Height (mm)"
          value={dec.height}
          step={1}
          min={1}
          onChange={v => update({ height: v ?? 20 })}
        />
      )}
      <NumInput
        label="Opacity"
        value={dec.opacity}
        step={0.05}
        min={0}
        max={1}
        onChange={v => update({ opacity: v ?? 1 })}
      />
      <div className="pt-1 border-t border-slate-700/50 space-y-1.5">
        <div className="text-[10px] text-slate-400 italic">Border / Curve</div>
        <NumInput
          label="Border w"
          value={dec.borderWidth}
          step={0.1}
          min={0}
          onChange={v => update({ borderWidth: v ?? 0 })}
        />
        <ColorInput
          label="Border c"
          value={dec.borderColor}
          onChange={v => update({ borderColor: v || '#000000' })}
        />
        <NumInput
          label="Corner r"
          value={dec.borderRadius}
          step={0.5}
          min={0}
          onChange={v => update({ borderRadius: v ?? 0 })}
        />
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Shape decoration editor
// ---------------------------------------------------------------------------

function ShapeEditor({ dec }: { dec: ShapeDecoration }) {
  const updateDecoration = useEnclosureStore(s => s.updateDecoration);
  const update = (partial: Partial<ShapeDecoration>) =>
    updateDecoration(dec.id, partial);

  return (
    <div className="space-y-2">
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Shape</Label>
        <Select
          value={dec.shape}
          onValueChange={v => update({ shape: v as DecorationShapeKind })}
        >
          <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="rectangle">Rectangle</SelectItem>
            <SelectItem value="rounded-rectangle">Rounded rect</SelectItem>
            <SelectItem value="circle">Circle</SelectItem>
            <SelectItem value="triangle">Triangle</SelectItem>
            <SelectItem value="hexagon">Hexagon</SelectItem>
            <SelectItem value="diamond">Diamond</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <NumInput
        label="Width (mm)"
        value={dec.width}
        step={1}
        min={1}
        onChange={v => update({ width: v ?? 10 })}
      />
      <NumInput
        label="Height (mm)"
        value={dec.height}
        step={1}
        min={1}
        onChange={v => update({ height: v ?? 10 })}
      />
      <ColorInput
        label="Fill"
        value={dec.fillColor}
        onChange={v => update({ fillColor: v || '#cccccc' })}
      />
      <NumInput
        label="Opacity"
        value={dec.opacity}
        step={0.05}
        min={0}
        max={1}
        onChange={v => update({ opacity: v ?? 1 })}
      />
      <div className="pt-1 border-t border-slate-700/50 space-y-1.5">
        <div className="text-[10px] text-slate-400 italic">Border / Curve</div>
        <NumInput
          label="Border w"
          value={dec.borderWidth}
          step={0.1}
          min={0}
          onChange={v => update({ borderWidth: v ?? 0 })}
        />
        <ColorInput
          label="Border c"
          value={dec.borderColor}
          onChange={v => update({ borderColor: v || '#000000' })}
        />
        {(dec.shape === 'rectangle' || dec.shape === 'rounded-rectangle') && (
          <NumInput
            label="Corner r"
            value={dec.borderRadius}
            step={0.5}
            min={0}
            onChange={v => update({ borderRadius: v ?? 0 })}
          />
        )}
      </div>
    </div>
  );
}

// ---------------------------------------------------------------------------
// Single decoration card
// ---------------------------------------------------------------------------

function DecorationCard({
  dec,
  index,
}: {
  dec: Decoration;
  index: number;
}) {
  const removeDecoration = useEnclosureStore(s => s.removeDecoration);
  const updateDecoration = useEnclosureStore(s => s.updateDecoration);
  const [expanded, setExpanded] = React.useState(index === 0);

  const kindIcon =
    dec.kind === 'text' ? (
      <Type size={10} />
    ) : dec.kind === 'logo' ? (
      <ImageIcon size={10} />
    ) : (
      <Shapes size={10} />
    );

  return (
    <div className="rounded bg-slate-800/50 border border-slate-700/50">
      <div className="flex items-center justify-between px-2 py-1.5 cursor-pointer hover:bg-slate-800/70" onClick={() => setExpanded(!expanded)}>
        <div className="flex items-center gap-1.5 text-[10px] text-slate-200">
          {kindIcon}
          <Input
            value={dec.name}
            onChange={e => {
              e.stopPropagation();
              updateDecoration(dec.id, { name: e.target.value });
            }}
            onClick={e => e.stopPropagation()}
            className="h-5 w-32 text-[10px] bg-slate-900 border-slate-700 px-1"
          />
          <span className="text-[9px] text-slate-500 uppercase">{dec.kind}</span>
        </div>
        <div className="flex items-center gap-1">
          <Button
            variant="ghost"
            size="icon"
            className="size-5 text-slate-400 hover:text-red-400"
            onClick={(e) => {
              e.stopPropagation();
              removeDecoration(dec.id);
            }}
          >
            <Trash2 size={10} />
          </Button>
        </div>
      </div>
      {expanded && (
        <div className="px-2 pb-2 space-y-2">
          <CommonFields
            dec={dec}
            update={(partial) => updateDecoration(dec.id, partial)}
          />
          {dec.kind === 'text' && <TextEditor dec={dec} />}
          {dec.kind === 'logo' && <LogoEditor dec={dec} />}
          {dec.kind === 'shape' && <ShapeEditor dec={dec} />}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------------------
// Main DecorationsEditor
// ---------------------------------------------------------------------------

export function DecorationsEditor() {
  const project = useEnclosureStore(s => s.project);
  const addTextDecoration = useEnclosureStore(s => s.addTextDecoration);
  const addLogoDecoration = useEnclosureStore(s => s.addLogoDecoration);
  const addShapeDecoration = useEnclosureStore(s => s.addShapeDecoration);

  return (
    <div className="space-y-2">
      <Tabs defaultValue="text">
        <TabsList className="grid grid-cols-3 h-7 bg-slate-800">
          <TabsTrigger value="text" className="text-[10px]">
            <Type size={10} className="mr-1" /> Text
          </TabsTrigger>
          <TabsTrigger value="logo" className="text-[10px]">
            <ImageIcon size={10} className="mr-1" /> Logo
          </TabsTrigger>
          <TabsTrigger value="shape" className="text-[10px]">
            <Shapes size={10} className="mr-1" /> Shape
          </TabsTrigger>
        </TabsList>
        <TabsContent value="text" className="mt-1">
          <Button
            variant="outline"
            size="sm"
            className="w-full h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
            onClick={() => addTextDecoration()}
          >
            <Plus size={10} className="mr-1" /> Add Text
          </Button>
        </TabsContent>
        <TabsContent value="logo" className="mt-1">
          <Button
            variant="outline"
            size="sm"
            className="w-full h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
            onClick={() => addLogoDecoration()}
          >
            <Plus size={10} className="mr-1" /> Add Logo
          </Button>
        </TabsContent>
        <TabsContent value="shape" className="mt-1">
          <Button
            variant="outline"
            size="sm"
            className="w-full h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
            onClick={() => addShapeDecoration()}
          >
            <Plus size={10} className="mr-1" /> Add Shape
          </Button>
        </TabsContent>
      </Tabs>

      <div className="space-y-1.5">
        {project.decorations?.length === 0 && (
          <div className="text-[10px] text-slate-500 italic text-center py-2">
            No decorations yet. Add one above.
          </div>
        )}
        {project.decorations?.map((dec, idx) => (
          <DecorationCard key={dec.id} dec={dec} index={idx} />
        ))}
      </div>
    </div>
  );
}
