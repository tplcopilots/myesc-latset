'use client';

/**
 * Download complete project source as a ZIP file.
 * The ZIP is pre-built and served from /public/3d-enclosure-designer.zip
 * — includes all source files, tests, docs, configs.
 */
import React from 'react';
import { Button } from '@/components/ui/button';
import { FolderArchive, Loader2 } from 'lucide-react';
import { downloadBlob } from '../utils/download';
import { toast } from 'sonner';

export function DownloadProjectButton() {
  const [downloading, setDownloading] = React.useState(false);

  const handleDownload = async () => {
    setDownloading(true);
    try {
      const response = await fetch('/3d-enclosure-designer.zip');
      if (!response.ok) throw new Error(`HTTP ${response.status}`);
      const blob = await response.blob();
      downloadBlob(blob, '3d-enclosure-designer.zip');
      toast.success('Project ZIP downloaded!');
    } catch (err) {
      console.error('Download failed:', err);
      toast.error(`Download failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setDownloading(false);
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      className="text-slate-300 hover:text-amber-400 text-xs"
      onClick={handleDownload}
      disabled={downloading}
      title="Download complete project source as ZIP"
    >
      {downloading ? <Loader2 size={14} className="mr-1 animate-spin" /> : <FolderArchive size={14} className="mr-1" />}
      {downloading ? 'Downloading...' : 'Download ZIP'}
    </Button>
  );
}
