'use client';

/**
 * Export dialog.
 *
 * Lets the user pick the export format, multi-part vs combined, and which
 * parts to include (lid, standoffs, feet). Clicking "Export" runs the
 * appropriate exporter and downloads the file(s).
 *
 * Also runs a mesh validation pass on the generated geometry and shows
 * open-edge / non-manifold warnings BEFORE the user exports, so they
 * understand what their slicer will see.
 */
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { AlertTriangle, CheckCircle2, Loader2 } from 'lucide-react';
import type * as THREE from 'three';
import { useEnclosureStore } from '../store/enclosureStore';
import { generateEnclosureGeometry } from '../geometry';
import {
  exportCombined,
  exportMultiPart,
  extensionFor,
} from '../export';
import type { ExportFormat, ExportOptions } from '../types';
import { downloadBlob } from '../utils/download';
import { validateMeshes, type AggregateValidationResult } from '../validation/meshValidation';
import { toast } from 'sonner';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function ExportDialog({ open, onClose }: Props) {
  const project = useEnclosureStore(s => s.project);
  const [format, setFormat] = React.useState<ExportFormat>(project.settings.defaultExportFormat);
  // Default to multi-part = true. This is the standard 3D-printing workflow:
  // each part (bottom, lid, standoffs, feet) is exported as a separate file
  // centered at the origin (Z=0), so the slicer can slice each part
  // independently on the build plate. Without this, the combined STL has
  // the lid floating at Z=25mm (above the bottom), which the slicer would
  // either auto-drop or require manual placement.
  const [multiPart, setMultiPart] = React.useState(true);
  const [includeLid, setIncludeLid] = React.useState(true);
  const [includeStandoffs, setIncludeStandoffs] = React.useState(true);
  const [includeFeet, setIncludeFeet] = React.useState(true);
  const [exporting, setExporting] = React.useState(false);
  const [validation, setValidation] = React.useState<AggregateValidationResult | null>(null);
  const [validating, setValidating] = React.useState(false);

  // Re-run validation whenever the project changes or the dialog opens.
  React.useEffect(() => {
    if (!open) return;
    setValidating(true);
    setValidation(null);
    try {
      const result = generateEnclosureGeometry({ project });
      const meshes: { name: string; mesh: THREE.Mesh }[] = [];
      for (const part of result.parts) {
        for (const m of part.meshes) {
          // Apply world matrix (each part's meshes already have their
          // matrixWorld set by the geometry engine).
          m.updateMatrixWorld(true);
          meshes.push({ name: `${part.name}`, mesh: m });
        }
      }
      const v = validateMeshes(meshes);
      setValidation(v);
    } catch (err) {
      console.error('Validation failed:', err);
    } finally {
      setValidating(false);
    }
  }, [project, open]);

  const handleExport = async () => {
    setExporting(true);
    try {
      const result = generateEnclosureGeometry({ project });
      const options: ExportOptions = {
        format,
        multiPart,
        includeLid,
        includeStandoffs,
        includeFeet,
      };
      const safe = project.name.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 48) || 'enclosure';
      if (multiPart) {
        const files = await exportMultiPart({ parts: result.parts, project, options });
        for (const file of files) {
          downloadBlob(file.blob, file.name);
        }
        toast.success(`Exported ${files.length} file(s).`);
      } else {
        const blob = await exportCombined({ parts: result.parts, project, options });
        const ext = extensionFor(format);
        downloadBlob(blob, `${safe}.${ext}`);
        toast.success(`Exported ${safe}.${ext}`);
      }
      onClose();
    } catch (err) {
      console.error(err);
      toast.error(`Export failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setExporting(false);
    }
  };

  // Build validation summary line.
  let valSummary: React.ReactNode = null;
  if (validating) {
    valSummary = (
      <div className="flex items-center gap-2 text-xs text-slate-400">
        <Loader2 size={12} className="animate-spin" />
        Validating mesh...
      </div>
    );
  } else if (validation) {
    if (validation.allClosed && validation.allManifold && validation.totalDegenerate === 0) {
      valSummary = (
        <div className="flex items-start gap-2 text-xs text-emerald-400">
          <CheckCircle2 size={14} className="mt-0.5 shrink-0" />
          <div>
            <div className="font-medium">Mesh is closed and manifold</div>
            <div className="text-slate-400">
              {validation.totalTriangles.toLocaleString()} triangles • {(validation.totalSurfaceArea / 100).toFixed(2)} cm² surface • {(validation.totalVolume / 1000).toFixed(2)} cm³ volume
            </div>
          </div>
        </div>
      );
    } else {
      valSummary = (
        <div className="flex items-start gap-2 text-xs text-amber-400">
          <AlertTriangle size={14} className="mt-0.5 shrink-0" />
          <div>
            <div className="font-medium">Mesh has issues — slicer may report warnings</div>
            <div className="text-slate-400">
              {validation.totalOpenEdges} open edge(s) • {validation.totalNonManifold} non-manifold • {validation.totalDegenerate} degenerate
            </div>
          </div>
        </div>
      );
    }
  }

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-700 text-slate-100 max-w-2xl">
        <DialogHeader>
          <DialogTitle>Export Enclosure</DialogTitle>
          <DialogDescription className="text-slate-400">
            Choose a format and parts to export. Multi-part (recommended for 3D printing)
            produces one file per part — each recentered to Z=0 so it sits on the build plate.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Label className="text-sm w-20 shrink-0">Format</Label>
            <Select value={format} onValueChange={v => setFormat(v as ExportFormat)}>
              <SelectTrigger className="bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stl-binary">STL (binary)</SelectItem>
                <SelectItem value="stl-ascii">STL (ASCII)</SelectItem>
                <SelectItem value="obj">OBJ + MTL (ZIP)</SelectItem>
                <SelectItem value="3mf">3MF</SelectItem>
                <SelectItem value="ply">PLY (binary)</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-start gap-3">
            <Label className="text-sm w-20 shrink-0 pt-1">Multi-part</Label>
            <Switch checked={multiPart} onCheckedChange={setMultiPart} className="mt-1" />
            <span className="text-[10px] text-slate-500 flex-1">
              <strong className="text-slate-300">Recommended for 3D printing.</strong>{' '}
              Each part (bottom, lid, standoffs, feet) is exported as a <em>separate</em> file
              with its bbox recentered to origin (Z=0) — so the lid sits on the build plate,
              not floating at Z=25mm above it. A ZIP containing all parts is also produced.
              <br/>
              Turn <em>off</em> for a single combined STL showing the assembled enclosure
              (lid sitting on top of bottom).
            </span>
          </div>

          <div className="space-y-2 border border-slate-700 rounded p-3 bg-slate-950/40">
            <Label className="text-xs uppercase text-slate-500">Parts to include</Label>
            <div className="flex items-center gap-3">
              <Switch checked={includeLid} onCheckedChange={setIncludeLid} id="lid" />
              <Label htmlFor="lid" className="text-sm">Lid</Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={includeStandoffs} onCheckedChange={setIncludeStandoffs} id="standoffs" />
              <Label htmlFor="standoffs" className="text-sm">Standoffs</Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={includeFeet} onCheckedChange={setIncludeFeet} id="feet" />
              <Label htmlFor="feet" className="text-sm">Feet</Label>
            </div>
          </div>

          {/* Mesh validation summary */}
          <div className="border border-slate-700 rounded p-3 bg-slate-950/40">
            <Label className="text-xs uppercase text-slate-500 mb-2 block">
              Mesh Validation (live)
            </Label>
            {valSummary}
            {validation && (validation.totalOpenEdges > 0 || validation.totalNonManifold > 0) && (
              <div className="mt-2 space-y-1 max-h-32 overflow-y-auto text-[10px] text-slate-400">
                {validation.warnings.slice(0, 5).map((w, i) => (
                  <div key={i}>• {w}</div>
                ))}
                {validation.warnings.length > 5 && (
                  <div className="italic">...and {validation.warnings.length - 5} more</div>
                )}
                <div className="mt-2 pt-2 border-t border-slate-700/50 italic text-amber-500/70">
                  Note: Some open edges are expected from CSG (cutout / ventilation) operations.
                  The exported STL skips degenerate triangles (which would cause "Surface area: NaN cm²"
                  in slicers). Most modern slicers (PrusaSlicer, Cura, Bambu Studio) can still slice
                  the model — they "improvise" around minor open edges. For a perfectly closed mesh,
                  use your slicer's mesh-repair tool after import.
                </div>
              </div>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={exporting}>
            Cancel
          </Button>
          <Button onClick={handleExport} disabled={exporting}>
            {exporting ? 'Exporting...' : 'Export'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
