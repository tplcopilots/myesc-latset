'use client';

/**
 * File Viewer — opens a separate popup window showing the contents of the
 * current project's files:
 *   - Project file (.enclosure JSON)
 *   - STL (ASCII)
 *   - STL (binary hex dump)
 *   - OBJ
 *   - 3MF (XML, unzipped from the ZIP)
 *   - PLY (ASCII)
 *
 * Also supports a DIFF mode: take a snapshot of the current file content,
 * then after modifying parameters, click "Show Diff" to see a line-by-line
 * diff between the snapshot and the current content.
 *
 * The popup window is a full HTML document written via document.write().
 * This avoids the need for a separate route in Next.js (the user can only
 * see the `/` route).
 */
import React from 'react';
import * as THREE from 'three';
import { Button } from '@/components/ui/button';
import { FileText } from 'lucide-react';
import { useEnclosureStore } from '../store/enclosureStore';
import { generateEnclosureGeometry } from '../geometry';
import { serializeProject } from '../project/projectFile';
import { exportSTL } from '../export/stl';
import { exportOBJ, meshesToObjMeshes } from '../export/obj';
import { exportPLY } from '../export/ply';
import { export3MF } from '../export/3mf';
import { repairMeshes } from '../geometry/repair';
import { computeDiff, diffToHtml, summarizeDiff } from '../utils/diff';
import JSZip from 'jszip';
import type { MaterialType } from '../types';

interface FileContent {
  name: string;
  ext: string;
  content: string;
  /** If true, the content is binary hex dump (not editable text) */
  isBinary?: boolean;
}

/**
 * Serialized mesh for the 3D preview (passed to the popup as JSON).
 * Vertices are a flat Float32Array-like number[]; indices are optional
 * (for indexed geometry). Color is the material color.
 */
interface SerializedMesh {
  name: string;
  vertices: number[];
  indices: number[] | null;
  color: string;
}

/**
 * Serialize the repaired meshes into a JSON-safe format for the popup's
 * Three.js scene. We apply each mesh's world matrix so all meshes are
 * in world space (no need for the popup to track parent transforms).
 */
function serializeMeshes(meshes: THREE.Mesh[]): SerializedMesh[] {
  return meshes.map((mesh, i) => {
    mesh.updateMatrixWorld(true);
    const geom = mesh.geometry.clone();
    geom.applyMatrix4(mesh.matrixWorld);
    const pos = geom.getAttribute('position');
    const index = geom.getIndex();
    const vertices: number[] = [];
    for (let j = 0; j < pos.count; j++) {
      vertices.push(pos.getX(j), pos.getY(j), pos.getZ(j));
    }
    let indices: number[] | null = null;
    if (index) {
      indices = [];
      for (let j = 0; j < index.count; j++) {
        indices.push(index.getX(j));
      }
    }
    // Extract material color.
    let color = '#9ca3af';
    const mat = mesh.material as THREE.Material | THREE.Material[];
    if (Array.isArray(mat)) {
      const first = mat.find(m => (m as THREE.MeshStandardMaterial).color);
      if (first) color = `#${(first as THREE.MeshStandardMaterial).color.getHexString()}`;
    } else if (mat && 'color' in mat) {
      color = `#${(mat as THREE.MeshStandardMaterial).color.getHexString()}`;
    }
    return {
      name: mesh.name || `mesh_${i}`,
      vertices,
      indices,
      color,
    };
  });
}

/**
 * Generate all file contents for the current project.
 */
async function generateFileContents(): Promise<FileContent[]> {
  const project = useEnclosureStore.getState().project;
  const files: FileContent[] = [];

  // 1. Project JSON (.enclosure)
  files.push({
    name: 'Project File',
    ext: 'enclosure',
    content: serializeProject(project),
  });

  // Generate geometry for the export formats.
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const repaired = repairMeshes(allMeshes, 0.01);

  // 2. STL (ASCII)
  const stlAsciiBlob = exportSTL(repaired, false, project.name);
  const stlAsciiText = await stlAsciiBlob.text();
  files.push({
    name: 'STL (ASCII)',
    ext: 'stl',
    content: stlAsciiText,
  });

  // 3. STL (binary hex dump)
  const stlBinaryBlob = exportSTL(repaired, true, project.name);
  const stlBinaryBuf = new Uint8Array(await stlBinaryBlob.arrayBuffer());
  files.push({
    name: 'STL (Binary — hex dump)',
    ext: 'stl',
    content: hexDump(stlBinaryBuf, 512), // first 512 bytes
    isBinary: true,
  });

  // 4. OBJ
  const mat: MaterialType = 'PLA';
  const { obj, mtl } = exportOBJ(
    meshesToObjMeshes(repaired.map(m => ({ mesh: m, name: project.name, material: mat }))),
    project.name
  );
  files.push({
    name: 'OBJ',
    ext: 'obj',
    content: obj,
  });
  files.push({
    name: 'MTL (material)',
    ext: 'mtl',
    content: mtl,
  });

  // 5. 3MF (unzip and show the XML)
  const threeMfBlob = await export3MF(repaired, project.name);
  const threeMfBuf = await threeMfBlob.arrayBuffer();
  const zip = await JSZip.loadAsync(threeMfBuf);
  const modelFile = zip.file('3D/3dmodel.model');
  if (modelFile) {
    const modelXml = await modelFile.async('string');
    files.push({
      name: '3MF (XML — 3D/3dmodel.model)',
      ext: '3mf',
      content: modelXml,
    });
  }
  const ctFile = zip.file('[Content_Types].xml');
  if (ctFile) {
    files.push({
      name: '3MF ([Content_Types].xml)',
      ext: 'xml',
      content: await ctFile.async('string'),
    });
  }
  const relsFile = zip.file('_rels/.rels');
  if (relsFile) {
    files.push({
      name: '3MF (_rels/.rels)',
      ext: 'xml',
      content: await relsFile.async('string'),
    });
  }

  // 6. PLY (ASCII)
  const plyBlob = exportPLY(repaired, false);
  const plyText = await plyBlob.text();
  files.push({
    name: 'PLY (ASCII)',
    ext: 'ply',
    content: plyText,
  });

  return files;
}

/**
 * Format a Uint8Array as a hex dump (offset | hex bytes | ASCII).
 */
function hexDump(buf: Uint8Array, maxBytes: number): string {
  const len = Math.min(buf.length, maxBytes);
  const lines: string[] = [];
  for (let i = 0; i < len; i += 16) {
    const offset = i.toString(16).padStart(8, '0');
    const hexBytes: string[] = [];
    const asciiChars: string[] = [];
    for (let j = 0; j < 16; j++) {
      if (i + j < len) {
        const byte = buf[i + j];
        hexBytes.push(byte.toString(16).padStart(2, '0'));
        asciiChars.push(byte >= 32 && byte < 127 ? String.fromCharCode(byte) : '.');
      } else {
        hexBytes.push('  ');
        asciiChars.push(' ');
      }
    }
    lines.push(`${offset}  ${hexBytes.slice(0, 8).join(' ')}  ${hexBytes.slice(8, 16).join(' ')}  |${asciiChars.join('')}|`);
  }
  if (buf.length > maxBytes) {
    lines.push(`... (${buf.length - maxBytes} more bytes)`);
  }
  return lines.join('\n');
}

/**
 * Generate the full HTML document for the popup window.
 */
function buildPopupHtml(files: FileContent[], meshes: SerializedMesh[], projectName: string): string {
  const escapeJs = (s: string) =>
    s.replace(/\\/g, '\\\\').replace(/'/g, "\\'").replace(/"/g, '\\"').replace(/\n/g, '\\n').replace(/\r/g, '\\r');

  const fileData = files.map(f => ({
    name: f.name,
    ext: f.ext,
    content: f.content,
    isBinary: f.isBinary ?? false,
  }));

  // Serialize meshes to JSON for the 3D preview. We embed this as a JSON
  // string that the popup's script parses with JSON.parse.
  const meshesJson = JSON.stringify(meshes);

  return `<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <title>File Viewer — ${escapeHtml(projectName)}</title>
  <style>
    * { box-sizing: border-box; margin: 0; padding: 0; }
    body { font-family: 'SF Mono', 'Monaco', 'Cascadia Code', 'Roboto Mono', monospace; font-size: 12px; background: #0f172a; color: #e2e8f0; height: 100vh; display: flex; flex-direction: column; }
    .header { background: #1e293b; padding: 8px 16px; border-bottom: 1px solid #334155; display: flex; align-items: center; gap: 12px; }
    .header h1 { font-size: 14px; font-weight: 600; color: #f1f5f9; }
    .header .project-name { font-size: 11px; color: #94a3b8; }
    .toolbar { display: flex; gap: 8px; margin-left: auto; }
    .toolbar button { background: #334155; color: #e2e8f0; border: 1px solid #475569; border-radius: 4px; padding: 4px 10px; font-size: 11px; cursor: pointer; font-family: inherit; }
    .toolbar button:hover { background: #475569; }
    .toolbar button.active { background: #fbbf24; color: #0f172a; border-color: #fbbf24; }
    .main { flex: 1; display: flex; overflow: hidden; }
    .sidebar { width: 220px; background: #1e293b; border-right: 1px solid #334155; overflow-y: auto; padding: 8px 0; }
    .sidebar .file-item { padding: 6px 12px; cursor: pointer; font-size: 11px; color: #cbd5e1; border-left: 2px solid transparent; }
    .sidebar .file-item:hover { background: #334155; }
    .sidebar .file-item.active { background: #334155; border-left-color: #fbbf24; color: #fbbf24; }
    .sidebar .file-item .ext { color: #64748b; margin-left: 6px; font-size: 10px; }
    .sidebar .file-item .size { color: #475569; font-size: 10px; margin-left: 6px; }
    .content-area { flex: 1; overflow: auto; background: #0f172a; }
    .content-area.previewer { display: flex; flex-direction: column; overflow: hidden; }
    .content-area pre { padding: 12px; white-space: pre-wrap; word-break: break-all; font-family: inherit; font-size: 11px; line-height: 1.5; color: #e2e8f0; }
    .diff-line { display: flex; align-items: flex-start; padding: 0 4px; min-height: 16px; }
    .diff-equal { color: #64748b; }
    .diff-added { background: #14532d; color: #86efac; }
    .diff-removed { background: #7f1d1d; color: #fca5a5; }
    .line-num { display: inline-block; width: 40px; text-align: right; color: #475569; padding-right: 6px; user-select: none; flex-shrink: 0; font-size: 10px; }
    .line-prefix { display: inline-block; width: 14px; text-align: center; flex-shrink: 0; font-weight: bold; }
    .line-text { flex: 1; word-break: break-all; white-space: pre-wrap; }
    .diff-summary { padding: 8px 12px; background: #1e293b; border-bottom: 1px solid #334155; font-size: 11px; color: #94a3b8; }
    .diff-summary .added { color: #86efac; }
    .diff-summary .removed { color: #fca5a5; }
    .diff-summary .unchanged { color: #64748b; }
    .empty { padding: 40px; text-align: center; color: #475569; }
    .preview-3d { flex: 1 1 auto; min-height: 0; position: relative; background: #1a1a2e; }
    .preview-3d canvas { display: block; }
    .view-toolbar { position: absolute; top: 8px; left: 8px; display: flex; gap: 4px; flex-wrap: wrap; z-index: 10; }
    .view-toolbar button { background: rgba(30,41,59,0.9); color: #e2e8f0; border: 1px solid #475569; border-radius: 3px; padding: 3px 8px; font-size: 10px; cursor: pointer; font-family: inherit; }
    .view-toolbar button:hover { background: #475569; }
    .view-toolbar button.active { background: #fbbf24; color: #0f172a; border-color: #fbbf24; }
    .preview-info { position: absolute; bottom: 8px; left: 8px; background: rgba(15,23,42,0.85); color: #94a3b8; padding: 6px 10px; border-radius: 4px; font-size: 10px; font-family: inherit; }
    .print-summary { position: absolute; bottom: 8px; right: 8px; background: rgba(15,23,42,0.92); color: #e2e8f0; padding: 8px 12px; border-radius: 4px; font-size: 11px; font-family: inherit; max-width: 500px; z-index: 10; border: 1px solid #334155; }
    .print-summary .ok { color: #4ade80; }
    .print-summary .warn { color: #fbbf24; }
    .print-summary .bad { color: #f87171; }
    .sidebar .section-label { padding: 8px 12px 4px; font-size: 9px; text-transform: uppercase; color: #475569; letter-spacing: 0.5px; }
  </style>
</head>
<body>
  <div class="header">
    <h1>File Viewer</h1>
    <span class="project-name">${escapeHtml(projectName)}</span>
    <div class="toolbar">
      <button id="btn-snapshot" onclick="takeSnapshot()">Take Snapshot</button>
      <button id="btn-diff" onclick="toggleDiff()">Show Diff</button>
      <button onclick="window.close()">Close</button>
    </div>
  </div>
  <div class="main">
    <div class="sidebar" id="sidebar"></div>
    <div class="content-area" id="content-area">
      <div class="empty">Select a file from the sidebar.</div>
    </div>
  </div>
  <script>
    const files = ${JSON.stringify(fileData.map(f => ({
      name: f.name,
      ext: f.ext,
      content: f.content,
      isBinary: f.isBinary,
    })))};
    const meshes3d = ${meshesJson};
    // activeFile: -1 = 3D preview, 0..N = text files
    let activeFile = -1; // default to 3D preview
    let snapshot = null; // { fileIndex: content }
    // Load snapshot from localStorage (survives popup close/reopen).
    try {
      const saved = localStorage.getItem('enclosure-file-viewer-snapshot');
      if (saved) { snapshot = JSON.parse(saved); }
    } catch (e) { /* ignore */ }
    let diffMode = false;
    let three3D = null; // { scene, camera, renderer, controls, animationId }

    function escapeHtml(s) {
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    function renderSidebar() {
      const sidebar = document.getElementById('sidebar');
      sidebar.innerHTML = '';
      // 3D Preview section
      const section3d = document.createElement('div');
      section3d.className = 'section-label';
      section3d.textContent = '3D Preview';
      sidebar.appendChild(section3d);
      const item3d = document.createElement('div');
      item3d.className = 'file-item' + (activeFile === -1 ? ' active' : '');
      let triCount3d = 0;
      for (const m of meshes3d) {
        if (m.indices) triCount3d += m.indices.length / 3;
        else triCount3d += m.vertices.length / 9;
      }
      item3d.innerHTML = '3D Model<span class="ext">.glb</span><span class="size">' + triCount3d.toLocaleString() + ' tris</span>';
      item3d.onclick = () => { activeFile = -1; diffMode = false; renderSidebar(); renderContent(); };
      sidebar.appendChild(item3d);
      // Text files section
      const sectionText = document.createElement('div');
      sectionText.className = 'section-label';
      sectionText.style.marginTop = '8px';
      sectionText.textContent = 'File Contents';
      sidebar.appendChild(sectionText);
      files.forEach((f, i) => {
        const item = document.createElement('div');
        item.className = 'file-item' + (i === activeFile ? ' active' : '');
        const sizeKB = (f.content.length / 1024).toFixed(1);
        item.innerHTML = escapeHtml(f.name) + '<span class="ext">.' + escapeHtml(f.ext) + '</span><span class="size">' + sizeKB + 'KB</span>';
        item.onclick = () => { activeFile = i; diffMode = false; renderSidebar(); renderContent(); };
        sidebar.appendChild(item);
      });
    }

    function renderContent() {
      const area = document.getElementById('content-area');
      // Clean up any existing 3D scene.
      cleanup3D();

      if (activeFile === -1) {
        // 3D Preview mode — render the model with Three.js.
        area.className = 'content-area previewer';
        render3DPreview(area);
        return;
      }

      // Text content mode — switch back to scrollable content area.
      area.className = 'content-area';

      const f = files[activeFile];
      if (!f) { area.innerHTML = '<div class="empty">No file selected.</div>'; return; }

      if (diffMode && snapshot && snapshot[activeFile] !== undefined) {
        // Show diff
        const oldText = snapshot[activeFile];
        const newText = f.content;
        const diff = computeDiff(oldText, newText);
        const summary = summarizeDiff(diff);
        area.innerHTML =
          '<div class="diff-summary">Diff: <span class="added">+' + summary.added + ' added</span> · <span class="removed">-' + summary.removed + ' removed</span> · <span class="unchanged">' + summary.unchanged + ' unchanged</span></div>' +
          '<div>' + diffToHtml(diff) + '</div>';
      } else {
        // Show raw content
        area.innerHTML = '<pre>' + escapeHtml(f.content) + '</pre>';
      }
    }

    function cleanup3D() {
      if (three3D) {
        if (three3D.animationId) cancelAnimationFrame(three3D.animationId);
        if (three3D.controls) three3D.controls.dispose();
        if (three3D.renderer) three3D.renderer.dispose();
        three3D = null;
      }
    }

    function render3DPreview(area) {
      area.innerHTML =
        '<div class="preview-3d">' +
          '<div class="view-toolbar">' +
            '<button onclick="setView(\\'front\\')">Front</button>' +
            '<button onclick="setView(\\'back\\')">Back</button>' +
            '<button onclick="setView(\\'left\\')">Left</button>' +
            '<button onclick="setView(\\'right\\')">Right</button>' +
            '<button onclick="setView(\\'top\\')">Top</button>' +
            '<button onclick="setView(\\'bottom\\')">Bottom</button>' +
            '<button onclick="setView(\\'iso\\')" class="active">Iso</button>' +
            '<button onclick="toggleWireframe()" id="btn-wireframe">Wireframe</button>' +
            '<button onclick="togglePrintPreview()" id="btn-print" title="Color-code faces by overhang angle: green=OK, yellow=needs supports, red=will sag">Print Check</button>' +
          '</div>' +
          '<div class="preview-info" id="preview-info">Loading...</div>' +
          '<div class="print-summary" id="print-summary" style="display:none;"></div>' +
        '</div>';
      const container = area.querySelector('.preview-3d');

      // Load Three.js from CDN if not already loaded.
      if (typeof THREE === 'undefined') {
        const script = document.createElement('script');
        script.src = 'https://cdn.jsdelivr.net/npm/three@0.160.0/build/three.min.js';
        script.onload = () => { init3DScene(container); };
        script.onerror = () => {
          container.innerHTML = '<div class="empty">Failed to load Three.js from CDN. Check your internet connection.</div>';
        };
        document.head.appendChild(script);
      } else {
        init3DScene(container);
      }
    }

    function init3DScene(container) {
      if (three3D) cleanup3D();

      const scene = new THREE.Scene();
      scene.background = new THREE.Color(0x1a1a2e);

      const camera = new THREE.PerspectiveCamera(45, container.clientWidth / container.clientHeight, 0.1, 5000);
      camera.position.set(100, 100, 150);
      camera.lookAt(0, 0, 0);

      const renderer = new THREE.WebGLRenderer({ antialias: true });
      renderer.setPixelRatio(window.devicePixelRatio);
      renderer.setSize(container.clientWidth, container.clientHeight);
      renderer.shadowMap.enabled = true;
      container.appendChild(renderer.domElement);

      // Lights
      const ambient = new THREE.AmbientLight(0xffffff, 0.4);
      scene.add(ambient);
      const dir1 = new THREE.DirectionalLight(0xffffff, 0.8);
      dir1.position.set(100, 200, 150);
      scene.add(dir1);
      const dir2 = new THREE.DirectionalLight(0xffffff, 0.3);
      dir2.position.set(-100, 50, -150);
      scene.add(dir2);

      // Grid + axes
      const grid = new THREE.GridHelper(200, 20, 0x475569, 0x334155);
      scene.add(grid);
      const axes = new THREE.AxesHelper(50);
      scene.add(axes);

      // Add meshes
      let totalTri = 0;
      const allMeshes = [];
      for (const m of meshes3d) {
        const geom = new THREE.BufferGeometry();
        geom.setAttribute('position', new THREE.Float32BufferAttribute(m.vertices, 3));
        if (m.indices) geom.setIndex(m.indices);
        geom.computeVertexNormals();
        geom.computeBoundingBox();
        const mat = new THREE.MeshStandardMaterial({
          color: new THREE.Color(m.color),
          roughness: 0.5,
          metalness: 0.0,
          side: THREE.DoubleSide,
        });
        const mesh = new THREE.Mesh(geom, mat);
        scene.add(mesh);
        allMeshes.push(mesh);
        totalTri += m.indices ? m.indices.length / 3 : m.vertices.length / 9;
      }

      // Center the camera on the model's bounding box.
      const bbox = new THREE.Box3();
      for (const m of allMeshes) {
        bbox.expandByObject(m);
      }
      const center = new THREE.Vector3();
      const size = new THREE.Vector3();
      bbox.getCenter(center);
      bbox.getSize(size);
      const maxDim = Math.max(size.x, size.y, size.z);
      const dist = maxDim * 2.5;
      camera.position.set(center.x + dist * 0.5, center.y + dist * 0.5, center.z + dist * 1.2);
      camera.lookAt(center);
      camera.near = maxDim / 100;
      camera.far = maxDim * 100;
      camera.updateProjectionMatrix();

      // Load OrbitControls from CDN.
      const controlsScript = document.createElement('script');
      controlsScript.src = 'https://cdn.jsdelivr.net/npm/three@0.160.0/examples/js/controls/OrbitControls.js';
      controlsScript.onload = () => {
        // OrbitControls is attached to THREE.OrbitControls in the legacy build.
        if (THREE.OrbitControls) {
          const controls = new THREE.OrbitControls(camera, renderer.domElement);
          controls.target.copy(center);
          controls.enableDamping = true;
          controls.dampingFactor = 0.08;
          controls.update();
          three3D.controls = controls;
        }
      };
      document.head.appendChild(controlsScript);

      const info = document.getElementById('preview-info');
      if (info) {
        info.textContent = totalTri.toLocaleString() + ' triangles · ' + meshes3d.length + ' meshes · ' +
          size.x.toFixed(1) + '×' + size.y.toFixed(1) + '×' + size.z.toFixed(1) + ' mm';
      }

      // Handle resize.
      const onResize = () => {
        if (!three3D) return;
        camera.aspect = container.clientWidth / container.clientHeight;
        camera.updateProjectionMatrix();
        renderer.setSize(container.clientWidth, container.clientHeight);
      };
      window.addEventListener('resize', onResize);

      // Animation loop.
      const animate = () => {
        three3D.animationId = requestAnimationFrame(animate);
        if (three3D.controls) three3D.controls.update();
        renderer.render(scene, camera);
      };
      three3D = { scene, camera, renderer, controls: null, animationId: null };
      animate();
    }

    // View presets for the 3D preview.
    function setView(view) {
      if (!three3D) return;
      const c = three3D.camera;
      const ctr = three3D.controls ? three3D.controls.target : new THREE.Vector3(0,0,0);
      // Determine distance based on current camera distance to target.
      const dist = c.position.distanceTo(ctr);
      const dx = dist, dy = dist, dz = dist;
      switch (view) {
        case 'front':  c.position.set(ctr.x, ctr.y, ctr.z + dz); break;
        case 'back':   c.position.set(ctr.x, ctr.y, ctr.z - dz); break;
        case 'left':   c.position.set(ctr.x - dx, ctr.y, ctr.z); break;
        case 'right':  c.position.set(ctr.x + dx, ctr.y, ctr.z); break;
        case 'top':    c.position.set(ctr.x, ctr.y + dy, ctr.z); break;
        case 'bottom': c.position.set(ctr.x, ctr.y - dy, ctr.z); break;
        case 'iso':    c.position.set(ctr.x + dx * 0.5, ctr.y + dy * 0.5, ctr.z + dz * 1.2); break;
      }
      c.lookAt(ctr);
      if (three3D.controls) three3D.controls.update();
      // Update active button styling
      document.querySelectorAll('.view-toolbar button').forEach(b => b.classList.remove('active'));
      if (event && event.target) event.target.classList.add('active');
    }

    function toggleWireframe() {
      if (!three3D) return;
      three3D.scene.traverse(obj => {
        if (obj.isMesh && obj.material) {
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          for (const m of mats) {
            if ('wireframe' in m) m.wireframe = !m.wireframe;
          }
        }
      });
      const btn = document.getElementById('btn-wireframe');
      if (btn) btn.classList.toggle('active');
    }

    // Print Preview — color-codes each face by overhang angle.
    //   GREEN  = face points up or is steep enough (< 45° from horizontal): OK
    //   YELLOW = face is 30-45° from horizontal, facing down: overhang, may need supports
    //   RED    = face is < 30° from horizontal, facing down: will sag without supports
    //
    // For each triangle, we compute the normal's Z component:
    //   nz ≥ -0.707 → GREEN (upward, vertical, or steep > 45°)
    //   -0.866 < nz < -0.707 → YELLOW (30-45° overhang)
    //   nz ≤ -0.866 → RED (< 30° from horizontal, nearly flat — needs supports)
    let printPreviewActive = false;

    function togglePrintPreview() {
      if (!three3D) return;
      printPreviewActive = !printPreviewActive;
      const btn = document.getElementById('btn-print');
      const summary = document.getElementById('print-summary');
      if (btn) btn.classList.toggle('active', printPreviewActive);

      if (printPreviewActive) {
        // Run the overhang analysis and apply vertex colors.
        const stats = { ok: 0, warning: 0, problem: 0, total: 0 };
        three3D.scene.traverse(obj => {
          if (!obj.isMesh) return;
          const geom = obj.geometry;
          const pos = geom.getAttribute('position');
          const index = geom.getIndex();
          if (!pos) return;

          // Compute per-vertex colors based on the triangle normal's Z component.
          const colors = new Float32Array(pos.count * 3);
          const v0 = new THREE.Vector3();
          const v1 = new THREE.Vector3();
          const v2 = new THREE.Vector3();
          const e1 = new THREE.Vector3();
          const e2 = new THREE.Vector3();
          const n = new THREE.Vector3();
          const triCount = index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);

          // Initialize colors to green (OK).
          for (let i = 0; i < colors.length; i++) colors[i] = 0.3;

          for (let i = 0; i < triCount; i++) {
            const a = index ? index.getX(i * 3) : i * 3;
            const b = index ? index.getX(i * 3 + 1) : i * 3 + 1;
            const c = index ? index.getX(i * 3 + 2) : i * 3 + 2;
            v0.fromBufferAttribute(pos, a);
            v1.fromBufferAttribute(pos, b);
            v2.fromBufferAttribute(pos, c);
            e1.subVectors(v1, v0);
            e2.subVectors(v2, v0);
            n.crossVectors(e1, e2);
            const len = n.length();
            if (len < 1e-9) continue;
            const nz = n.z / len;

            // Determine color based on normal Z.
            let r, g, b_;
            if (nz >= -0.707) {
              // GREEN — OK (upward, vertical, or steep > 45°)
              r = 0.1; g = 0.7; b_ = 0.3;
              stats.ok++;
            } else if (nz > -0.866) {
              // YELLOW — warning (30-45° overhang)
              r = 0.9; g = 0.75; b_ = 0.1;
              stats.warning++;
            } else {
              // RED — problem (< 30° from horizontal, nearly flat — needs supports)
              r = 0.85; g = 0.15; b_ = 0.15;
              stats.problem++;
            }
            stats.total++;

            // Apply color to all 3 vertices of this triangle.
            colors[a * 3] = r; colors[a * 3 + 1] = g; colors[a * 3 + 2] = b_;
            colors[b * 3] = r; colors[b * 3 + 1] = g; colors[b * 3 + 2] = b_;
            colors[c * 3] = r; colors[c * 3 + 1] = g; colors[c * 3 + 2] = b_;
          }

          geom.setAttribute('color', new THREE.Float32BufferAttribute(colors, 3));
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          for (const m of mats) {
            if ('vertexColors' in m) {
              m.vertexColors = true;
              m.needsUpdate = true;
            }
          }
        });
        // Show summary.
        if (summary) {
          const pct = (count, total) => total > 0 ? ((count / total) * 100).toFixed(1) + '%' : '0%';
          summary.style.display = 'block';
          summary.innerHTML =
            '<span class="ok">● ' + pct(stats.ok, stats.total) + ' OK (prints fine)</span> · ' +
            '<span class="warn">● ' + pct(stats.warning, stats.total) + ' Overhang (may need supports)</span> · ' +
            '<span class="bad">● ' + pct(stats.problem, stats.total) + ' Needs supports (will sag)</span>';
        }
      } else {
        // Revert to original colors — disable vertex colors on all materials.
        three3D.scene.traverse(obj => {
          if (!obj.isMesh) return;
          const mats = Array.isArray(obj.material) ? obj.material : [obj.material];
          for (const m of mats) {
            if ('vertexColors' in m) {
              m.vertexColors = false;
              m.needsUpdate = true;
            }
          }
          if (obj.geometry.getAttribute('color')) {
            obj.geometry.deleteAttribute('color');
          }
        });
        if (summary) summary.style.display = 'none';
      }
    }

    function takeSnapshot() {
      snapshot = {};
      files.forEach((f, i) => { snapshot[i] = f.content; });
      // Persist to localStorage so the snapshot survives popup close/reopen.
      try {
        localStorage.setItem('enclosure-file-viewer-snapshot', JSON.stringify(snapshot));
        localStorage.setItem('enclosure-file-viewer-snapshot-time', new Date().toISOString());
      } catch (e) { /* localStorage might be unavailable in some contexts */ }
      document.getElementById('btn-snapshot').classList.add('active');
      document.getElementById('btn-snapshot').textContent = 'Snapshot Taken ✓';
      setTimeout(() => {
        document.getElementById('btn-snapshot').classList.remove('active');
        document.getElementById('btn-snapshot').textContent = 'Take Snapshot';
      }, 2000);
    }

    function toggleDiff() {
      if (!snapshot) {
        alert('Take a snapshot first (click "Take Snapshot"), then modify your project in the main window, then re-open this File Viewer and click "Show Diff" to see what changed.');
        return;
      }
      diffMode = !diffMode;
      const btn = document.getElementById('btn-diff');
      if (diffMode) { btn.classList.add('active'); btn.textContent = 'Hide Diff'; }
      else { btn.classList.remove('active'); btn.textContent = 'Show Diff'; }
      renderContent();
    }

    // Diff algorithm (LCS-based)
    function computeDiff(oldText, newText) {
      const oldLines = oldText.split('\\n');
      const newLines = newText.split('\\n');
      const n = oldLines.length, m = newLines.length;
      const MAX = 5000;
      if (n > MAX || m > MAX) {
        const r = [];
        for (let i = 0; i < n; i++) r.push({type:'removed',text:oldLines[i],oldLineNumber:i+1,newLineNumber:0});
        for (let j = 0; j < m; j++) r.push({type:'added',text:newLines[j],oldLineNumber:0,newLineNumber:j+1});
        return r;
      }
      const lcs = Array.from({length:n+1}, () => new Array(m+1).fill(0));
      for (let i = n-1; i >= 0; i--) {
        for (let j = m-1; j >= 0; j--) {
          if (oldLines[i] === newLines[j]) lcs[i][j] = lcs[i+1][j+1] + 1;
          else lcs[i][j] = Math.max(lcs[i+1][j], lcs[i][j+1]);
        }
      }
      const result = [];
      let i = 0, j = 0;
      while (i < n && j < m) {
        if (oldLines[i] === newLines[j]) {
          result.push({type:'equal',text:oldLines[i],oldLineNumber:i+1,newLineNumber:j+1});
          i++; j++;
        } else if (lcs[i+1][j] >= lcs[i][j+1]) {
          result.push({type:'removed',text:oldLines[i],oldLineNumber:i+1,newLineNumber:0});
          i++;
        } else {
          result.push({type:'added',text:newLines[j],oldLineNumber:0,newLineNumber:j+1});
          j++;
        }
      }
      while (i < n) { result.push({type:'removed',text:oldLines[i],oldLineNumber:i+1,newLineNumber:0}); i++; }
      while (j < m) { result.push({type:'added',text:newLines[j],oldLineNumber:0,newLineNumber:j+1}); j++; }
      return result;
    }

    function diffToHtml(diff) {
      return diff.map(dl => {
        const cls = dl.type === 'added' ? 'diff-added' : dl.type === 'removed' ? 'diff-removed' : 'diff-equal';
        const prefix = dl.type === 'added' ? '+' : dl.type === 'removed' ? '-' : ' ';
        const oldLn = dl.oldLineNumber > 0 ? String(dl.oldLineNumber).padStart(4,' ') : '    ';
        const newLn = dl.newLineNumber > 0 ? String(dl.newLineNumber).padStart(4,' ') : '    ';
        return '<div class="diff-line ' + cls + '"><span class="line-num">' + oldLn + '</span><span class="line-num">' + newLn + '</span><span class="line-prefix">' + prefix + '</span><span class="line-text">' + escapeHtml(dl.text) + '</span></div>';
      }).join('');
    }

    function summarizeDiff(diff) {
      let added=0, removed=0, unchanged=0;
      for (const dl of diff) {
        if (dl.type === 'added') added++;
        else if (dl.type === 'removed') removed++;
        else unchanged++;
      }
      return {added, removed, unchanged};
    }

    function escapeHtml(s) {
      return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
    }

    renderSidebar();
    renderContent();
  </script>
</body>
</html>`;
}

function escapeHtml(s: string): string {
  return s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
}

/**
 * The FileViewer button component.
 */
export function FileViewerButton() {
  const [loading, setLoading] = React.useState(false);

  const handleOpen = async () => {
    setLoading(true);
    try {
      const project = useEnclosureStore.getState().project;
      const files = await generateFileContents();

      // Serialize the meshes for the 3D preview.
      const result = generateEnclosureGeometry({ project });
      const allMeshes = result.parts.flatMap(p => p.meshes);
      const repaired = repairMeshes(allMeshes, 0.01);
      const meshes = serializeMeshes(repaired);

      const html = buildPopupHtml(files, meshes, project.name);

      // Open a popup window.
      const popup = window.open('', '_blank', 'width=1200,height=800,scrollbars=yes');
      if (!popup) {
        alert('Popup blocked. Please allow popups for this site, then try again.');
        return;
      }
      popup.document.open();
      popup.document.write(html);
      popup.document.close();
    } catch (err) {
      console.error('File viewer failed:', err);
      alert(`File viewer failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally {
      setLoading(false);
    }
  };

  return (
    <Button
      variant="ghost"
      size="sm"
      className="text-slate-300 hover:text-amber-400 text-xs"
      onClick={handleOpen}
      disabled={loading}
      title="Open file viewer in a separate window"
    >
      <FileText size={12} className="mr-1" />
      {loading ? 'Loading...' : '3D Preview'}
    </Button>
  );
}
