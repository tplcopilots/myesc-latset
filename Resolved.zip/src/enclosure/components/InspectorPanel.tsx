'use client';

/**
 * Inspector panel (RIGHT) — shows:
 *   - Object tree
 *   - Validation issues list (color-coded, click to select)
 *   - Print orientation controls (XYZ rotation sliders)
 *   - Print stats (bbox dims, volumes)
 */
import React from 'react';
import { AlertTriangle, CheckCircle2, XCircle, ChevronRight } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { ScrollArea } from '@/components/ui/scroll-area';
import { useEnclosureStore } from '../store/enclosureStore';
import { generateEnclosureGeometry } from '../geometry';
import type { PartId } from '../types';
import { formatLength, formatVolume, formatCount } from '../utils/format';
import { useMemo } from 'react';

// Object tree node — recursive.
function TreeNode({
  label,
  level = 0,
  selected,
  onClick,
  children,
}: {
  label: string;
  level?: number;
  selected?: boolean;
  onClick?: () => void;
  children?: React.ReactNode;
}) {
  const [open, setOpen] = React.useState(true);
  return (
    <div>
      <div
        className={`flex items-center gap-1 px-1 py-1 text-xs rounded cursor-pointer hover:bg-slate-800/70 ${
          selected ? 'bg-slate-800 text-amber-400' : 'text-slate-200'
        }`}
        style={{ paddingLeft: 8 + level * 12 }}
        onClick={onClick}
      >
        {children ? (
          <button
            onClick={(e) => { e.stopPropagation(); setOpen(!open); }}
            className="text-slate-400 hover:text-slate-200"
          >
            <ChevronRight
              size={10}
              className={`transition-transform ${open ? 'rotate-90' : ''}`}
            />
          </button>
        ) : (
          <span className="w-[10px]" />
        )}
        <span>{label}</span>
      </div>
      {open && children && <div>{children}</div>}
    </div>
  );
}

function ObjectTree() {
  const project = useEnclosureStore(s => s.project);
  const selectedPart = useEnclosureStore(s => s.selectedPart);
  const setSelectedPart = useEnclosureStore(s => s.setSelectedPart);

  return (
    <div className="text-xs">
      <TreeNode
        label="Enclosure"
        level={0}
        selected={selectedPart === 'bottom'}
        onClick={() => setSelectedPart('bottom')}
      >
        <TreeNode
          label="Bottom"
          level={1}
          selected={selectedPart === 'bottom'}
          onClick={() => setSelectedPart('bottom')}
        />
        <TreeNode
          label="Lid"
          level={1}
          selected={selectedPart === 'lid'}
          onClick={() => setSelectedPart('lid')}
        />
        <TreeNode label={`PCB${project.pcbs.length > 1 ? ` (${project.pcbs.length})` : ''}`} level={1}>
          {project.pcbs.length === 0 ? (
            <TreeNode label="(none)" level={2} />
          ) : (
            project.pcbs.map((p, i) => (
              <TreeNode key={p.id} label={`${i + 1}. ${p.name}`} level={2} />
            ))
          )}
        </TreeNode>
        <TreeNode label="Mounting" level={1}>
          <TreeNode label="Screw bosses (auto)" level={2} />
        </TreeNode>
        <TreeNode label={`Cutouts (${project.cutouts.length})`} level={1}>
          {project.cutouts.length === 0 ? (
            <TreeNode label="(none)" level={2} />
          ) : (
            project.cutouts.map((c, i) => (
              <TreeNode key={c.id} label={`${i + 1}. ${c.name}`} level={2} />
            ))
          )}
        </TreeNode>
        <TreeNode
          label="Ventilation"
          level={1}
          selected={selectedPart === 'vents'}
          onClick={() => setSelectedPart('vents')}
        />
        <TreeNode
          label="Feet"
          level={1}
          selected={selectedPart === 'feet'}
          onClick={() => setSelectedPart('feet')}
        />
      </TreeNode>
    </div>
  );
}

function ValidationList() {
  const issues = useEnclosureStore(s => s.validationIssues);
  const runValidation = useEnclosureStore(s => s.runValidation);
  const setSelectedPart = useEnclosureStore(s => s.setSelectedPart);

  React.useEffect(() => {
    if (issues.length === 0) runValidation();
  }, [issues.length, runValidation]);

  return (
    <div className="space-y-1">
      {issues.map(issue => {
        const color =
          issue.severity === 'error' ? 'text-red-400' :
          issue.severity === 'warning' ? 'text-amber-400' :
          'text-emerald-400';
        const Icon =
          issue.severity === 'error' ? XCircle :
          issue.severity === 'warning' ? AlertTriangle :
          CheckCircle2;
        return (
          <button
            key={issue.id}
            onClick={() => issue.part && setSelectedPart(issue.part)}
            className="w-full text-left p-2 rounded hover:bg-slate-800/70 flex gap-2 items-start"
          >
            <Icon size={12} className={`${color} mt-0.5 shrink-0`} />
            <div className="flex-1">
              <div className={`text-[10px] uppercase tracking-wide ${color}`}>
                {issue.category.replace('-', ' ')}
              </div>
              <div className="text-[11px] text-slate-200">{issue.message}</div>
            </div>
          </button>
        );
      })}
    </div>
  );
}

function PrintOrientation() {
  const project = useEnclosureStore(s => s.project);
  const setPrintOrientation = useEnclosureStore(s => s.setPrintOrientation);

  return (
    <div className="space-y-3">
      <div>
        <Label className="text-[10px] text-slate-400 uppercase">Rotation X (°)</Label>
        <div className="flex items-center gap-2">
          <Slider
            value={[project.printOrientation.x]}
            min={0}
            max={360}
            step={1}
            onValueChange={v => setPrintOrientation({ x: v[0] })}
            className="flex-1"
          />
          <span className="text-xs text-slate-300 w-10 text-right">{project.printOrientation.x.toFixed(0)}</span>
        </div>
      </div>
      <div>
        <Label className="text-[10px] text-slate-400 uppercase">Rotation Y (°)</Label>
        <div className="flex items-center gap-2">
          <Slider
            value={[project.printOrientation.y]}
            min={0}
            max={360}
            step={1}
            onValueChange={v => setPrintOrientation({ y: v[0] })}
            className="flex-1"
          />
          <span className="text-xs text-slate-300 w-10 text-right">{project.printOrientation.y.toFixed(0)}</span>
        </div>
      </div>
      <div>
        <Label className="text-[10px] text-slate-400 uppercase">Rotation Z (°)</Label>
        <div className="flex items-center gap-2">
          <Slider
            value={[project.printOrientation.z]}
            min={0}
            max={360}
            step={1}
            onValueChange={v => setPrintOrientation({ z: v[0] })}
            className="flex-1"
          />
          <span className="text-xs text-slate-300 w-10 text-right">{project.printOrientation.z.toFixed(0)}</span>
        </div>
      </div>
    </div>
  );
}

function PrintStats() {
  const project = useEnclosureStore(s => s.project);
  const dirty = useEnclosureStore(s => s.dirty);
  // Memoize on project changes.
  const stats = useMemo(() => {
    try {
      return generateEnclosureGeometry({ project });
    } catch (err) {
      console.error(err);
      return null;
    }
  }, [project, dirty]);
  if (!stats) {
    return <div className="text-xs text-slate-500">Computing...</div>;
  }
  const { width, depth, height } = project.dimensions;
  const unit = project.settings.unit;
  return (
    <div className="space-y-1 text-xs">
      <div className="flex justify-between text-slate-300">
        <span>Bounding box</span>
        <span>{formatLength(width, unit, 1)} × {formatLength(depth, unit, 1)} × {formatLength(height, unit, 1)}</span>
      </div>
      <div className="flex justify-between text-slate-300">
        <span>Triangle count</span>
        <span>{formatCount(stats.triangleCount)}</span>
      </div>
      <div className="flex justify-between text-slate-300">
        <span>Bbox volume (est.)</span>
        <span>{formatVolume(stats.boundingBoxVolume, unit, 1)}</span>
      </div>
      <div className="flex justify-between text-slate-300">
        <span>Material volume (est.)</span>
        <span>{formatVolume(stats.materialVolume, unit, 1)}</span>
      </div>
      <div className="text-[10px] text-slate-500 pt-1">
        Volumes are heuristic estimates based on signed-tetrahedron summation
        and may differ from slicer estimates.
      </div>
    </div>
  );
}

export default function InspectorPanel() {
  return (
    <div className="w-full h-full bg-slate-900 border-l border-slate-700 flex flex-col">
      <Tabs defaultValue="tree" className="flex-1 flex flex-col">
        <TabsList className="bg-slate-950/50 border-b border-slate-700 rounded-none justify-start">
          <TabsTrigger value="tree">Tree</TabsTrigger>
          <TabsTrigger value="validate">Validate</TabsTrigger>
          <TabsTrigger value="orient">Orientation</TabsTrigger>
          <TabsTrigger value="stats">Stats</TabsTrigger>
        </TabsList>
        <ScrollArea className="flex-1">
          <TabsContent value="tree" className="p-2">
            <ObjectTree />
          </TabsContent>
          <TabsContent value="validate" className="p-2">
            <ValidationList />
          </TabsContent>
          <TabsContent value="orient" className="p-2">
            <PrintOrientation />
          </TabsContent>
          <TabsContent value="stats" className="p-2">
            <PrintStats />
          </TabsContent>
        </ScrollArea>
      </Tabs>
    </div>
  );
}
