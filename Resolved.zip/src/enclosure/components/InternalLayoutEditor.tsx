'use client';

/**
 * Internal Layout editor — controls battery, PCB orientation, screw mounts,
 * belt clip, strap slots. All parameters live-adjustable.
 */
import React from 'react';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import { Switch } from '@/components/ui/switch';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { useEnclosureStore } from '../store/enclosureStore';
import type { BatteryPcbArrangement, PcbOrientation, BatteryOrientation } from '../types';

function NumInput({ label, value, step = 0.1, min, onChange, placeholder }: {
  label: string; value: number | null | undefined; step?: number; min?: number;
  onChange: (v: number | null) => void; placeholder?: string;
}) {
  return (
    <div className="flex items-center gap-2">
      <Label className="text-[10px] text-slate-300 w-20 shrink-0">{label}</Label>
      <Input
        type="number" value={value ?? ''} step={step} min={min}
        onChange={e => { const v = parseFloat(e.target.value); onChange(isNaN(v) ? null : v); }}
        placeholder={placeholder ?? 'auto'}
        className="h-6 text-[10px] bg-slate-900 border-slate-700"
      />
    </div>
  );
}

export function InternalLayoutEditor() {
  const project = useEnclosureStore(s => s.project);
  const setInternalLayout = useEnclosureStore(s => s.setInternalLayout);
  const layout = project.internalLayout;

  if (!layout) {
    return (
      <div className="text-[10px] text-slate-500 italic">
        Internal layout not configured. Use the 7SEMI Safeguard template to enable it.
      </div>
    );
  }

  return (
    <div className="space-y-3">
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">PCB Orient</Label>
        <Select value={layout.pcbOrientation} onValueChange={v => setInternalLayout({ pcbOrientation: v as PcbOrientation })}>
          <SelectTrigger className="h-6 text-[10px] bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="horizontal">Horizontal (flat)</SelectItem>
            <SelectItem value="vertical">Vertical (standing)</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <div className="flex items-center gap-2">
        <Label className="text-[10px] text-slate-300 w-20 shrink-0">Arrange</Label>
        <Select value={layout.arrangement} onValueChange={v => setInternalLayout({ arrangement: v as BatteryPcbArrangement })}>
          <SelectTrigger className="h-6 text-[10px] bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="side-by-side">Side-by-side</SelectItem>
            <SelectItem value="stacked">Stacked</SelectItem>
            <SelectItem value="battery-only">Battery only</SelectItem>
            <SelectItem value="pcb-only">PCB only</SelectItem>
          </SelectContent>
        </Select>
      </div>
      <NumInput label="Gap (mm)" value={layout.batteryPcbGap} step={0.5} onChange={v => setInternalLayout({ batteryPcbGap: v ?? 5 })} />

      <div className="pl-2 border-l border-slate-700/50 space-y-1.5">
        <div className="text-[10px] text-slate-400 italic">Battery</div>
        <div className="flex items-center gap-2">
          <Label className="text-[10px] text-slate-300 w-20 shrink-0">Enabled</Label>
          <Switch
            checked={layout.battery?.enabled ?? false}
            onCheckedChange={b => setInternalLayout({
              battery: b ? { enabled: true, width: 60, depth: 110, height: 12, positionX: -20, positionY: 0, orientation: 'horizontal', wallThickness: 1.2 } : null,
            })}
          />
        </div>
        {layout.battery?.enabled && (
          <>
            <NumInput label="Width (mm)" value={layout.battery.width} step={1} onChange={v => setInternalLayout({ battery: { ...layout.battery!, width: v ?? 60 } })} />
            <NumInput label="Depth (mm)" value={layout.battery.depth} step={1} onChange={v => setInternalLayout({ battery: { ...layout.battery!, depth: v ?? 110 } })} />
            <NumInput label="Height (mm)" value={layout.battery.height} step={0.5} onChange={v => setInternalLayout({ battery: { ...layout.battery!, height: v ?? 12 } })} />
            <NumInput label="Pos X (mm)" value={layout.battery.positionX} step={1} onChange={v => setInternalLayout({ battery: { ...layout.battery!, positionX: v ?? 0 } })} />
            <NumInput label="Pos Y (mm)" value={layout.battery.positionY} step={1} onChange={v => setInternalLayout({ battery: { ...layout.battery!, positionY: v ?? 0 } })} />
            <div className="flex items-center gap-2">
              <Label className="text-[10px] text-slate-300 w-20 shrink-0">Batt Orient</Label>
              <Select value={layout.battery.orientation} onValueChange={v => setInternalLayout({ battery: { ...layout.battery!, orientation: v as BatteryOrientation } })}>
                <SelectTrigger className="h-6 text-[10px] bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="horizontal">Horizontal</SelectItem>
                  <SelectItem value="vertical">Vertical</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </>
        )}
      </div>

      <div className="pl-2 border-l border-slate-700/50 space-y-1.5">
        <div className="text-[10px] text-slate-400 italic">Screw Mounts</div>
        <div className="flex items-center gap-2">
          <Label className="text-[10px] text-slate-300 w-20 shrink-0">Start From</Label>
          <Select value={layout.screwMount.startFrom} onValueChange={v => setInternalLayout({ screwMount: { ...layout.screwMount, startFrom: v as 'top' | 'bottom' } })}>
            <SelectTrigger className="h-6 text-[10px] bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="bottom">Bottom (floor)</SelectItem>
              <SelectItem value="top">Top (lid side)</SelectItem>
            </SelectContent>
          </Select>
        </div>
        <NumInput label="Height (mm)" value={layout.screwMount.height} step={0.5} onChange={v => setInternalLayout({ screwMount: { ...layout.screwMount, height: v ?? 8 } })} />
        <NumInput label="Diameter" value={layout.screwMount.diameter} step={0.5} onChange={v => setInternalLayout({ screwMount: { ...layout.screwMount, diameter: v ?? 8 } })} />
        <NumInput label="Inset (mm)" value={layout.screwMount.inset} step={0.5} onChange={v => setInternalLayout({ screwMount: { ...layout.screwMount, inset: v ?? 6 } })} />
        <NumInput label="Hole Dia" value={layout.screwMount.holeDiameter} step={0.1} onChange={v => setInternalLayout({ screwMount: { ...layout.screwMount, holeDiameter: v ?? 3 } })} />
      </div>

      <NumInput label="Lid Panel H" value={layout.lidPanelHeight} step={0.5} onChange={v => setInternalLayout({ lidPanelHeight: v ?? 3 })} />

      <div className="pl-2 border-l border-slate-700/50 space-y-1.5">
        <div className="text-[10px] text-slate-400 italic">Back Features</div>
        <NumInput label="Belt Clip W" value={layout.beltClipWidth} step={1} onChange={v => setInternalLayout({ beltClipWidth: v ?? 0 })} />
        <NumInput label="Strap Slot W" value={layout.strapSlotWidth} step={1} onChange={v => setInternalLayout({ strapSlotWidth: v ?? 0 })} />
        <NumInput label="Strap Slot H" value={layout.strapSlotHeight} step={0.5} onChange={v => setInternalLayout({ strapSlotHeight: v ?? 6 })} />
      </div>
    </div>
  );
}
