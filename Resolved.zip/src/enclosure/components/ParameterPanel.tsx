'use client';

/**
 * Parameter panel (LEFT) — collapsible sections for every editable parameter
 * of the enclosure project.
 *
 * Uses shadcn/ui Accordion, Input, Select, Slider, Switch components.
 */
import React from 'react';
import { Plus, Trash2 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Slider } from '@/components/ui/slider';
import { Switch } from '@/components/ui/switch';
import {
  Accordion,
  AccordionItem,
  AccordionTrigger,
  AccordionContent,
} from '@/components/ui/accordion';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { useEnclosureStore } from '../store/enclosureStore';
import {
  CUTOUT_PRESETS,
  MATERIAL_PRESETS,
  SCREW_PRESETS,
} from '../types';
import type {
  CutoutFace,
  CutoutShape,
  LidType,
  MaterialType,
  ScrewSize,
  UnitSystem,
  ExportFormat,
  VentilationPattern,
  Decoration,
  TextDecoration,
  LogoDecoration,
  ShapeDecoration,
  DecorationShapeKind,
  FontFamily,
  TextAlign,
} from '../types';
import { uid } from '../utils/id';
import { DecorationsEditor } from './DecorationsEditor';
import { InternalLayoutEditor } from './InternalLayoutEditor';
import { CutoutEditor } from './CutoutEditor';

// Reusable number input row.
function NumInput({
  label,
  value,
  step = 0.1,
  min,
  max,
  onChange,
}: {
  label: string;
  value: number;
  step?: number;
  min?: number;
  max?: number;
  onChange: (v: number) => void;
}) {
  return (
    <div className="flex items-center gap-2">
      <Label className="text-xs text-slate-300 w-24 shrink-0">{label}</Label>
      <Input
        type="number"
        value={Number.isFinite(value) ? value : 0}
        step={step}
        min={min}
        max={max}
        onChange={e => {
          const v = parseFloat(e.target.value);
          onChange(isNaN(v) ? 0 : v);
        }}
        className="h-7 text-xs bg-slate-800 border-slate-700"
      />
    </div>
  );
}

function Section({
  title,
  children,
  value,
}: {
  title: string;
  children: React.ReactNode;
  value: string;
}) {
  return (
    <AccordionItem value={value}>
      <AccordionTrigger className="text-xs text-slate-200 px-3 hover:bg-slate-800/50">
        {title}
      </AccordionTrigger>
      <AccordionContent className="px-3 pb-4 pt-1 space-y-3 bg-slate-900/30">
        {children}
      </AccordionContent>
    </AccordionItem>
  );
}

export default function ParameterPanel() {
  const project = useEnclosureStore(s => s.project);
  const setDimensions = useEnclosureStore(s => s.setDimensions);
  const setLid = useEnclosureStore(s => s.setLid);
  const setScrew = useEnclosureStore(s => s.setScrew);
  const addCutout = useEnclosureStore(s => s.addCutout);
  const removeCutout = useEnclosureStore(s => s.removeCutout);
  const addPCB = useEnclosureStore(s => s.addPCB);
  const removePCB = useEnclosureStore(s => s.removePCB);
  const setVentilation = useEnclosureStore(s => s.setVentilation);
  const setSnapFit = useEnclosureStore(s => s.setSnapFit);
  const setHinge = useEnclosureStore(s => s.setHinge);
  const setFeet = useEnclosureStore(s => s.setFeet);
  const setInternalSupport = useEnclosureStore(s => s.setInternalSupport);
  const addLabel = useEnclosureStore(s => s.addLabel);
  const removeLabel = useEnclosureStore(s => s.removeLabel);
  const setMaterial = useEnclosureStore(s => s.setMaterial);
  const setSettings = useEnclosureStore(s => s.setSettings);
  const renameProject = useEnclosureStore(s => s.renameProject);

  return (
    <div className="w-full h-full bg-slate-900 border-r border-slate-700 flex flex-col">
      <div className="px-3 py-2 border-b border-slate-700 bg-slate-950/50 shrink-0">
        <div className="flex items-center gap-2">
          <Input
            value={project.name}
            onChange={e => renameProject(e.target.value)}
            className="h-7 text-xs bg-slate-800 border-slate-700"
            placeholder="Project name"
          />
        </div>
      </div>
      <div className="flex-1 overflow-y-auto min-h-0">
        <Accordion type="multiple" defaultValue={['dims']} className="px-1">
          {/* Dimensions */}
          <Section title="Dimensions" value="dims">
            <NumInput label="Width (mm)" value={project.dimensions.width} step={1} onChange={v => setDimensions({ width: v })} />
            <NumInput label="Depth (mm)" value={project.dimensions.depth} step={1} onChange={v => setDimensions({ depth: v })} />
            <NumInput label="Height (mm)" value={project.dimensions.height} step={1} onChange={v => setDimensions({ height: v })} />
            <NumInput label="Wall (mm)" value={project.dimensions.wallThickness} step={0.1} onChange={v => setDimensions({ wallThickness: v })} />
            <NumInput label="Floor (mm)" value={project.dimensions.floorThickness} step={0.1} onChange={v => setDimensions({ floorThickness: v })} />
            <NumInput label="Corner r" value={project.dimensions.cornerRadius} step={0.5} onChange={v => setDimensions({ cornerRadius: v })} />
            <NumInput label="Edge Bevel" value={project.dimensions.edgeBevel ?? 0} step={0.5} onChange={v => setDimensions({ edgeBevel: v ?? 0 })} />
            <NumInput label="Draft°" value={project.dimensions.draftAngle ?? 0} step={0.5} onChange={v => setDimensions({ draftAngle: v ?? 0 })} />
          </Section>

          {/* Lid */}
          <Section title="Lid" value="lid">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Type</Label>
              <Select value={project.lid.type} onValueChange={v => setLid({ type: v as LidType })}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="flat-removable">Flat removable</SelectItem>
                  <SelectItem value="screw">Screw</SelectItem>
                  <SelectItem value="captive-screw">Captive screw</SelectItem>
                  <SelectItem value="snap-fit">Snap-fit</SelectItem>
                  <SelectItem value="sliding">Sliding</SelectItem>
                  <SelectItem value="hinged">Hinged</SelectItem>
                  <SelectItem value="none">None</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <NumInput label="Thickness" value={project.lid.thickness} step={0.1} onChange={v => setLid({ thickness: v })} />
            <NumInput label="Clearance" value={project.lid.clearance} step={0.05} onChange={v => setLid({ clearance: v })} />
            <NumInput label="Screw spacing" value={project.lid.screwSpacing} step={1} onChange={v => setLid({ screwSpacing: v })} />
            <NumInput label="Hinge size" value={project.lid.hingeSize} step={0.5} onChange={v => setLid({ hingeSize: v })} />
            <NumInput label="Snap tol" value={project.lid.snapFitTolerance} step={0.05} onChange={v => setLid({ snapFitTolerance: v })} />
            <div className="flex items-center gap-2 pt-1">
              <Label className="text-xs text-slate-300">Visible</Label>
              <Switch checked={project.lid.visible} onCheckedChange={b => setLid({ visible: b })} />
            </div>
          </Section>

          {/* Screw */}
          <Section title="Screw" value="screw">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Size</Label>
              <Select
                value={project.screw.size}
                onValueChange={v => {
                  const size = v as ScrewSize;
                  if (size === 'custom') {
                    setScrew({ size: 'custom' });
                  } else {
                    setScrew({ size, ...SCREW_PRESETS[size] });
                  }
                }}
              >
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="M2">M2</SelectItem>
                  <SelectItem value="M2.5">M2.5</SelectItem>
                  <SelectItem value="M3">M3</SelectItem>
                  <SelectItem value="M4">M4</SelectItem>
                  <SelectItem value="M5">M5</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <NumInput label="Thread Ø" value={project.screw.threadDiameter} step={0.1} onChange={v => setScrew({ threadDiameter: v })} />
            <NumInput label="Clearance Ø" value={project.screw.clearanceHole} step={0.1} onChange={v => setScrew({ clearanceHole: v })} />
            <NumInput label="Head Ø" value={project.screw.headDiameter} step={0.1} onChange={v => setScrew({ headDiameter: v })} />
            <NumInput label="Head H" value={project.screw.headHeight} step={0.1} onChange={v => setScrew({ headHeight: v })} />
            <div className="text-[10px] text-slate-500 pt-1">
              Note: Threads are not modeled. Use self-tapping or thread-forming screws.
            </div>
          </Section>

          {/* Cutouts */}
          <Section title="Cutouts" value="cutouts">
            <CutoutEditor />
          </Section>

          {/* PCBs */}
          <Section title="PCBs" value="pcbs">
            <Button
              variant="outline"
              size="sm"
              className="w-full h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
              onClick={() => addPCB()}
            >
              <Plus size={12} className="mr-1" /> Add PCB
            </Button>
            <div className="space-y-2">
              {project.pcbs.map(p => (
                <div key={p.id} className="rounded bg-slate-800/50 p-2 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-200">{p.name}</span>
                    <div className="flex items-center gap-1">
                      <Button variant="ghost" size="icon" className="size-5 text-slate-400 hover:text-amber-400"
                        onClick={() => {
                          const store = useEnclosureStore.getState();
                          store.updatePCB(p.id, {
                            mountingHoles: [...p.mountingHoles, { id: uid('hole'), x: 0, y: 0, diameter: 2.4 }]
                          });
                        }}>
                        <Plus size={10} />
                      </Button>
                      <Button variant="ghost" size="icon" className="size-5 text-slate-400 hover:text-red-400"
                        onClick={() => removePCB(p.id)}>
                        <Trash2 size={10} />
                      </Button>
                    </div>
                  </div>
                  <Input
                    value={p.name}
                    onChange={e => useEnclosureStore.getState().updatePCB(p.id, { name: e.target.value })}
                    className="h-6 text-[10px] bg-slate-900 border-slate-700"
                  />
                  <NumInput label="Width (mm)" value={p.width} step={1} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { width: v })} />
                  <NumInput label="Height (mm)" value={p.height} step={1} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { height: v })} />
                  <NumInput label="Thickness" value={p.thickness} step={0.1} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { thickness: v })} />
                  <NumInput label="Pos Z (mm)" value={p.positionZ} step={0.5} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { positionZ: v })} />
                  <NumInput label="Standoff H" value={p.standoffHeight} step={0.5} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { standoffHeight: v })} />
                  <NumInput label="Standoff Ø" value={p.standoffDiameter} step={0.5} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { standoffDiameter: v })} />
                  <NumInput label="Hole Ø" value={p.standoffHoleDiameter} step={0.1} onChange={v => useEnclosureStore.getState().updatePCB(p.id, { standoffHoleDiameter: v })} />
                  <div className="flex items-center gap-2">
                    <Label className="text-[10px] text-slate-300 w-24 shrink-0">Visible</Label>
                    <Switch checked={p.visible} onCheckedChange={b => useEnclosureStore.getState().updatePCB(p.id, { visible: b })} />
                  </div>
                  {/* Mounting holes editor */}
                  <div className="pl-2 border-l border-slate-700/50 space-y-1.5">
                    <div className="text-[9px] text-slate-500 italic">Mounting Holes ({p.mountingHoles.length})</div>
                    {p.mountingHoles.map((h, hi) => (
                      <div key={h.id} className="flex items-center gap-1">
                        <span className="text-[9px] text-slate-400 w-6">{hi + 1}.</span>
                        <Input type="number" value={h.x} step={0.5}
                          onChange={e => {
                            const holes = [...p.mountingHoles];
                            holes[hi] = { ...h, x: parseFloat(e.target.value) || 0 };
                            useEnclosureStore.getState().updatePCB(p.id, { mountingHoles: holes });
                          }}
                          className="h-5 w-12 text-[9px] bg-slate-900 border-slate-700 px-1" placeholder="X" />
                        <Input type="number" value={h.y} step={0.5}
                          onChange={e => {
                            const holes = [...p.mountingHoles];
                            holes[hi] = { ...h, y: parseFloat(e.target.value) || 0 };
                            useEnclosureStore.getState().updatePCB(p.id, { mountingHoles: holes });
                          }}
                          className="h-5 w-12 text-[9px] bg-slate-900 border-slate-700 px-1" placeholder="Y" />
                        <Input type="number" value={h.diameter} step={0.1}
                          onChange={e => {
                            const holes = [...p.mountingHoles];
                            holes[hi] = { ...h, diameter: parseFloat(e.target.value) || 2.4 };
                            useEnclosureStore.getState().updatePCB(p.id, { mountingHoles: holes });
                          }}
                          className="h-5 w-12 text-[9px] bg-slate-900 border-slate-700 px-1" placeholder="Ø" />
                        <Button variant="ghost" size="icon" className="size-4 text-slate-400 hover:text-red-400"
                          onClick={() => {
                            useEnclosureStore.getState().updatePCB(p.id, {
                              mountingHoles: p.mountingHoles.filter((_, i) => i !== hi)
                            });
                          }}>
                          <Trash2 size={8} />
                        </Button>
                      </div>
                    ))}
                    <Button variant="ghost" size="sm" className="h-5 text-[9px] text-slate-400 hover:text-amber-400 w-full"
                      onClick={() => {
                        useEnclosureStore.getState().updatePCB(p.id, {
                          mountingHoles: [...p.mountingHoles, { id: uid('hole'), x: 0, y: 0, diameter: 2.4 }]
                        });
                      }}>
                      <Plus size={8} className="mr-1" /> Add Hole
                    </Button>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Ventilation */}
          <Section title="Ventilation" value="vent">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Pattern</Label>
              <Select value={project.ventilation.pattern} onValueChange={v => setVentilation({ pattern: v as VentilationPattern })}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="none">None</SelectItem>
                  <SelectItem value="horizontal-slots">Horizontal slots</SelectItem>
                  <SelectItem value="vertical-slots">Vertical slots</SelectItem>
                  <SelectItem value="circular-holes">Circular holes</SelectItem>
                  <SelectItem value="honeycomb">Honeycomb</SelectItem>
                  <SelectItem value="grid">Grid</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Face</Label>
              <Select value={project.ventilation.face} onValueChange={v => setVentilation({ face: v as CutoutFace })}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="front">Front</SelectItem>
                  <SelectItem value="back">Back</SelectItem>
                  <SelectItem value="left">Left</SelectItem>
                  <SelectItem value="right">Right</SelectItem>
                  <SelectItem value="top">Top</SelectItem>
                  <SelectItem value="bottom">Bottom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <NumInput label="Slot width" value={project.ventilation.slotWidth} step={0.5} onChange={v => setVentilation({ slotWidth: v })} />
            <NumInput label="Slot height" value={project.ventilation.slotHeight} step={0.5} onChange={v => setVentilation({ slotHeight: v })} />
            <NumInput label="Rows" value={project.ventilation.rows} step={1} onChange={v => setVentilation({ rows: Math.round(v) })} />
            <NumInput label="Columns" value={project.ventilation.columns} step={1} onChange={v => setVentilation({ columns: Math.round(v) })} />
            <NumInput label="Border" value={project.ventilation.borderDistance} step={0.5} onChange={v => setVentilation({ borderDistance: v })} />
            <NumInput label="Cell radius" value={project.ventilation.cellRadius} step={0.5} onChange={v => setVentilation({ cellRadius: v })} />
            <div className="flex items-center gap-2 pt-1">
              <Label className="text-xs text-slate-300">Visible</Label>
              <Switch checked={project.ventilation.visible} onCheckedChange={b => setVentilation({ visible: b })} />
            </div>
          </Section>

          {/* Snap-fit */}
          <Section title="Snap Fit" value="snap">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Enabled</Label>
              <Switch checked={project.snapFit.enabled} onCheckedChange={b => setSnapFit({ enabled: b })} />
            </div>
            <NumInput label="Arm length" value={project.snapFit.armLength} step={0.5} onChange={v => setSnapFit({ armLength: v })} />
            <NumInput label="Arm thick" value={project.snapFit.armThickness} step={0.1} onChange={v => setSnapFit({ armThickness: v })} />
            <NumInput label="Hook H" value={project.snapFit.hookHeight} step={0.1} onChange={v => setSnapFit({ hookHeight: v })} />
            <NumInput label="Clearance" value={project.snapFit.clearance} step={0.05} onChange={v => setSnapFit({ clearance: v })} />
            <NumInput label="Count" value={project.snapFit.count} step={1} onChange={v => setSnapFit({ count: Math.round(v) })} />
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Direction</Label>
              <Select value={project.snapFit.flexDirection} onValueChange={v => setSnapFit({ flexDirection: v as 'x' | 'y' })}>
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="x">Along X</SelectItem>
                  <SelectItem value="y">Along Y</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Section>

          {/* Hinge */}
          <Section title="Hinge" value="hinge">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Enabled</Label>
              <Switch checked={project.hinge.enabled} onCheckedChange={b => setHinge({ enabled: b })} />
            </div>
            <NumInput label="Size" value={project.hinge.size} step={0.5} onChange={v => setHinge({ size: v })} />
            <NumInput label="Count" value={project.hinge.count} step={1} onChange={v => setHinge({ count: Math.round(v) })} />
          </Section>

          {/* Feet */}
          <Section title="Feet" value="feet">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Enabled</Label>
              <Switch checked={project.feet.enabled} onCheckedChange={b => setFeet({ enabled: b })} />
            </div>
            <NumInput label="Diameter" value={project.feet.diameter} step={0.5} onChange={v => setFeet({ diameter: v })} />
            <NumInput label="Height" value={project.feet.height} step={0.1} onChange={v => setFeet({ height: v })} />
            <NumInput label="Count" value={project.feet.count} step={1} onChange={v => setFeet({ count: Math.round(v) })} />
          </Section>

          {/* Internal support */}
          <Section title="Internal Support" value="support">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Enabled</Label>
              <Switch checked={project.internalSupport.enabled} onCheckedChange={b => setInternalSupport({ enabled: b })} />
            </div>
            <NumInput label="Diameter" value={project.internalSupport.diameter} step={0.5} onChange={v => setInternalSupport({ diameter: v })} />
            <NumInput label="Spacing" value={project.internalSupport.spacing} step={1} onChange={v => setInternalSupport({ spacing: v })} />
          </Section>

          {/* Internal Layout */}
          <Section title="Internal Layout" value="layout">
            <InternalLayoutEditor />
          </Section>

          {/* Labels */}
          <Section title="Labels" value="labels">
            <Button
              variant="outline"
              size="sm"
              className="w-full h-7 text-[10px] bg-slate-800 border-slate-700 text-slate-200 hover:bg-slate-700"
              onClick={() => addLabel()}
            >
              <Plus size={12} className="mr-1" /> Add Label
            </Button>
            <div className="space-y-2">
              {project.labels.map((l, idx) => (
                <div key={idx} className="rounded bg-slate-800/50 p-2 space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="text-[10px] text-slate-200">{l.text || 'Label'}</span>
                    <Button
                      variant="ghost"
                      size="icon"
                      className="size-5 text-slate-400 hover:text-red-400"
                      onClick={() => removeLabel(idx)}
                    >
                      <Trash2 size={10} />
                    </Button>
                  </div>
                  <Input
                    value={l.text}
                    onChange={e => {
                      const labels = [...project.labels];
                      labels[idx] = { ...l, text: e.target.value };
                      useEnclosureStore.setState(s => ({ project: { ...s.project, labels }, dirty: true }));
                    }}
                    className="h-6 text-[10px] bg-slate-900 border-slate-700"
                    placeholder="Label text"
                  />
                  <NumInput label="Size (mm)" value={l.size} step={0.5} onChange={v => {
                    const labels = [...project.labels];
                    labels[idx] = { ...l, size: v };
                    useEnclosureStore.setState(s => ({ project: { ...s.project, labels }, dirty: true }));
                  }} />
                  <div className="flex items-center gap-2">
                    <Label className="text-xs text-slate-300 w-24 shrink-0">Face</Label>
                    <Select
                      value={l.face}
                      onValueChange={v => {
                        const labels = [...project.labels];
                        labels[idx] = { ...l, face: v as CutoutFace };
                        useEnclosureStore.setState(s => ({ project: { ...s.project, labels }, dirty: true }));
                      }}
                    >
                      <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="front">Front</SelectItem>
                        <SelectItem value="back">Back</SelectItem>
                        <SelectItem value="left">Left</SelectItem>
                        <SelectItem value="right">Right</SelectItem>
                        <SelectItem value="top">Top</SelectItem>
                        <SelectItem value="bottom">Bottom</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              ))}
            </div>
          </Section>

          {/* Decorations: Text / Logo / Shape */}
          <Section title="Decorations" value="decorations">
            <DecorationsEditor />
          </Section>

          {/* Material */}
          <Section title="Material" value="material">
            <div className="grid grid-cols-3 gap-1">
              {(Object.keys(MATERIAL_PRESETS) as MaterialType[]).map(m => {
                const preset = MATERIAL_PRESETS[m];
                const active = project.material === m;
                return (
                  <button
                    key={m}
                    onClick={() => setMaterial(m)}
                    className={`rounded p-2 text-[10px] flex flex-col items-center gap-1 border transition-colors ${
                      active
                        ? 'border-amber-400 bg-slate-800'
                        : 'border-slate-700 hover:border-slate-500 bg-slate-800/50'
                    }`}
                  >
                    <div
                      className="size-4 rounded-full"
                      style={{ background: preset.color }}
                    />
                    <span className="text-slate-300">{m}</span>
                  </button>
                );
              })}
            </div>
            <div className="text-[10px] text-slate-500 pt-1">
              Material color is visualization only and does not imply mechanical properties.
            </div>
          </Section>

          {/* Settings */}
          <Section title="Settings" value="settings">
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Units</Label>
              <Select
                value={project.settings.unit}
                onValueChange={v => setSettings({ unit: v as UnitSystem })}
              >
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="mm">mm</SelectItem>
                  <SelectItem value="cm">cm</SelectItem>
                  <SelectItem value="in">in</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <NumInput label="Grid size" value={project.settings.gridSize} step={1} onChange={v => setSettings({ gridSize: v })} />
            <NumInput label="Snap size" value={project.settings.snapSize} step={0.5} onChange={v => setSettings({ snapSize: v })} />
            <NumInput label="Default wall" value={project.settings.defaultWallThickness} step={0.1} onChange={v => setSettings({ defaultWallThickness: v })} />
            <NumInput label="Default clearance" value={project.settings.defaultClearance} step={0.05} onChange={v => setSettings({ defaultClearance: v })} />
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Screw</Label>
              <Select
                value={project.settings.defaultScrew}
                onValueChange={v => setSettings({ defaultScrew: v as ScrewSize })}
              >
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="M2">M2</SelectItem>
                  <SelectItem value="M2.5">M2.5</SelectItem>
                  <SelectItem value="M3">M3</SelectItem>
                  <SelectItem value="M4">M4</SelectItem>
                  <SelectItem value="M5">M5</SelectItem>
                  <SelectItem value="custom">Custom</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Export</Label>
              <Select
                value={project.settings.defaultExportFormat}
                onValueChange={v => setSettings({ defaultExportFormat: v as ExportFormat })}
              >
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="stl-binary">STL (binary)</SelectItem>
                  <SelectItem value="stl-ascii">STL (ASCII)</SelectItem>
                  <SelectItem value="obj">OBJ</SelectItem>
                  <SelectItem value="3mf">3MF</SelectItem>
                  <SelectItem value="ply">PLY</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Theme</Label>
              <Select
                value={project.settings.theme}
                onValueChange={v => setSettings({ theme: v as 'dark' | 'light' })}
              >
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="dark">Dark</SelectItem>
                  <SelectItem value="light">Light</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div className="flex items-center gap-2">
              <Label className="text-xs text-slate-300 w-24 shrink-0">Accent</Label>
              <Select
                value={project.settings.themeColor ?? 'orange'}
                onValueChange={v => setSettings({ themeColor: v as 'orange' | 'blue' | 'navy' | 'green' })}
              >
                <SelectTrigger className="h-7 text-xs bg-slate-800 border-slate-700">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="orange">Orange & White</SelectItem>
                  <SelectItem value="blue">Blue & White</SelectItem>
                  <SelectItem value="navy">Navy & White</SelectItem>
                  <SelectItem value="green">Green & White</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </Section>
        </Accordion>
      </div>
    </div>
  );
}
