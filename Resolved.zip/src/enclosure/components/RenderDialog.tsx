'use client';

import React from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription, DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import {
  Select, SelectTrigger, SelectValue, SelectContent, SelectItem,
} from '@/components/ui/select';
import { ImageIcon, Loader2 } from 'lucide-react';
import { useEnclosureStore } from '../store/enclosureStore';
import { renderProjectImage, renderFileName, type RenderViewMode, type RenderBackground, type RenderResolution } from '../render/renderImage';
import { downloadBlob } from '../utils/download';
import { toast } from 'sonner';

interface Props { open: boolean; onClose: () => void; }

export default function RenderDialog({ open, onClose }: Props) {
  const project = useEnclosureStore(s => s.project);
  const [view, setView] = React.useState<RenderViewMode>('external');
  const [background, setBackground] = React.useState<RenderBackground>('studio');
  const [resolution, setResolution] = React.useState<RenderResolution>('1080p');
  const [rendering, setRendering] = React.useState(false);

  const handleRender = async () => {
    setRendering(true);
    try {
      const blob = await renderProjectImage(project, { view, background, resolution, useMaterialColors: true });
      const name = renderFileName(project, { view, background, resolution, useMaterialColors: true });
      downloadBlob(blob, name);
      toast.success(`Rendered: ${name}`);
      onClose();
    } catch (err) {
      toast.error(`Render failed: ${err instanceof Error ? err.message : String(err)}`);
    } finally { setRendering(false); }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-700 text-slate-100 max-w-lg">
        <DialogHeader>
          <DialogTitle>Render Image</DialogTitle>
          <DialogDescription className="text-slate-400">
            Produce a high-quality PNG render showing how the enclosure will look after 3D printing.
          </DialogDescription>
        </DialogHeader>
        <div className="space-y-4">
          <div className="flex items-center gap-3">
            <Label className="text-sm w-28 shrink-0">View</Label>
            <Select value={view} onValueChange={v => setView(v as RenderViewMode)}>
              <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="external">External (assembled)</SelectItem>
                <SelectItem value="internal">Internal (cross-section)</SelectItem>
                <SelectItem value="exploded">Exploded (all parts)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-3">
            <Label className="text-sm w-28 shrink-0">Background</Label>
            <Select value={background} onValueChange={v => setBackground(v as RenderBackground)}>
              <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="transparent">Transparent</SelectItem>
                <SelectItem value="white">White</SelectItem>
                <SelectItem value="dark">Dark</SelectItem>
                <SelectItem value="studio">Studio (slate)</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <div className="flex items-center gap-3">
            <Label className="text-sm w-28 shrink-0">Resolution</Label>
            <Select value={resolution} onValueChange={v => setResolution(v as RenderResolution)}>
              <SelectTrigger className="bg-slate-800 border-slate-700"><SelectValue /></SelectTrigger>
              <SelectContent>
                <SelectItem value="720p">720p (1280×720)</SelectItem>
                <SelectItem value="1080p">1080p (1920×1080)</SelectItem>
                <SelectItem value="4k">4K (3840×2160)</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>
        <DialogFooter>
          <Button variant="ghost" onClick={onClose} disabled={rendering}>Cancel</Button>
          <Button onClick={handleRender} disabled={rendering}>
            {rendering ? <Loader2 size={14} className="mr-1 animate-spin" /> : <ImageIcon size={14} className="mr-1" />}
            {rendering ? 'Rendering...' : 'Render'}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
