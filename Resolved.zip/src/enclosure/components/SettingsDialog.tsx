'use client';

/**
 * Settings dialog.
 *
 * Wraps the settings state in the store (ApplicationSettings). The settings
 * are already editable in the parameter panel — this dialog is a shortcut to
 * quickly change unit, theme, grid, snap, defaults.
 */
import React from 'react';
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogDescription,
  DialogFooter,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectTrigger,
  SelectValue,
  SelectContent,
  SelectItem,
} from '@/components/ui/select';
import { Switch } from '@/components/ui/switch';
import { useEnclosureStore } from '../store/enclosureStore';
import type { UnitSystem, ScrewSize, ExportFormat } from '../types';

interface Props {
  open: boolean;
  onClose: () => void;
}

export default function SettingsDialog({ open, onClose }: Props) {
  const project = useEnclosureStore(s => s.project);
  const setSettings = useEnclosureStore(s => s.setSettings);
  const showGrid = useEnclosureStore(s => s.showGrid);
  const showAxes = useEnclosureStore(s => s.showAxes);
  const showBoundingBox = useEnclosureStore(s => s.showBoundingBox);
  const setShowGrid = useEnclosureStore(s => s.setShowGrid);
  const setShowAxes = useEnclosureStore(s => s.setShowAxes);
  const setShowBoundingBox = useEnclosureStore(s => s.setShowBoundingBox);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-700 text-slate-100">
        <DialogHeader>
          <DialogTitle>Settings</DialogTitle>
          <DialogDescription className="text-slate-400">
            Application preferences. Changes are saved to the project file.
          </DialogDescription>
        </DialogHeader>

        <div className="space-y-3">
          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Units</Label>
            <Select
              value={project.settings.unit}
              onValueChange={v => setSettings({ unit: v as UnitSystem })}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="mm">mm</SelectItem>
                <SelectItem value="cm">cm</SelectItem>
                <SelectItem value="in">in</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Grid size</Label>
            <Input
              type="number"
              value={project.settings.gridSize}
              onChange={e => setSettings({ gridSize: parseFloat(e.target.value) || 1 })}
              className="bg-slate-800 border-slate-700"
            />
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Snap size</Label>
            <Input
              type="number"
              value={project.settings.snapSize}
              onChange={e => setSettings({ snapSize: parseFloat(e.target.value) || 0.5 })}
              className="bg-slate-800 border-slate-700"
            />
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Default wall</Label>
            <Input
              type="number"
              value={project.settings.defaultWallThickness}
              onChange={e => setSettings({ defaultWallThickness: parseFloat(e.target.value) || 1 })}
              className="bg-slate-800 border-slate-700"
            />
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Default clearance</Label>
            <Input
              type="number"
              value={project.settings.defaultClearance}
              onChange={e => setSettings({ defaultClearance: parseFloat(e.target.value) || 0.2 })}
              className="bg-slate-800 border-slate-700"
            />
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Default screw</Label>
            <Select
              value={project.settings.defaultScrew}
              onValueChange={v => setSettings({ defaultScrew: v as ScrewSize })}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="M2">M2</SelectItem>
                <SelectItem value="M2.5">M2.5</SelectItem>
                <SelectItem value="M3">M3</SelectItem>
                <SelectItem value="M4">M4</SelectItem>
                <SelectItem value="M5">M5</SelectItem>
                <SelectItem value="custom">Custom</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Default export</Label>
            <Select
              value={project.settings.defaultExportFormat}
              onValueChange={v => setSettings({ defaultExportFormat: v as ExportFormat })}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="stl-binary">STL (binary)</SelectItem>
                <SelectItem value="stl-ascii">STL (ASCII)</SelectItem>
                <SelectItem value="obj">OBJ + MTL</SelectItem>
                <SelectItem value="3mf">3MF</SelectItem>
                <SelectItem value="ply">PLY</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="flex items-center gap-3">
            <Label className="text-sm w-32 shrink-0">Theme</Label>
            <Select
              value={project.settings.theme}
              onValueChange={v => setSettings({ theme: v as 'dark' | 'light' })}
            >
              <SelectTrigger className="bg-slate-800 border-slate-700">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="dark">Dark</SelectItem>
                <SelectItem value="light">Light</SelectItem>
              </SelectContent>
            </Select>
          </div>

          <div className="border-t border-slate-700 pt-3 space-y-2">
            <Label className="text-xs uppercase text-slate-500">Viewport</Label>
            <div className="flex items-center gap-3">
              <Switch checked={showGrid} onCheckedChange={setShowGrid} id="grid" />
              <Label htmlFor="grid" className="text-sm">Show grid</Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={showAxes} onCheckedChange={setShowAxes} id="axes" />
              <Label htmlFor="axes" className="text-sm">Show axes</Label>
            </div>
            <div className="flex items-center gap-3">
              <Switch checked={showBoundingBox} onCheckedChange={setShowBoundingBox} id="bbox" />
              <Label htmlFor="bbox" className="text-sm">Show bounding box</Label>
            </div>
          </div>
        </div>

        <DialogFooter>
          <Button onClick={onClose}>Close</Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
