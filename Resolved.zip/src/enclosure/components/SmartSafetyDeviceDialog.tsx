'use client';

/**
 * Smart Safety Harness Device Module — dedicated industrial IoT dashboard.
 *
 * Shows:
 *   1. Device Overview (status, device ID, battery, signal)
 *   2. 3D Device Structure (component list with details)
 *   3. Device Dimensions (111 × 68 × 32 mm)
 *   4. 3D Printing Specifications
 *   5. Assembly (exploded view order)
 *   6. 3D Files (STL list with download/view status)
 *
 * Follows the existing app's design system: dark mode, shadcn/ui components,
 * amber accent color, monospace for technical data.
 */
import React, { useState } from 'react';
import {
  Dialog, DialogContent, DialogHeader, DialogTitle, DialogDescription,
} from '@/components/ui/dialog';
import { Button } from '@/components/ui/button';
import { Label } from '@/components/ui/label';
import { ScrollArea } from '@/components/ui/scroll-area';
import {
  Shield, Cpu, Box, Wrench, Download, Eye, Layers,
  CheckCircle2, AlertCircle, Battery, Wifi, Activity, Clock,
} from 'lucide-react';
import {
  SAFETY_DEVICE_COMPONENTS, DEVICE_DIMENSIONS, PRINT_SPECS,
  ASSEMBLY_ORDER, DEVICE_VIEWS, type SafetyDeviceComponent,
} from '../smart-safety-device/data';

interface Props {
  open: boolean;
  onClose: () => void;
}

const CATEGORY_ICONS: Record<string, React.ReactNode> = {
  enclosure: <Box size={14} />,
  mechanical: <Wrench size={14} />,
  electronic: <Cpu size={14} />,
  fastener: <Shield size={14} />,
};

const CATEGORY_COLORS: Record<string, string> = {
  enclosure: 'text-blue-400',
  mechanical: 'text-amber-400',
  electronic: 'text-emerald-400',
  fastener: 'text-purple-400',
};

export default function SmartSafetyDeviceDialog({ open, onClose }: Props) {
  const [selectedComponent, setSelectedComponent] = useState<SafetyDeviceComponent | null>(null);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="bg-slate-900 border-slate-700 text-slate-100 max-w-5xl max-h-[90vh] overflow-hidden">
        <DialogHeader>
          <DialogTitle className="text-lg font-bold flex items-center gap-2">
            <Shield size={20} className="text-amber-400" />
            Smart Safety Harness Device
          </DialogTitle>
          <DialogDescription className="text-slate-400">
            Rugged wearable IoT safety device — 3D-printable enclosure module.
            Dimensions: {DEVICE_DIMENSIONS.height} × {DEVICE_DIMENSIONS.width} × {DEVICE_DIMENSIONS.depth} mm.
          </DialogDescription>
        </DialogHeader>

        <div className="flex-1 overflow-y-auto min-h-0 max-h-[75vh] pr-2 space-y-6">

          {/* === DEVICE OVERVIEW === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2 flex items-center gap-1">
              <Activity size={12} /> Device Overview
            </h3>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-2">
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                <div className="flex items-center gap-1 text-[10px] text-slate-500 uppercase">Status</div>
                <div className="flex items-center gap-1 mt-1">
                  <CheckCircle2 size={14} className="text-emerald-400" />
                  <span className="text-xs text-emerald-400">Connected</span>
                </div>
              </div>
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                <div className="text-[10px] text-slate-500 uppercase">Device ID</div>
                <div className="text-xs text-slate-200 font-mono mt-1">SSHD-0001</div>
              </div>
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                <div className="flex items-center gap-1 text-[10px] text-slate-500 uppercase">
                  <Battery size={10} /> Battery
                </div>
                <div className="text-xs text-slate-200 mt-1">Not specified</div>
              </div>
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3">
                <div className="flex items-center gap-1 text-[10px] text-slate-500 uppercase">
                  <Wifi size={10} /> Signal
                </div>
                <div className="text-xs text-slate-200 mt-1">Not specified</div>
              </div>
            </div>
          </section>

          {/* === DEVICE DIMENSIONS === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2">Device Dimensions</h3>
            <div className="grid grid-cols-3 gap-2">
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3 text-center">
                <div className="text-[10px] text-slate-500 uppercase">Height</div>
                <div className="text-lg font-mono text-slate-200">{DEVICE_DIMENSIONS.height} mm</div>
              </div>
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3 text-center">
                <div className="text-[10px] text-slate-500 uppercase">Width</div>
                <div className="text-lg font-mono text-slate-200">{DEVICE_DIMENSIONS.width} mm</div>
              </div>
              <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-3 text-center">
                <div className="text-[10px] text-slate-500 uppercase">Depth</div>
                <div className="text-lg font-mono text-slate-200">{DEVICE_DIMENSIONS.depth} mm</div>
              </div>
            </div>
          </section>

          {/* === 3D DEVICE STRUCTURE === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2 flex items-center gap-1">
              <Layers size={12} /> 3D Device Structure
            </h3>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
              {SAFETY_DEVICE_COMPONENTS.map(comp => (
                <div
                  key={comp.id}
                  className={`rounded-lg border p-2 cursor-pointer transition-colors ${
                    selectedComponent?.id === comp.id
                      ? 'bg-amber-900/20 border-amber-600'
                      : 'bg-slate-800/50 border-slate-700 hover:bg-slate-800/70'
                  }`}
                  onClick={() => setSelectedComponent(comp)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <span className={CATEGORY_COLORS[comp.category]}>{CATEGORY_ICONS[comp.category]}</span>
                      <span className="text-xs text-slate-200">{comp.name}</span>
                    </div>
                    {comp.filename && (
                      <span className="text-[9px] text-slate-500 font-mono">{comp.filename}</span>
                    )}
                  </div>
                  {selectedComponent?.id === comp.id && (
                    <div className="mt-2 space-y-1 text-[10px] text-slate-400">
                      <div><span className="text-slate-500">Purpose:</span> {comp.purpose}</div>
                      <div><span className="text-slate-500">Shape:</span> {comp.shape}</div>
                      <div><span className="text-slate-500">Dimensions:</span> {comp.dimensions}</div>
                      <div><span className="text-slate-500">Material:</span> {comp.material}</div>
                      <div><span className="text-slate-500">Supports:</span> {comp.supportsRequired ? 'Yes' : 'No'}</div>
                      <div><span className="text-slate-500">Assembly Order:</span> #{comp.assemblyOrder}</div>
                    </div>
                  )}
                </div>
              ))}
            </div>
          </section>

          {/* === 3D PRINTING === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2">3D Printing Specifications</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              <SpecCard label="Material" value={PRINT_SPECS.material} />
              <SpecCard label="Layer Height" value={PRINT_SPECS.layerHeight} />
              <SpecCard label="Infill" value={PRINT_SPECS.infill} />
              <SpecCard label="Wall Thickness" value={PRINT_SPECS.wallThickness} />
              <SpecCard label="Top/Bottom" value={PRINT_SPECS.topBottomThickness} />
              <SpecCard label="Supports" value={PRINT_SPECS.supports} />
            </div>
            <div className="mt-2 rounded-lg bg-slate-800/50 border border-slate-700 p-2">
              <div className="flex items-center gap-2">
                <Wrench size={12} className="text-amber-400" />
                <span className="text-[10px] text-slate-500 uppercase">Fasteners</span>
                <span className="text-xs text-slate-200 font-mono ml-auto">{PRINT_SPECS.fasteners}</span>
              </div>
            </div>
          </section>

          {/* === ASSEMBLY === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2 flex items-center gap-1">
              <Layers size={12} /> Assembly Order
            </h3>
            <div className="space-y-1">
              {ASSEMBLY_ORDER.map((step, i) => (
                <div key={i} className="flex items-center gap-2 rounded bg-slate-800/30 px-3 py-1.5">
                  <span className="text-[10px] font-mono text-amber-400 w-6">{i + 1}.</span>
                  <span className="text-xs text-slate-300">{step}</span>
                </div>
              ))}
            </div>
            <div className="text-[10px] text-slate-500 italic mt-1">
              Assembly sequence is conceptual. Actual sequence may vary based on hardware revision.
            </div>
          </section>

          {/* === 3D FILES === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2">3D Print Files</h3>
            <div className="space-y-1">
              {SAFETY_DEVICE_COMPONENTS.filter(c => c.filename).map(comp => (
                <div key={comp.id} className="flex items-center gap-2 rounded bg-slate-800/50 border border-slate-700 px-3 py-2">
                  <Box size={14} className="text-slate-500" />
                  <div className="flex-1">
                    <div className="text-xs text-slate-200">{comp.name}</div>
                    <div className="text-[9px] text-slate-500 font-mono">{comp.filename}</div>
                  </div>
                  <div className="flex items-center gap-1">
                    <Button variant="ghost" size="sm" className="h-6 text-[10px] text-slate-500" disabled={!comp.hasSTL}>
                      <Eye size={10} className="mr-1" /> View
                    </Button>
                    <Button variant="ghost" size="sm" className="h-6 text-[10px] text-slate-500" disabled={!comp.hasSTL}>
                      <Download size={10} className="mr-1" /> Download
                    </Button>
                  </div>
                  {!comp.hasSTL && (
                    <span className="text-[9px] text-slate-600 italic">Not available</span>
                  )}
                </div>
              ))}
            </div>
            <div className="text-[10px] text-slate-500 italic mt-1">
              STL files are not included in this module. Download and 3D view are disabled until files are provided.
            </div>
          </section>

          {/* === DEVICE VIEWS === */}
          <section>
            <h3 className="text-xs uppercase text-amber-400 font-semibold mb-2">Device Views</h3>
            <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
              {DEVICE_VIEWS.map(view => (
                <div key={view.id} className="rounded bg-slate-800/50 border border-slate-700 p-2">
                  <div className="text-[10px] font-semibold text-slate-300">{view.name}</div>
                  <div className="text-[9px] text-slate-500 mt-0.5">{view.description}</div>
                </div>
              ))}
            </div>
          </section>

          {/* === ENGINEERING DISCLAIMER === */}
          <div className="rounded-lg bg-slate-800/30 border border-slate-700/50 p-3">
            <div className="flex items-start gap-2">
              <AlertCircle size={14} className="text-amber-400 mt-0.5 shrink-0" />
              <div className="text-[10px] text-slate-500">
                This is a visual/software representation of the physical product.
                IP rating, waterproof rating, battery capacity, voltage, sensor specifications,
                connectivity protocols, and certifications are not specified unless provided
                in the project documentation. Unknown values are shown as "Not specified".
              </div>
            </div>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

function SpecCard({ label, value }: { label: string; value: string }) {
  return (
    <div className="rounded-lg bg-slate-800/50 border border-slate-700 p-2.5">
      <div className="text-[10px] text-slate-500 uppercase">{label}</div>
      <div className="text-xs text-slate-200 font-mono mt-1">{value}</div>
    </div>
  );
}
