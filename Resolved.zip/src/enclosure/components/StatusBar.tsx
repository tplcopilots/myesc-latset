'use client';

/**
 * Bottom status bar.
 *
 * Shows: dimensions, units, object count, triangle count, estimated print
 * volume (bbox), estimated material volume, warnings count.
 *
 * Stats are computed only on the client (after mount) to avoid SSR/CSR
 * hydration mismatch — geometry generation depends on `document` (canvas
 * for textures) which is undefined on the server.
 */
import React from 'react';
import { AlertTriangle, CheckCircle2, Info } from 'lucide-react';
import { useEnclosureStore } from '../store/enclosureStore';
import { generateEnclosureGeometry, type GeometryResult } from '../geometry';
import { formatLength, formatVolume, formatCount } from '../utils/format';

function Stat({ label, value, accent }: { label: string; value: string; accent?: string }) {
  return (
    <div className="flex items-center gap-1 px-2 py-0.5">
      <span className="text-[10px] uppercase text-slate-500">{label}</span>
      <span className={`text-[11px] font-mono ${accent ?? 'text-slate-200'}`}>{value}</span>
    </div>
  );
}

export default function StatusBar() {
  const project = useEnclosureStore(s => s.project);
  const dirty = useEnclosureStore(s => s.dirty);
  const issues = useEnclosureStore(s => s.validationIssues);
  const runValidation = useEnclosureStore(s => s.runValidation);

  // Compute geometry only on the client (after mount) to avoid SSR mismatch.
  // The server renders with stats=null and the client renders with the
  // real numbers after the first effect runs.
  const [stats, setStats] = React.useState<GeometryResult | null>(null);
  const [mounted, setMounted] = React.useState(false);

  React.useEffect(() => {
    setMounted(true);
  }, []);

  React.useEffect(() => {
    if (!mounted) return;
    try {
      const result = generateEnclosureGeometry({ project });
      setStats(result);
    } catch (err) {
      console.error(err);
    }
  }, [project, dirty, mounted]);

  React.useEffect(() => {
    if (mounted && issues.length === 0) runValidation();
  }, [mounted]);

  const { width, depth, height } = project.dimensions;
  const unit = project.settings.unit;
  const objectCount = stats?.parts.length ?? 0;
  const warningCount = issues.filter(i => i.severity === 'warning').length;
  const errorCount = issues.filter(i => i.severity === 'error').length;

  return (
    <div className="h-7 bg-slate-950 border-t border-slate-700 flex items-center text-xs overflow-x-auto">
      <Stat label="Dimensions" value={`${formatLength(width, unit, 1)} × ${formatLength(depth, unit, 1)} × ${formatLength(height, unit, 1)}`} />
      <div className="w-px h-3 bg-slate-700" />
      <Stat label="Unit" value={unit} />
      <div className="w-px h-3 bg-slate-700" />
      <Stat label="Objects" value={formatCount(objectCount)} />
      <div className="w-px h-3 bg-slate-700" />
      <Stat label="Triangles" value={formatCount(stats?.triangleCount ?? 0)} />
      <div className="w-px h-3 bg-slate-700" />
      <Stat label="Bbox vol (est.)" value={formatVolume(stats?.boundingBoxVolume ?? 0, unit, 1)} />
      <div className="w-px h-3 bg-slate-700" />
      <Stat label="Material vol (est.)" value={formatVolume(stats?.materialVolume ?? 0, unit, 1)} />
      <div className="flex-1" />
      {errorCount > 0 ? (
        <div className="flex items-center gap-1 px-2 text-red-400">
          <AlertTriangle size={12} />
          <span className="text-[11px]">{errorCount} error(s)</span>
        </div>
      ) : warningCount > 0 ? (
        <div className="flex items-center gap-1 px-2 text-amber-400">
          <AlertTriangle size={12} />
          <span className="text-[11px]">{warningCount} warning(s)</span>
        </div>
      ) : (
        <div className="flex items-center gap-1 px-2 text-emerald-400">
          <CheckCircle2 size={12} />
          <span className="text-[11px]">No issues detected</span>
        </div>
      )}
      <div className="w-px h-3 bg-slate-700" />
      <div className="flex items-center gap-1 px-2 text-slate-500">
        <Info size={10} />
        <span className="text-[10px]">Vols are heuristic estimates</span>
      </div>
    </div>
  );
}
