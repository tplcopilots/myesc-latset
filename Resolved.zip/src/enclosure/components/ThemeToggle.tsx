'use client';

/**
 * Theme toggle — switches between dark and light mode, plus lets the user
 * pick a professional accent color for light mode (orange/blue/navy/green).
 *
 * Injects theme CSS directly via a <style> tag (bypasses Tailwind 4
 * compilation issues with custom CSS in globals.css).
 */
import React from 'react';
import { Sun, Moon, Palette } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from '@/components/ui/popover';
import { useEnclosureStore } from '../store/enclosureStore';
import type { ApplicationSettings } from '../types';

const THEME_COLORS = [
  { id: 'orange' as const, name: 'Orange & White', color: '#ea580c', tint: 'rgba(234,88,12,0.08)' },
  { id: 'blue' as const, name: 'Blue & White', color: '#2563eb', tint: 'rgba(37,99,235,0.08)' },
  { id: 'navy' as const, name: 'Navy & White', color: '#1e3a5f', tint: 'rgba(30,58,95,0.08)' },
  { id: 'green' as const, name: 'Green & White', color: '#059669', tint: 'rgba(5,150,105,0.08)' },
];

// CSS injected directly — bypasses Tailwind 4 compilation
const LIGHT_MODE_CSS = `
/* Light mode: clean white + accent tints (NO gray) */
.bg-slate-950 { background-color: #ffffff !important; }
.bg-slate-900 { background-color: #ffffff !important; }
.bg-slate-800 { background-color: #ffffff !important; }
.bg-slate-800\/50 { background-color: var(--accent-surface, #f8fbff) !important; }
.bg-slate-950\/50 { background-color: var(--accent-surface, #f8fbff) !important; }
.bg-slate-900\/30 { background-color: var(--accent-surface, #f8fbff) !important; }
.bg-slate-900\/50 { background-color: var(--accent-surface, #f8fbff) !important; }
.text-slate-100 { color: #0f172a !important; }
.text-slate-200 { color: #1e293b !important; }
.text-slate-300 { color: #374151 !important; }
.text-slate-400 { color: #4b5563 !important; }
.text-slate-500 { color: #6b7280 !important; }
.border-slate-700 { border-color: #e2e8f0 !important; }
.border-slate-600 { border-color: #cbd5e1 !important; }
.border-r { border-right: 1px solid #e2e8f0 !important; box-shadow: 2px 0 8px rgba(0,0,0,0.06) !important; }
.border-l { border-left: 1px solid #e2e8f0 !important; box-shadow: -2px 0 8px rgba(0,0,0,0.06) !important; }
.border-t { border-top: 1px solid #e2e8f0 !important; }
.border-b { border-bottom: 1px solid #e2e8f0 !important; }
/* Input fields: white bg, clean border, monospace */
input[type="number"], input[type="text"] {
  background-color: #ffffff !important;
  border: 1px solid #d1d5db !important;
  border-radius: 5px !important;
  color: #1e293b !important;
  font-family: 'JetBrains Mono','Roboto Mono','Consolas',monospace !important;
  padding: 4px 8px !important;
}
input[type="number"]:focus, input[type="text"]:focus {
  outline: none !important;
}
/* Toolbar: cool surface with shadow */
header, .bg-slate-950:first-of-type {
  background-color: var(--accent-surface, #f8fbff) !important;
  box-shadow: 0 2px 6px rgba(0,0,0,0.08) !important;
}
/* Status bar: light surface */
.h-7.bg-slate-950 {
  background-color: var(--accent-surface, #f8fbff) !important;
  box-shadow: 0 -1px 4px rgba(0,0,0,0.05) !important;
}
/* Sidebar panel backgrounds: white with subtle shadow */
.border-r { background-color: #ffffff !important; }
.border-l { background-color: #ffffff !important; }
/* Active accordion header: accent tint + left bar */
button[aria-expanded="true"] {
  background-color: var(--accent-tint, rgba(59,130,246,0.08)) !important;
  border-left: 3px solid var(--accent-color, #3b82f6) !important;
  color: var(--accent-color, #3b82f6) !important;
  font-weight: 600 !important;
}
button[aria-expanded="false"] { border-left: 3px solid transparent !important; }
button[aria-expanded="false"]:hover {
  background-color: var(--accent-tint, rgba(59,130,246,0.04)) !important;
}
/* Active tab: accent border */
[role="tab"][data-state="active"] {
  font-weight: 600 !important;
  border-bottom: 2px solid var(--accent-color, #3b82f6) !important;
  color: var(--accent-color, #3b82f6) !important;
}
[role="tab"][data-state="inactive"] { color: #9ca3af !important; }
[role="tab"]:hover { background-color: var(--accent-tint, rgba(59,130,246,0.04)) !important; }
[role="tablist"] { border-bottom: 1px solid #e2e8f0 !important; }
/* Buttons: white with border */
button[class*="bg-slate-800"] {
  background-color: #ffffff !important;
  border: 1px solid #d1d5db !important;
  color: #374151 !important;
}
button[class*="bg-slate-800"]:hover { background-color: var(--accent-tint, rgba(59,130,246,0.06)) !important; }
button[class*="bg-slate-700"] {
  background-color: var(--accent-color, #3b82f6) !important;
  color: #ffffff !important;
  border-color: var(--accent-color, #3b82f6) !important;
}
/* Cards / items */
.border-amber-600 { background-color: var(--accent-tint, rgba(59,130,246,0.08)) !important; border-color: var(--accent-color, #3b82f6) !important; }
[class*="clickable"]:hover { background-color: var(--accent-tint, rgba(59,130,246,0.06)) !important; }
`;

const DARK_MODE_CSS = `
/* Dark mode: lighter inputs, amber active states */
input[type="number"], input[type="text"] {
  background-color: #334155 !important;
  border: 1px solid #475569 !important;
  border-radius: 4px !important;
  color: #e2e8f0 !important;
  font-family: 'JetBrains Mono','Roboto Mono','Consolas',monospace !important;
}
input[type="number"]:focus, input[type="text"]:focus {
  border-color: #fbbf24 !important;
  box-shadow: 0 0 0 2px rgba(251,191,36,0.2) !important;
  outline: none !important;
}
/* Expanded accordion: amber accent */
button[aria-expanded="true"] {
  background-color: rgba(251,191,36,0.08) !important;
  border-left: 2px solid #fbbf24 !important;
  color: #fbbf24 !important;
}
button[aria-expanded="false"] { border-left: 2px solid transparent !important; }
button[aria-expanded="false"]:hover {
  background-color: rgba(251,191,36,0.04) !important;
  color: #fcd34d !important;
}
/* Active viewport buttons: amber */
button.bg-slate-700, button[class*="bg-slate-700"] {
  background-color: #fbbf24 !important;
  color: #0f172a !important;
  border-color: #f59e0b !important;
}
/* Active tab: amber */
[role="tab"][data-state="active"] {
  color: #fbbf24 !important;
  border-bottom: 2px solid #fbbf24 !important;
  font-weight: 600 !important;
}
[role="tab"][data-state="inactive"] { color: #64748b !important; border-bottom: 2px solid transparent !important; }
[role="tab"]:hover { color: #fcd34d !important; background-color: rgba(251,191,36,0.05) !important; }
/* Selected items */
.border-amber-600 { background-color: rgba(251,191,36,0.08) !important; border-color: #fbbf24 !important; }
[class*="clickable"]:hover { background-color: rgba(251,191,36,0.06) !important; }
`;

export function ThemeToggle() {
  const theme = useEnclosureStore(s => s.project.settings.theme);
  const themeColor = useEnclosureStore(s => s.project.settings.themeColor ?? 'orange');
  const setSettings = useEnclosureStore(s => s.setSettings);

  React.useEffect(() => {
    if (typeof document === 'undefined') return;

    // Set CSS variables for the accent color
    const tc = THEME_COLORS.find(t => t.id === themeColor);
    const accentColor = tc?.color || '#3b82f6';
    const accentTint = tc?.tint || 'rgba(59,130,246,0.08)';
    // Surface color = very light tint of the accent
    const surfaceColors: Record<string, string> = {
      orange: '#fff8f0',
      blue: '#f0f6ff',
      navy: '#f0f4f8',
      green: '#f0fdf6',
    };
    const accentSurface = surfaceColors[themeColor] || '#f8fbff';

    document.documentElement.style.setProperty('--accent-color', accentColor);
    document.documentElement.style.setProperty('--accent-tint', accentTint);
    document.documentElement.style.setProperty('--accent-surface', accentSurface);

    // Inject or update the theme CSS
    let styleEl = document.getElementById('theme-styles');
    if (!styleEl) {
      styleEl = document.createElement('style');
      styleEl.id = 'theme-styles';
      document.head.appendChild(styleEl);
    }

    if (theme === 'light') {
      // Build the accent-specific overrides
      const accentCss = `
        .text-amber-400 { color: ${accentColor} !important; }
        .text-amber-500 { color: ${accentColor} !important; }
        .hover\\:text-amber-400:hover { color: ${accentColor} !important; }
        .hover\\:text-red-400:hover { color: #dc2626 !important; }
        .text-red-400 { color: #dc2626 !important; }
        .bg-amber-900\\/20 { background-color: ${accentTint} !important; }
        .border-amber-600 { border-color: ${accentColor} !important; }
        .border-amber-700\\/50 { border-color: ${accentTint} !important; }
        input[type="number"]:focus, input[type="text"]:focus {
          border-color: ${accentColor} !important;
          box-shadow: 0 0 0 3px ${accentTint.replace('0.08', '0.15')} !important;
        }
        [role="tab"][data-state="active"] { border-bottom-color: ${accentColor} !important; }
      `;
      styleEl.innerHTML = LIGHT_MODE_CSS + accentCss;
    } else {
      styleEl.innerHTML = DARK_MODE_CSS;
    }
  }, [theme, themeColor]);

  const toggle = () => {
    setSettings({ theme: theme === 'dark' ? 'light' : 'dark' } as Partial<ApplicationSettings>);
  };

  return (
    <div className="flex items-center gap-1">
      <Button
        variant="ghost"
        size="sm"
        className="text-slate-300 hover:text-amber-400 text-xs"
        onClick={toggle}
        title={`Switch to ${theme === 'dark' ? 'light' : 'dark'} mode`}
      >
        {theme === 'dark' ? <Sun size={14} /> : <Moon size={14} />}
      </Button>
      {theme === 'light' && (
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="ghost"
              size="sm"
              className="text-slate-300 hover:text-amber-400 text-xs"
              title="Choose accent color"
            >
              <Palette size={14} />
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-48 bg-white border border-slate-200 shadow-lg">
            <div className="space-y-1.5 p-1">
              <div className="text-[10px] font-medium text-slate-600 mb-1">Accent Color</div>
              {THEME_COLORS.map(tc => (
                <button
                  key={tc.id}
                  className={`w-full flex items-center gap-2 px-2 py-1.5 rounded text-xs transition-colors hover:bg-slate-100 ${
                    themeColor === tc.id ? 'ring-2 ring-offset-1' : ''
                  }`}
                  style={themeColor === tc.id ? { boxShadow: `inset 0 0 0 2px ${tc.color}` } : {}}
                  onClick={() => setSettings({ themeColor: tc.id } as Partial<ApplicationSettings>)}
                >
                  <div className="w-4 h-4 rounded shrink-0" style={{ backgroundColor: tc.color }} />
                  <span className="text-slate-700 text-[11px]">{tc.name}</span>
                </button>
              ))}
            </div>
          </PopoverContent>
        </Popover>
      )}
    </div>
  );
}
