'use client';

/**
 * Top toolbar.
 *
 * Buttons: New, Open, Save, Undo, Redo, Generate, Validate, Preview, Export,
 * Settings. Plus a Templates dropdown and a Samples dropdown for quick access.
 */
import React, { useRef } from 'react';
import {
  FilePlus,
  FolderOpen,
  Save,
  Undo2,
  Redo2,
  RefreshCw,
  ShieldCheck,
  Eye,
  Download,
  Settings as SettingsIcon,
  Boxes,
  BookOpen,
  ImageIcon,
  Shield,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import {
  DropdownMenu,
  DropdownMenuTrigger,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
} from '@/components/ui/dropdown-menu';
import { useEnclosureStore } from '../store/enclosureStore';
import { TEMPLATE_LIST } from '../templates';
import { SAMPLE_PROJECTS } from '../templates/samples';
import { serializeProject, projectFileName, deserializeProject } from '../project/projectFile';
import { downloadBlob } from '../utils/download';
import { FileViewerButton } from './FileViewer';
import { ThemeToggle } from './ThemeToggle';
import { DownloadProjectButton } from './DownloadProjectButton';

interface Props {
  onExportClick: () => void;
  onSettingsClick: () => void;
  onRenderClick: () => void;
  onSmartSafetyClick: () => void;
}

function ToolbarButton({
  icon,
  label,
  onClick,
  shortcut,
  disabled,
}: {
  icon: React.ReactNode;
  label: string;
  onClick: () => void;
  shortcut?: string;
  disabled?: boolean;
}) {
  return (
    <Tooltip>
      <TooltipTrigger asChild>
        <Button
          variant="ghost"
          size="icon"
          onClick={onClick}
          disabled={disabled}
          className="text-slate-200 hover:text-white hover:bg-slate-700/50"
        >
          {icon}
        </Button>
      </TooltipTrigger>
      <TooltipContent side="bottom">
        <div className="flex items-center gap-2">
          <span>{label}</span>
          {shortcut && <span className="opacity-50">{shortcut}</span>}
        </div>
      </TooltipContent>
    </Tooltip>
  );
}

export default function Toolbar({ onExportClick, onSettingsClick, onRenderClick, onSmartSafetyClick }: Props) {
  const fileInputRef = useRef<HTMLInputElement>(null);
  const undo = useEnclosureStore(s => s.undo);
  const redo = useEnclosureStore(s => s.redo);
  const newProject = useEnclosureStore(s => s.newProject);
  const loadProject = useEnclosureStore(s => s.loadProject);
  const loadTemplate = useEnclosureStore(s => s.loadTemplate);
  const loadSample = useEnclosureStore(s => s.loadSample);
  const runValidation = useEnclosureStore(s => s.runValidation);
  const setViewMode = useEnclosureStore(s => s.setViewMode);
  const viewMode = useEnclosureStore(s => s.viewMode);
  const markClean = useEnclosureStore(s => s.markClean);
  const project = useEnclosureStore(s => s.project);
  const canUndo = useEnclosureStore(s => s.history.length > 0);
  const canRedo = useEnclosureStore(s => s.future.length > 0);

  const handleOpen = () => {
    fileInputRef.current?.click();
  };
  const handleFilePicked = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;
    file.text().then(text => {
      try {
        const p = deserializeProject(text);
        loadProject(p);
      } catch (err) {
        alert(`Failed to open file: ${err instanceof Error ? err.message : String(err)}`);
      }
    });
    e.target.value = ''; // allow re-opening same file
  };
  const handleSave = () => {
    const json = serializeProject(project);
    downloadBlob(new Blob([json], { type: 'application/json' }), projectFileName(project)).catch(() => {});
  };
  const handleGenerate = () => {
    // Force geometry regen by toggling dirty.
    markClean();
    requestAnimationFrame(() => useEnclosureStore.setState({ dirty: true }));
  };
  const handleValidate = () => {
    runValidation();
  };
  const handlePreview = () => {
    setViewMode(viewMode === 'wireframe' ? 'solid' : 'wireframe');
  };

  return (
    <div className="flex items-center gap-1 px-3 h-12 bg-slate-900 border-b border-slate-700">
      <div className="flex items-center gap-2 mr-2">
        <Boxes className="size-5 text-amber-400" />
        <span className="text-sm font-semibold text-slate-100">Enclosure Designer</span>
      </div>

      <div className="w-px h-6 bg-slate-700 mx-1" />

      <ToolbarButton icon={<FilePlus size={16} />} label="New" onClick={newProject} shortcut="Ctrl+N" />
      <ToolbarButton icon={<FolderOpen size={16} />} label="Open" onClick={handleOpen} shortcut="Ctrl+O" />
      <ToolbarButton icon={<Save size={16} />} label="Save" onClick={handleSave} shortcut="Ctrl+S" />

      <div className="w-px h-6 bg-slate-700 mx-1" />

      <ToolbarButton icon={<Undo2 size={16} />} label="Undo" onClick={undo} disabled={!canUndo} shortcut="Ctrl+Z" />
      <ToolbarButton icon={<Redo2 size={16} />} label="Redo" onClick={redo} disabled={!canRedo} shortcut="Ctrl+Shift+Z" />

      <div className="w-px h-6 bg-slate-700 mx-1" />

      <ToolbarButton icon={<RefreshCw size={16} />} label="Generate" onClick={handleGenerate} />
      <ToolbarButton icon={<ShieldCheck size={16} />} label="Validate" onClick={handleValidate} />
      <ToolbarButton icon={<Eye size={16} />} label="Toggle Wireframe" onClick={handlePreview} />

      <div className="w-px h-6 bg-slate-700 mx-1" />

      {/* Templates dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="text-slate-200 hover:text-white hover:bg-slate-700/50">
            Templates
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          <DropdownMenuLabel>Enclosure Templates</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {TEMPLATE_LIST.map(t => (
            <DropdownMenuItem key={t.id} onClick={() => loadTemplate(t.id)}>
              <div className="flex flex-col">
                <span>{t.name}</span>
                <span className="text-xs text-slate-400">{t.description}</span>
              </div>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      {/* Samples dropdown */}
      <DropdownMenu>
        <DropdownMenuTrigger asChild>
          <Button variant="ghost" size="sm" className="text-slate-200 hover:text-white hover:bg-slate-700/50">
            Samples
          </Button>
        </DropdownMenuTrigger>
        <DropdownMenuContent align="start" className="w-56">
          <DropdownMenuLabel>Sample Projects</DropdownMenuLabel>
          <DropdownMenuSeparator />
          {SAMPLE_PROJECTS.map(s => (
            <DropdownMenuItem key={s.id} onClick={() => loadSample(s.id)}>
              <div className="flex flex-col">
                <span>{s.name}</span>
                <span className="text-xs text-slate-400">{s.description}</span>
              </div>
            </DropdownMenuItem>
          ))}
        </DropdownMenuContent>
      </DropdownMenu>

      <ToolbarButton icon={<Download size={16} />} label="Export" onClick={onExportClick} shortcut="Ctrl+E" />
      <ToolbarButton icon={<ImageIcon size={16} />} label="Render" onClick={onRenderClick} title="Render high-quality image (external, internal, exploded views)" />
      <ToolbarButton icon={<Shield size={16} />} label="Safety Device" onClick={onSmartSafetyClick} title="Smart Safety Harness Device Module" />

      <div className="flex-1" />

      <FileViewerButton />

      <DownloadProjectButton />

      <ThemeToggle />

      <ToolbarButton
        icon={<BookOpen size={16} />}
        label="Manual"
        onClick={() => window.open('/ESP-S3-4G-DEV-Kit_Manual.pdf', '_blank')}
        title="Open the ESP-S3-4G-DEV-Kit reference manual (PDF)"
      />

      <ToolbarButton icon={<SettingsIcon size={16} />} label="Settings" onClick={onSettingsClick} />

      <input
        ref={fileInputRef}
        type="file"
        accept=".enclosure,.json,application/json"
        onChange={handleFilePicked}
        className="hidden"
      />
    </div>
  );
}
