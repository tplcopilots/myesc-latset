'use client';

/**
 * 3D Viewer (React Three Fiber).
 *
 * Renders the generated enclosure geometry with OrbitControls, grid, axes.
 * Supports:
 *   - solid / wireframe / transparent view modes
 *   - front/back/left/right/top/bottom/iso camera presets
 *   - object selection (click to select part)
 *   - print orientation (rotates the whole enclosure)
 *   - bounding box helper
 *
 * Geometry is regenerated (debounced) when the project's dimensions change.
 */
import React, { useEffect, useMemo, useRef } from 'react';
import * as THREE from 'three';
import { Canvas, useThree, useFrame, ThreeEvent } from '@react-three/fiber';
import { OrbitControls, Grid, GizmoHelper, GizmoViewport, Environment } from '@react-three/drei';
import { useEnclosureStore } from '../store/enclosureStore';
import { generateEnclosureGeometry } from '../geometry';
import type { GeneratedPart } from '../types';
import { MATERIAL_PRESETS } from '../types';

// -----------------------------------------------------------------------------
// Material cache — create ONE material per material type, reused across parts.
// -----------------------------------------------------------------------------
const materialCache = new Map<string, THREE.MeshStandardMaterial>();
function getMaterial(materialType: keyof typeof MATERIAL_PRESETS): THREE.MeshStandardMaterial {
  const preset = MATERIAL_PRESETS[materialType];
  if (!materialCache.has(materialType)) {
    const mat = new THREE.MeshStandardMaterial({
      color: new THREE.Color(preset.color),
      roughness: preset.roughness,
      metalness: preset.metalness,
      transparent: preset.opacity < 1,
      opacity: preset.opacity,
    });
    materialCache.set(materialType, mat);
  }
  return materialCache.get(materialType)!;
}

// -----------------------------------------------------------------------------
// PartMeshes — renders one GeneratedPart as a set of <mesh> elements.
// -----------------------------------------------------------------------------
function PartMeshes({
  part,
  selected,
  viewMode,
  printOrientation,
  onSelect,
}: {
  part: GeneratedPart;
  selected: boolean;
  viewMode: 'solid' | 'wireframe' | 'transparent' | 'section';
  printOrientation: THREE.Euler;
  onSelect: () => void;
}) {
  const matRef = useRef<THREE.MeshStandardMaterial>(null);
  // Apply view-mode params to all meshes' materials.
  useEffect(() => {
    for (const mesh of part.meshes) {
      // Material can be a single material OR an array (e.g., text decorations
      // use a multi-material array so the +Z face has the text texture and
      // the other faces are plain). Handle both cases.
      const mats: THREE.MeshStandardMaterial[] = Array.isArray(mesh.material)
        ? (mesh.material as THREE.Material[]).filter(
            (m): m is THREE.MeshStandardMaterial =>
              !!m && 'opacity' in m && 'wireframe' in m,
          )
        : mesh.material
        ? [mesh.material as THREE.MeshStandardMaterial]
        : [];
      for (const mat of mats) {
        if (!mat) continue;
        // Stash the original opacity once, so toggling transparent mode
        // doesn't lose the preset opacity.
        if (mat.userData.originalOpacity == null) {
          mat.userData.originalOpacity = mat.opacity ?? 1;
        }
        mat.wireframe = viewMode === 'wireframe';
        mat.opacity =
          viewMode === 'transparent' ? 0.4 : (mat.userData.originalOpacity ?? 1);
        mat.transparent = viewMode === 'transparent' || mat.opacity < 1;
        if ('emissive' in mat) {
          mat.emissive = selected
            ? new THREE.Color('#fbbf24')
            : new THREE.Color('#000000');
          mat.emissiveIntensity = selected ? 0.3 : 0;
        }
        mat.needsUpdate = true;
      }
    }
  }, [part, viewMode, selected]);
  return (
    <group rotation={printOrientation}>
      {part.meshes.map((mesh, i) => (
        <primitive
          key={`${part.id}_${i}`}
          object={mesh}
          onClick={(e: ThreeEvent<MouseEvent>) => {
            e.stopPropagation();
            onSelect();
          }}
        />
      ))}
      {/* Edges for selected parts */}
      {selected && part.meshes.map((mesh, i) => (
        <primitive
          key={`${part.id}_edges_${i}`}
          object={new THREE.LineSegments(
            new THREE.EdgesGeometry(mesh.geometry as THREE.BufferGeometry),
            new THREE.LineBasicMaterial({ color: '#fbbf24' })
          )}
        />
      ))}
    </group>
  );
}

// -----------------------------------------------------------------------------
// CameraViewSetter — when `currentView` changes, snap the camera.
// -----------------------------------------------------------------------------
function CameraViewSetter({ view }: { view: string }) {
  const { camera, controls } = useThree();
  useEffect(() => {
    // Compute distance from bounding box of all meshes (we use a fixed
    // distance based on project dimensions).
    const dist = 200;
    const target = new THREE.Vector3(0, 20, 0); // look at the enclosure mid-height
    const positions: Record<string, [number, number, number]> = {
      front: [0, 20, dist],
      back: [0, 20, -dist],
      left: [-dist, 20, 0],
      right: [dist, 20, 0],
      top: [0, dist, 0.001],
      bottom: [0, -dist, 0.001],
      iso: [dist * 0.7, dist * 0.7, dist * 0.7],
    };
    const pos = positions[view] ?? positions.iso;
    camera.position.set(...pos);
    camera.lookAt(target);
    const controlsObj = controls as unknown as { target: THREE.Vector3; update: () => void } | null;
    if (controlsObj) {
      controlsObj.target.set(0, 20, 0);
      controlsObj.update();
    }
  }, [view, camera, controls]);
  return null;
}

// -----------------------------------------------------------------------------
// ViewerContent — the inner R3F scene. Lives inside <Canvas>.
// -----------------------------------------------------------------------------
function ViewerContent() {
  const project = useEnclosureStore(s => s.project);
  const viewMode = useEnclosureStore(s => s.viewMode);
  const currentView = useEnclosureStore(s => s.currentView);
  const selectedPart = useEnclosureStore(s => s.selectedPart);
  const showGrid = useEnclosureStore(s => s.showGrid);
  const showAxes = useEnclosureStore(s => s.showAxes);
  const showBoundingBox = useEnclosureStore(s => s.showBoundingBox);
  const setSelectedPart = useEnclosureStore(s => s.setSelectedPart);
  const dirty = useEnclosureStore(s => s.dirty);
  const markClean = useEnclosureStore(s => s.markClean);

  // Regenerate geometry whenever project changes (debounced via setTimeout).
  // We use a ref to avoid stale closures.
  const [parts, setParts] = React.useState<GeneratedPart[]>([]);
  const [boundingBox, setBoundingBox] = React.useState<THREE.Box3 | null>(null);

  useEffect(() => {
    let cancelled = false;
    const id = setTimeout(() => {
      try {
        const result = generateEnclosureGeometry({ project });
        if (!cancelled) {
          setParts(result.parts);
          const box = new THREE.Box3(result.boundingBox.min, result.boundingBox.max);
          setBoundingBox(box);
          markClean();
        }
      } catch (err) {
        console.error('Geometry generation failed:', err);
      }
    }, 60);
    return () => {
      cancelled = true;
      clearTimeout(id);
    };
  }, [project, dirty, markClean]);

  // Print orientation: convert degrees to radians.
  const printEuler = useMemo(() => {
    const degToRad = (d: number) => (d * Math.PI) / 180;
    return new THREE.Euler(
      degToRad(project.printOrientation.x),
      degToRad(project.printOrientation.y),
      degToRad(project.printOrientation.z)
    );
  }, [project.printOrientation]);

  return (
    <>
      <CameraViewSetter view={currentView} />
      <OrbitControls makeDefault enablePan enableZoom enableRotate />
      <ambientLight intensity={0.6} />
      <directionalLight position={[80, 100, 80]} intensity={1.0} castShadow={false} />
      <directionalLight position={[-80, 60, -80]} intensity={0.4} />

      {/* Render each part */}
      {parts.map(part => (
        <PartMeshes
          key={part.id}
          part={part}
          selected={selectedPart === part.id}
          viewMode={viewMode}
          printOrientation={printEuler}
          onSelect={() => setSelectedPart(part.id)}
        />
      ))}

      {/* Bounding box helper */}
      {showBoundingBox && boundingBox && (
        <box3Helper args={[boundingBox, '#fbbf24']} />
      )}

      {/* Grid */}
      {showGrid && (
        <Grid
          position={[0, 0, 0]}
          args={[400, 400]}
          cellSize={10}
          cellThickness={0.6}
          cellColor="#475569"
          sectionSize={50}
          sectionThickness={1.0}
          sectionColor="#94a3b8"
          fadeDistance={500}
          fadeStrength={1.0}
          infiniteGrid
        />
      )}

      {/* Axes */}
      {showAxes && (
        <axesHelper args={[40]} />
      )}

      {/* Viewport gizmo */}
      <GizmoHelper alignment="top-right" margin={[80, 80]}>
        <GizmoViewport axisColors={['#ef4444', '#22c55e', '#3b82f6']} labelColor="white" />
      </GizmoHelper>
    </>
  );
}

// -----------------------------------------------------------------------------
// Viewer wrapper (the <Canvas>).
// -----------------------------------------------------------------------------
export default function Viewer() {
  return (
    <div className="w-full h-full bg-slate-950 relative">
      <Canvas
        camera={{ position: [140, 140, 140], fov: 45, near: 0.1, far: 2000 }}
        dpr={[1, 2]}
        gl={{ antialias: true, preserveDrawingBuffer: true }}
      >
        <color attach="background" args={['#0b1120']} />
        <Environment preset="city" />
        <ViewerContent />
      </Canvas>
    </div>
  );
}
