'use client';

/**
 * Viewport controls — small overlay buttons for view presets and view modes.
 * Rendered inside the viewer container.
 */
import React from 'react';
import { Grid3x3, Axis3d, Box } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Tooltip, TooltipTrigger, TooltipContent } from '@/components/ui/tooltip';
import { useEnclosureStore } from '../store/enclosureStore';
import type { CameraView, ViewMode } from '../store/enclosureStore';

const VIEWS: { id: CameraView; label: string }[] = [
  { id: 'front', label: 'Front' },
  { id: 'back', label: 'Back' },
  { id: 'left', label: 'Left' },
  { id: 'right', label: 'Right' },
  { id: 'top', label: 'Top' },
  { id: 'bottom', label: 'Bottom' },
  { id: 'iso', label: 'Iso' },
];

const MODES: { id: ViewMode; label: string }[] = [
  { id: 'solid', label: 'Solid' },
  { id: 'wireframe', label: 'Wireframe' },
  { id: 'transparent', label: 'Transparent' },
  { id: 'section', label: 'Section' },
];

export default function ViewportControls() {
  const currentView = useEnclosureStore(s => s.currentView);
  const setCurrentView = useEnclosureStore(s => s.setCurrentView);
  const viewMode = useEnclosureStore(s => s.viewMode);
  const setViewMode = useEnclosureStore(s => s.setViewMode);
  const showGrid = useEnclosureStore(s => s.showGrid);
  const showAxes = useEnclosureStore(s => s.showAxes);
  const showBoundingBox = useEnclosureStore(s => s.showBoundingBox);
  const setShowGrid = useEnclosureStore(s => s.setShowGrid);
  const setShowAxes = useEnclosureStore(s => s.setShowAxes);
  const setShowBoundingBox = useEnclosureStore(s => s.setShowBoundingBox);

  return (
    <div className="absolute top-2 left-2 flex flex-col gap-2 z-10">
      <div className="flex flex-wrap gap-1 bg-slate-900/90 backdrop-blur rounded p-1 border border-slate-700">
        {VIEWS.map(v => (
          <Tooltip key={v.id}>
            <TooltipTrigger asChild>
              <Button
                variant={currentView === v.id ? 'secondary' : 'ghost'}
                size="sm"
                className={`h-6 px-2 text-[10px] ${
                  currentView === v.id ? 'bg-slate-700 text-white' : 'text-slate-300'
                }`}
                onClick={() => setCurrentView(v.id)}
              >
                {v.label}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">{v.label} view</TooltipContent>
          </Tooltip>
        ))}
      </div>
      <div className="flex flex-wrap gap-1 bg-slate-900/90 backdrop-blur rounded p-1 border border-slate-700">
        {MODES.map(m => (
          <Tooltip key={m.id}>
            <TooltipTrigger asChild>
              <Button
                variant={viewMode === m.id ? 'secondary' : 'ghost'}
                size="sm"
                className={`h-6 px-2 text-[10px] ${
                  viewMode === m.id ? 'bg-slate-700 text-white' : 'text-slate-300'
                }`}
                onClick={() => setViewMode(m.id)}
              >
                {m.label}
              </Button>
            </TooltipTrigger>
            <TooltipContent side="bottom">{m.label} mode</TooltipContent>
          </Tooltip>
        ))}
      </div>
      <div className="flex flex-wrap gap-1 bg-slate-900/90 backdrop-blur rounded p-1 border border-slate-700">
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={showGrid ? 'secondary' : 'ghost'}
              size="icon"
              className={`size-7 ${showGrid ? 'bg-slate-700 text-white' : 'text-slate-300'}`}
              onClick={() => setShowGrid(!showGrid)}
            >
              <Grid3x3 size={14} />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">Toggle grid</TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={showAxes ? 'secondary' : 'ghost'}
              size="icon"
              className={`size-7 ${showAxes ? 'bg-slate-700 text-white' : 'text-slate-300'}`}
              onClick={() => setShowAxes(!showAxes)}
            >
              <Axis3d size={14} />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">Toggle axes</TooltipContent>
        </Tooltip>
        <Tooltip>
          <TooltipTrigger asChild>
            <Button
              variant={showBoundingBox ? 'secondary' : 'ghost'}
              size="icon"
              className={`size-7 ${showBoundingBox ? 'bg-slate-700 text-white' : 'text-slate-300'}`}
              onClick={() => setShowBoundingBox(!showBoundingBox)}
            >
              <Box size={14} />
            </Button>
          </TooltipTrigger>
          <TooltipContent side="bottom">Toggle bounding box</TooltipContent>
        </Tooltip>
      </div>
    </div>
  );
}
