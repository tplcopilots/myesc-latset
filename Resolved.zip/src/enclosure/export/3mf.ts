/**
 * 3MF exporter.
 *
 * 3MF is a ZIP archive containing:
 *   - `[Content_Types].xml`    — declares MIME types
 *   - `_rels/.rels`            — root relationship pointing to the model
 *   - `3D/3dmodel.model`       — the actual mesh XML
 *
 * The model.xml uses the 3MF Core spec:
 *   <model unit="millimeter">
 *     <resources>
 *       <object id="1" type="model">
 *         <mesh>
 *           <vertices> <vertex x y z />* </vertices>
 *   <triangles> <triangle v1 v2 v3 />* </triangles>
 *         </mesh>
 *       </object>
 *     </resources>
 *     <build>
 *       <item objectid="1" transform="..."/>
 *     </build>
 *   </model>
 *
 * We merge all meshes' vertices/faces into a single object for simplicity.
 */
import * as THREE from 'three';
import JSZip from 'jszip';

interface ExportMesh {
  name: string;
  geometry: THREE.BufferGeometry;
  matrixWorld: THREE.Matrix4;
}

const CONTENT_TYPES_XML = `<?xml version="1.0" encoding="UTF-8"?>
<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">
  <Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>
  <Default Extension="model" ContentType="application/vnd.ms-3dmodeling+xml"/>
</Types>`;

const RELS_XML = `<?xml version="1.0" encoding="UTF-8"?>
<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">
  <Relationship Target="/3D/3dmodel.model" Id="rel0" Type="http://schemas.microsoft.com/3dmanufacturing/2013/01/3dmodel"/>
</Relationships>`;

function escapeXml(s: string): string {
  return s
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');
}

function buildModelXml(meshes: ExportMesh[], projectName: string): string {
  const vertexLines: string[] = [];
  const triangleLines: string[] = [];
  let vertexOffset = 0;
  const v0 = new THREE.Vector3();
  for (const m of meshes) {
    const pos = m.geometry.getAttribute('position');
    if (!pos) continue;
    const matrix = m.matrixWorld;
    for (let i = 0; i < pos.count; i++) {
      v0.fromBufferAttribute(pos, i).applyMatrix4(matrix);
      vertexLines.push(
        `<vertex x="${sanitize(v0.x).toFixed(6)}" y="${sanitize(v0.y).toFixed(6)}" z="${sanitize(v0.z).toFixed(6)}"/>`
      );
    }
    const index = m.geometry.getIndex();
    const triCount = index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);
    for (let i = 0; i < triCount; i++) {
      // 3MF vertex indices are zero-based, like Three.js buffer indices.
      const a = (index ? index.getX(i * 3) : i * 3) + vertexOffset;
      const b = (index ? index.getX(i * 3 + 1) : i * 3 + 1) + vertexOffset;
      const c = (index ? index.getX(i * 3 + 2) : i * 3 + 2) + vertexOffset;
      triangleLines.push(`<triangle v1="${a}" v2="${b}" v3="${c}"/>`);
    }
    vertexOffset += pos.count;
  }

  return `<?xml version="1.0" encoding="UTF-8"?>
<model unit="millimeter" xml:lang="en-US" xmlns="http://schemas.microsoft.com/3dmanufacturing/core/2015/02">
  <metadata name="Title">${escapeXml(projectName)}</metadata>
  <metadata name="Application">3D Enclosure Designer</metadata>
  <resources>
    <object id="1" type="model" name="${escapeXml(projectName)}">
      <mesh>
        <vertices>
          ${vertexLines.join('\n          ')}
        </vertices>
        <triangles>
          ${triangleLines.join('\n          ')}
        </triangles>
      </mesh>
    </object>
  </resources>
  <build>
    <item objectid="1" transform="1 0 0 0 1 0 0 0 1 0 0 0"/>
  </build>
</model>`;
}

export async function export3MF(
  meshes: THREE.Mesh[],
  projectName: string
): Promise<Blob> {
  const exportMeshes: ExportMesh[] = meshes.map((m, i) => ({
    name: `part_${i}`,
    geometry: m.geometry as THREE.BufferGeometry,
    matrixWorld: m.matrixWorld,
  }));
  const modelXml = buildModelXml(exportMeshes, projectName);
  const zip = new JSZip();
  zip.file('[Content_Types].xml', CONTENT_TYPES_XML);
  zip.folder('_rels')!.file('.rels', RELS_XML);
  zip.folder('3D')!.file('3dmodel.model', modelXml);
  return zip.generateAsync({ type: 'blob' });
}

/** Replace NaN / Infinity with 0 to prevent corrupt XML output. */
function sanitize(n: number): number {
  return isFinite(n) ? n : 0;
}
