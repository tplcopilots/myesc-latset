/**
 * Export dispatcher.
 *
 * Given a GeometryResult (parts + meshes) and ExportOptions, produce either:
 *   - a single Blob (combined export)
 *   - a list of { name, blob } (multi-part export)
 *
 * The dispatcher returns the appropriate blob / file list and the caller
 * downloads them with file-saver.
 */
import * as THREE from 'three';
import type {
  EnclosureProject,
  ExportOptions,
  ExportFormat,
  GeneratedPart,
  MaterialType,
} from '../types';
import { exportSTL } from './stl';
import { exportOBJ, meshesToObjMeshes } from './obj';
import { exportPLY } from './ply';
import { export3MF } from './3mf';
import { exportZIP } from './zip';
import { repairMeshes } from '../geometry/repair';

export interface ExportInput {
  parts: GeneratedPart[];
  project: EnclosureProject;
  options: ExportOptions;
}

/**
 * Filter parts based on ExportOptions (multi-part or combined).
 */
function filterParts(input: ExportInput): GeneratedPart[] {
  const { parts, options } = input;
  return parts.filter(p => {
    if (p.id === 'lid' && !options.includeLid) return false;
    if (p.id === 'standoffs' && !options.includeStandoffs) return false;
    if (p.id === 'feet' && !options.includeFeet) return false;
    if (p.id === 'vents') return false; // vents are subtracted into walls
    if (p.id === 'mounts') return false; // mounts are part of bottom
    return true;
  });
}

/**
 * Material per part — the project's material type. (All parts share the
 * material color in this implementation.)
 */
function partMaterial(project: EnclosureProject): MaterialType {
  return project.material;
}

/**
 * Export a single combined file in the requested format.
 *
 * Returns a Blob. For 3MF, returns a Promise<Blob>.
 */
export async function exportCombined(input: ExportInput): Promise<Blob> {
  const parts = filterParts(input);
  const meshes: THREE.Mesh[] = [];
  for (const part of parts) {
    for (const mesh of part.meshes) {
      meshes.push(mesh);
    }
  }
  return await exportMeshes(meshes, input.options.format, input.project.name);
}

/**
 * Export separate files per part. Returns an array of { name, blob }.
 *
 * Filenames follow the spec: `enclosure_<partName>.<ext>`.
 *
 * IMPORTANT: Each part is RECENTERED TO ORIGIN before export. This means
 * the part's bounding box starts at (0, 0, 0) in the exported file. So:
 *   - `enclosure_bottom.stl` has Z from 0 to (bottom height)
 *   - `enclosure_lid.stl` has Z from 0 to (lid thickness) — NOT from
 *     (bottom height) to (bottom height + lid thickness)
 *   - `enclosure_standoffs.stl` has Z from 0 to (standoff height)
 *
 * This is the standard 3D-printing workflow: each part is sliced
 * independently, sitting on the build plate at Z=0. Without recentering,
 * the lid would appear at Z=25 (floating above the build plate) and the
 * slicer would either auto-drop it or require manual placement.
 *
 * For a combined export that shows the assembled enclosure (lid sitting
 * on top of the bottom), use `exportCombined` instead.
 */
export async function exportMultiPart(input: ExportInput): Promise<{ name: string; blob: Blob }[]> {
  const parts = filterParts(input);
  const files: { name: string; blob: Blob }[] = [];
  const ext = extensionFor(input.options.format);
  for (const part of parts) {
    // Recenter this part's meshes to origin so the bbox starts at (0,0,0).
    const recenteredMeshes = recenterMeshesToOrigin(part.meshes);
    const blob = await exportMeshes(recenteredMeshes, input.options.format, part.name);
    files.push({ name: `enclosure_${part.id}.${ext}`, blob });
  }
  if (files.length > 1) {
    const zipBlob = await exportZIP(files);
    files.push({ name: 'enclosure_all.zip', blob: zipBlob });
  }
  return files;
}

/**
 * Recenter a list of meshes so their combined bounding box starts at (0,0,0).
 *
 * For each mesh, we bake a translation into its geometry (so the mesh's
 * vertices are at the new positions) and reset its world matrix to identity.
 * This way, the exported STL has the part's bbox starting at the origin.
 *
 * Multi-mesh parts (e.g., bottom + decorations) are recentered together —
 * we compute the combined bbox of all meshes, then translate all by the
 * same offset so the combined bbox starts at (0,0,0).
 */
function recenterMeshesToOrigin(meshes: THREE.Mesh[]): THREE.Mesh[] {
  if (meshes.length === 0) return meshes;

  // Compute combined world-space bbox.
  const min = new THREE.Vector3(+Infinity, +Infinity, +Infinity);
  const max = new THREE.Vector3(-Infinity, -Infinity, -Infinity);
  const tmp = new THREE.Vector3();
  for (const mesh of meshes) {
    mesh.updateMatrixWorld(true);
    mesh.geometry.computeBoundingBox();
    const bb = mesh.geometry.boundingBox;
    if (!bb) continue;
    // Transform all 8 corners to world space and take min/max.
    const corners = [
      [bb.min.x, bb.min.y, bb.min.z],
      [bb.max.x, bb.min.y, bb.min.z],
      [bb.min.x, bb.max.y, bb.min.z],
      [bb.max.x, bb.max.y, bb.min.z],
      [bb.min.x, bb.min.y, bb.max.z],
      [bb.max.x, bb.min.y, bb.max.z],
      [bb.min.x, bb.max.y, bb.max.z],
      [bb.max.x, bb.max.y, bb.max.z],
    ];
    for (const [x, y, z] of corners) {
      tmp.set(x, y, z).applyMatrix4(mesh.matrixWorld);
      min.min(tmp);
      max.max(tmp);
    }
  }
  if (!isFinite(min.x)) return meshes;

  // Translation to bring min to (0,0,0).
  const offset = new THREE.Vector3(-min.x, -min.y, -min.z);

  // Bake the offset into each mesh's geometry and reset its matrix.
  const result: THREE.Mesh[] = [];
  for (const mesh of meshes) {
    // Clone the geometry so we don't mutate the original (which might be
    // cached and reused on next regen).
    const newGeom = mesh.geometry.clone();
    // Apply the mesh's current world matrix to the geometry (so vertices
    // are in world space), then apply the recenter offset, then reset
    // the mesh's matrix to identity.
    const worldMatrix = mesh.matrixWorld.clone();
    newGeom.applyMatrix4(worldMatrix);
    newGeom.translate(offset.x, offset.y, offset.z);
    newGeom.computeVertexNormals();
    newGeom.computeBoundingBox();
    newGeom.computeBoundingSphere();
    const newMesh = new THREE.Mesh(newGeom, mesh.material);
    // Reset matrix to identity — the geometry is already in world space.
    newMesh.matrix.identity();
    newMesh.matrixWorld.identity();
    newMesh.matrixAutoUpdate = false;
    newMesh.updateMatrixWorld(true);
    result.push(newMesh);
  }
  return result;
}

/**
 * Export the given meshes in the requested format. Returns a Blob.
 *
 * IMPORTANT: We call `repairMeshes()` before exporting. This welds vertices
 * within 10µm (10× smaller than typical 3D-printer layer height of 200µm),
 * removing the duplicate vertices that CSG operations and per-face
 * duplication in BoxGeometry produce. Without this step, the exported STL
 * has many "boundary edges" reported by slicers because each face's
 * vertices are separate (no edges shared between faces). After welding,
 * edges are properly shared, dramatically reducing boundary-edge counts
 * in slicer diagnostics.
 */
export async function exportMeshes(
  meshes: THREE.Mesh[],
  format: ExportFormat,
  name: string
): Promise<Blob> {
  // Repair the meshes: weld vertices, remove degenerate triangles,
  // recompute normals. This produces a cleaner mesh for the slicer.
  const repairedMeshes = repairMeshes(meshes, 0.01);
  switch (format) {
    case 'stl-binary':
      return exportSTL(repairedMeshes, true, name);
    case 'stl-ascii':
      return exportSTL(repairedMeshes, false, name);
    case 'ply':
      return exportPLY(repairedMeshes, true);
    case 'obj': {
      const mat: MaterialType = 'PLA'; // OBJ MTL color is visualization only.
      const { obj, mtl } = exportOBJ(meshesToObjMeshes(repairedMeshes.map(m => ({ mesh: m, name, material: mat }))), name);
      // Combine by zipping.
      return await exportZIP([
        { name: `${name}.obj`, blob: new Blob([obj], { type: 'text/plain' }) },
        { name: `${name}.mtl`, blob: new Blob([mtl], { type: 'text/plain' }) },
      ]);
    }
    case '3mf':
      return await export3MF(repairedMeshes, name);
    default: {
      const _exhaustive: never = format;
      throw new Error(`Unknown export format: ${_exhaustive}`);
    }
  }
}

export function extensionFor(format: ExportFormat): string {
  switch (format) {
    case 'stl-binary':
    case 'stl-ascii':
      return 'stl';
    case 'obj':
      return 'zip'; // OBJ + MTL zipped
    case '3mf':
      return '3mf';
    case 'ply':
      return 'ply';
    default: {
      const _exhaustive: never = format;
      throw new Error(`Unknown export format: ${_exhaustive}`);
    }
  }
}
