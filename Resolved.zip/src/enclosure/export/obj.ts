/**
 * OBJ + MTL exporter.
 *
 * OBJ format (manual implementation):
 *   - List vertices: "v x y z" (apply each mesh's world matrix)
 *   - List faces: "f v1 v2 v3" (1-indexed; offset accumulates across meshes)
 *   - Each mesh preceded by: "o object_name"
 *   - Group tag "g <name>"
 *
 * MTL format:
 *   - "newmtl <material_name>"
 *   - "Kd r g b" — diffuse color
 *
 * Returns { obj, mtl } strings. Caller writes them as separate files (or
 * zips them together).
 */
import * as THREE from 'three';
import type { MaterialType } from '../types';
import { MATERIAL_PRESETS } from '../types';

interface ObjMesh {
  name: string;
  geometry: THREE.BufferGeometry;
  matrixWorld: THREE.Matrix4;
  material: MaterialType;
}

/**
 * Color triple (0-1 range) for the given material.
 */
function materialColorRGB(mat: MaterialType): [number, number, number] {
  const preset = MATERIAL_PRESETS[mat];
  const c = new THREE.Color(preset.color);
  return [c.r, c.g, c.b];
}

/**
 * Build OBJ + MTL text. Returns { obj, mtl }.
 */
export function exportOBJ(meshes: ObjMesh[], name = 'enclosure'): { obj: string; mtl: string } {
  const objLines: string[] = [`# ${name}`, `mtllib ${name}.mtl`];
  const mtlLines: string[] = [`# ${name} materials`];

  // Emit one material per unique material type.
  const seenMaterials = new Set<MaterialType>();
  for (const m of meshes) {
    if (seenMaterials.has(m.material)) continue;
    seenMaterials.add(m.material);
    const [r, g, b] = materialColorRGB(m.material);
    mtlLines.push(`newmtl ${m.material}`);
    mtlLines.push(`Kd ${r.toFixed(4)} ${g.toFixed(4)} ${b.toFixed(4)}`);
    mtlLines.push('illum 2');
  }

  let vertexOffset = 0;
  const v0 = new THREE.Vector3();
  for (const m of meshes) {
    objLines.push(`o ${m.name}`);
    objLines.push(`usemtl ${m.material}`);
    const pos = m.geometry.getAttribute('position');
    if (!pos) continue;
    const matrix = m.matrixWorld;
    // Emit vertices (sanitize NaN/Infinity → 0).
    for (let i = 0; i < pos.count; i++) {
      v0.fromBufferAttribute(pos, i).applyMatrix4(matrix);
      objLines.push(`v ${sanitize(v0.x).toFixed(6)} ${sanitize(v0.y).toFixed(6)} ${sanitize(v0.z).toFixed(6)}`);
    }
    // Emit faces (1-indexed, add vertexOffset).
    const index = m.geometry.getIndex();
    const triCount = index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);
    for (let i = 0; i < triCount; i++) {
      const a = (index ? index.getX(i * 3) : i * 3) + vertexOffset + 1;
      const b = (index ? index.getX(i * 3 + 1) : i * 3 + 1) + vertexOffset + 1;
      const c = (index ? index.getX(i * 3 + 2) : i * 3 + 2) + vertexOffset + 1;
      objLines.push(`f ${a} ${b} ${c}`);
    }
    vertexOffset += pos.count;
  }

  return { obj: objLines.join('\n'), mtl: mtlLines.join('\n') };
}

/** Replace NaN / Infinity with 0 to prevent corrupt output. */
function sanitize(n: number): number {
  return isFinite(n) ? n : 0;
}

/**
 * Helper: build ObjMesh[] from THREE.Mesh[] given a per-mesh material type.
 */
export function meshesToObjMeshes(
  meshes: { mesh: THREE.Mesh; name: string; material: MaterialType }[]
): ObjMesh[] {
  return meshes.map(({ mesh, name, material }) => ({
    name,
    geometry: mesh.geometry as THREE.BufferGeometry,
    matrixWorld: mesh.matrixWorld,
    material,
  }));
}
