/**
 * PLY exporter — binary and ASCII.
 *
 * PLY format:
 *   Header (ASCII):
 *     "ply\n"
 *     "format binary_little_endian 1.0" (or "ascii 1.0")
 *     "element vertex <N>"
 *     "property float x\n property float y\n property float z"
 *     "element face <M>"
 *     "property list uchar int vertex_indices"
 *     "end_header\n"
 *   Then vertex data, then face data.
 *
 * Faces are written as: <count: uchar> <index: int>*count
 */
import * as THREE from 'three';

interface PlyMesh {
  name: string;
  geometry: THREE.BufferGeometry;
  matrixWorld: THREE.Matrix4;
}

function collect(meshes: PlyMesh[]): {
  vertices: Float32Array;
  vertexCount: number;
  faces: Uint32Array;
  faceCount: number;
} {
  let totalV = 0;
  let totalF = 0;
  for (const m of meshes) {
    const pos = m.geometry.getAttribute('position');
    if (!pos) continue;
    totalV += pos.count;
    const index = m.geometry.getIndex();
    totalF += index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);
  }
  const vertices = new Float32Array(totalV * 3);
  const faces = new Uint32Array(totalF * 3);
  let vOff = 0;
  let fOff = 0;
  const v0 = new THREE.Vector3();
  for (const m of meshes) {
    const pos = m.geometry.getAttribute('position');
    if (!pos) continue;
    const matrix = m.matrixWorld;
    for (let i = 0; i < pos.count; i++) {
      v0.fromBufferAttribute(pos, i).applyMatrix4(matrix);
      vertices[vOff * 3] = v0.x;
      vertices[vOff * 3 + 1] = v0.y;
      vertices[vOff * 3 + 2] = v0.z;
      vOff++;
    }
    const index = m.geometry.getIndex();
    const triCount = index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);
    for (let i = 0; i < triCount; i++) {
      const a = index ? index.getX(i * 3) : i * 3;
      const b = index ? index.getX(i * 3 + 1) : i * 3 + 1;
      const c = index ? index.getX(i * 3 + 2) : i * 3 + 2;
      faces[fOff * 3] = a + (vOff - pos.count); // adjust by mesh's offset
      faces[fOff * 3 + 1] = b + (vOff - pos.count);
      faces[fOff * 3 + 2] = c + (vOff - pos.count);
      fOff++;
    }
  }
  return { vertices, vertexCount: totalV, faces, faceCount: totalF };
}

export function exportPLYBinary(meshes: PlyMesh[]): Blob {
  const { vertices, vertexCount, faces, faceCount } = collect(meshes);
  const header =
    `ply\n` +
    `format binary_little_endian 1.0\n` +
    `comment Enclosure export\n` +
    `element vertex ${vertexCount}\n` +
    `property float x\n` +
    `property float y\n` +
    `property float z\n` +
    `element face ${faceCount}\n` +
    `property list uchar int vertex_indices\n` +
    `end_header\n`;
  const headerBytes = new TextEncoder().encode(header);
  // Vertex data: 3 floats (12 bytes) each. Face data: 1 byte + 3 ints (13 bytes) each.
  const buf = new ArrayBuffer(headerBytes.length + vertexCount * 12 + faceCount * 13);
  const view = new DataView(buf);
  // Write header.
  new Uint8Array(buf, 0, headerBytes.length).set(headerBytes);
  let offset = headerBytes.length;
  // Write vertices (sanitize NaN/Infinity → 0).
  for (let i = 0; i < vertexCount; i++) {
    view.setFloat32(offset, sanitize(vertices[i * 3]), true); offset += 4;
    view.setFloat32(offset, sanitize(vertices[i * 3 + 1]), true); offset += 4;
    view.setFloat32(offset, sanitize(vertices[i * 3 + 2]), true); offset += 4;
  }
  // Write faces.
  for (let i = 0; i < faceCount; i++) {
    view.setUint8(offset, 3); offset += 1;
    view.setInt32(offset, faces[i * 3], true); offset += 4;
    view.setInt32(offset, faces[i * 3 + 1], true); offset += 4;
    view.setInt32(offset, faces[i * 3 + 2], true); offset += 4;
  }
  return new Blob([buf], { type: 'application/octet-stream' });
}

export function exportPLYASCII(meshes: PlyMesh[]): Blob {
  const { vertices, vertexCount, faces, faceCount } = collect(meshes);
  const lines: string[] = [
    'ply',
    'format ascii 1.0',
    'comment Enclosure export',
    `element vertex ${vertexCount}`,
    'property float x',
    'property float y',
    'property float z',
    `element face ${faceCount}`,
    'property list uchar int vertex_indices',
    'end_header',
  ];
  for (let i = 0; i < vertexCount; i++) {
    lines.push(
      `${sanitize(vertices[i * 3]).toFixed(6)} ${sanitize(vertices[i * 3 + 1]).toFixed(6)} ${sanitize(vertices[i * 3 + 2]).toFixed(6)}`
    );
  }
  for (let i = 0; i < faceCount; i++) {
    lines.push(`3 ${faces[i * 3]} ${faces[i * 3 + 1]} ${faces[i * 3 + 2]}`);
  }
  return new Blob([lines.join('\n')], { type: 'text/plain' });
}

/** Replace NaN / Infinity with 0 to prevent corrupt binary output. */
function sanitize(n: number): number {
  return isFinite(n) ? n : 0;
}

export function exportPLY(
  meshes: THREE.Mesh[],
  binary = true
): Blob {
  const plyMeshes: PlyMesh[] = meshes.map((m, i) => ({
    name: `part_${i}`,
    geometry: m.geometry as THREE.BufferGeometry,
    matrixWorld: m.matrixWorld,
  }));
  return binary ? exportPLYBinary(plyMeshes) : exportPLYASCII(plyMeshes);
}
