/**
 * STL exporter — binary and ASCII.
 *
 * Binary format (mandatory):
 *   - 80-byte header (we leave it zero-filled except for a "binary" tag).
 *   - uint32 triangle count.
 *   - For each triangle: 12 floats (normal + 3 verts) = 48 bytes + 2-byte
 *     attribute byte count = 50 bytes per triangle.
 *
 * ASCII format:
 *   - "solid <name>"
 *   - For each triangle: "  facet normal nx ny nz\n    outer loop\n      vertex x y z\n..."
 *
 * The exporter walks each mesh's BufferGeometry, applying the mesh's world
 * matrix so multi-mesh exports end up in the same coordinate space.
 */
import * as THREE from 'three';

interface MeshLike {
  geometry: THREE.BufferGeometry;
  matrixWorld: THREE.Matrix4;
}

/**
 * Compute triangle (v0, v1, v2) and its normal for the i-th triangle of the
 * mesh's geometry. Applies the mesh's world matrix to vertices.
 *
 * Skips degenerate triangles (zero area) — these produce NaN normals when
 * normalized and would corrupt the binary STL (NaN bits → slicer reports
 * "Surface area: NaN cm²"). The slicer simply doesn't see them, which is
 * fine because they have zero area anyway.
 */
function* triangles(
  mesh: MeshLike
): Iterable<{ v0: THREE.Vector3; v1: THREE.Vector3; v2: THREE.Vector3; normal: THREE.Vector3 }> {
  const geom = mesh.geometry;
  const pos = geom.getAttribute('position');
  if (!pos) return;
  const index = geom.getIndex();
  const triCount = index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);
  const v0 = new THREE.Vector3();
  const v1 = new THREE.Vector3();
  const v2 = new THREE.Vector3();
  const e1 = new THREE.Vector3();
  const e2 = new THREE.Vector3();
  const n = new THREE.Vector3();
  const matrix = mesh.matrixWorld;
  for (let i = 0; i < triCount; i++) {
    const a = index ? index.getX(i * 3) : i * 3;
    const b = index ? index.getX(i * 3 + 1) : i * 3 + 1;
    const c = index ? index.getX(i * 3 + 2) : i * 3 + 2;
    v0.fromBufferAttribute(pos, a).applyMatrix4(matrix);
    v1.fromBufferAttribute(pos, b).applyMatrix4(matrix);
    v2.fromBufferAttribute(pos, c).applyMatrix4(matrix);
    e1.subVectors(v1, v0);
    e2.subVectors(v2, v0);
    n.crossVectors(e1, e2);
    // Skip degenerate triangles (zero area). Their normal would be NaN
    // after normalize() (0/0 = NaN), which corrupts binary STL output.
    if (n.lengthSq() < 1e-12) continue;
    n.normalize();
    yield { v0, v1, v2, normal: n };
  }
}

/**
 * Count total triangles across meshes.
 */
function countTriangles(meshes: MeshLike[]): number {
  let count = 0;
  for (const m of meshes) {
    const pos = m.geometry.getAttribute('position');
    if (!pos) continue;
    const index = m.geometry.getIndex();
    count += index ? Math.floor(index.count / 3) : Math.floor(pos.count / 3);
  }
  return count;
}

/**
 * Export as binary STL. Returns a Blob.
 *
 * Two-pass approach:
 *   1. Walk all meshes, collect non-degenerate triangles into an array.
 *      (Degenerate triangles would corrupt the binary STL — NaN normals
 *      write NaN bits, which slicers interpret as "Surface area: NaN cm²".)
 *   2. Allocate a buffer sized exactly for the valid triangles, write them.
 *
 * This avoids the bug where the buffer is pre-allocated for ALL triangles
 * but only some are written (leaving zero-filled garbage triangles at the
 * end that the slicer would try to read).
 */
export function exportSTLBinary(meshes: MeshLike[], name = 'enclosure'): Blob {
  // Pass 1: collect valid triangles.
  const collected: { v0: THREE.Vector3; v1: THREE.Vector3; v2: THREE.Vector3; normal: THREE.Vector3 }[] = [];
  for (const mesh of meshes) {
    for (const tri of triangles(mesh)) {
      collected.push({
        v0: tri.v0.clone(),
        v1: tri.v1.clone(),
        v2: tri.v2.clone(),
        normal: tri.normal.clone(),
      });
    }
  }
  const triCount = collected.length;

  // Pass 2: allocate exact buffer and write.
  const buffer = new ArrayBuffer(84 + triCount * 50);
  const dv = new DataView(buffer);
  // Header: 80 bytes. Write a name + null padding.
  const headerStr = `BINARY STL: ${name}`.slice(0, 80);
  for (let i = 0; i < 80; i++) {
    dv.setUint8(i, i < headerStr.length ? headerStr.charCodeAt(i) : 0);
  }
  dv.setUint32(80, triCount, true);
  let offset = 84;
  for (const tri of collected) {
    dv.setFloat32(offset, sanitize(tri.normal.x), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.normal.y), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.normal.z), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v0.x), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v0.y), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v0.z), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v1.x), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v1.y), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v1.z), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v2.x), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v2.y), true); offset += 4;
    dv.setFloat32(offset, sanitize(tri.v2.z), true); offset += 4;
    dv.setUint16(offset, 0, true); offset += 2; // attribute byte count
  }
  return new Blob([buffer], { type: 'application/octet-stream' });
}

/**
 * Sanitize a number for export — replace NaN/Infinity with 0.
 * Belt-and-suspenders defense against corrupt geometry.
 */
function sanitize(n: number): number {
  if (!isFinite(n)) return 0;
  return n;
}

/**
 * Export as ASCII STL. Returns a Blob.
 */
export function exportSTLASCII(meshes: MeshLike[], name = 'enclosure'): Blob {
  const lines: string[] = [`solid ${name}`];
  for (const mesh of meshes) {
    for (const tri of triangles(mesh)) {
      lines.push(`  facet normal ${f(tri.normal.x)} ${f(tri.normal.y)} ${f(tri.normal.z)}`);
      lines.push('    outer loop');
      lines.push(`      vertex ${f(tri.v0.x)} ${f(tri.v0.y)} ${f(tri.v0.z)}`);
      lines.push(`      vertex ${f(tri.v1.x)} ${f(tri.v1.y)} ${f(tri.v1.z)}`);
      lines.push(`      vertex ${f(tri.v2.x)} ${f(tri.v2.y)} ${f(tri.v2.z)}`);
      lines.push('    endloop');
      lines.push('  endfacet');
    }
  }
  lines.push(`endsolid ${name}`);
  return new Blob([lines.join('\n')], { type: 'model/stl' });
}

function f(n: number): string {
  // Use scientific notation for very small/large values, otherwise fixed.
  if (!isFinite(n)) return '0';
  return n.toFixed(6);
}

/**
 * Dispatcher: produce STL Blob in binary or ASCII.
 */
export function exportSTL(
  meshes: THREE.Mesh[],
  binary = true,
  name = 'enclosure'
): Blob {
  const meshLikes: MeshLike[] = meshes.map(m => ({
    geometry: m.geometry as THREE.BufferGeometry,
    matrixWorld: m.matrixWorld,
  }));
  return binary
    ? exportSTLBinary(meshLikes, name)
    : exportSTLASCII(meshLikes, name);
}
