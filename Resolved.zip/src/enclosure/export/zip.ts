/**
 * Multi-part ZIP exporter.
 *
 * Given a list of { name, blob } parts, produce a single ZIP using JSZip.
 */
import JSZip from 'jszip';

export async function exportZIP(parts: { name: string; blob: Blob }[]): Promise<Blob> {
  const zip = new JSZip();
  for (const part of parts) {
    const ab = await part.blob.arrayBuffer();
    zip.file(part.name, ab);
  }
  return zip.generateAsync({ type: 'blob' });
}
