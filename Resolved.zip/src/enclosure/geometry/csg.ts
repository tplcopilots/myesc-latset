/**
 * Constructive Solid Geometry (CSG) wrapper around `three-bvh-csg`.
 *
 * `three-bvh-csg` provides `Brush` (a Mesh subclass that can participate in
 * boolean operations) and `Evaluator` (performs the actual evaluation). The
 * evaluator reads each Brush's `matrixWorld`, so we MUST call
 * `brush.updateMatrixWorld()` before passing it in.
 *
 * Each function below returns a fresh THREE.Mesh whose geometry is the result
 * of the operation. Material is inherited from the target (first) brush.
 *
 * Note: We import directly from `three-bvh-csg/src/index.js` (the ESM build)
 * because the package's default CJS UMD build uses `require('three')` which
 * fails under Bun's strict module-resolution in tests. This is also fine for
 * Next.js's Turbopack which supports explicit paths within packages.
 */
import * as THREE from 'three';
// @ts-expect-error — the .d.ts at the package root types this path correctly.
import { Brush, Evaluator, ADDITION, SUBTRACTION, INTERSECTION } from 'three-bvh-csg/src/index.js';

const evaluator = new Evaluator();
// Disable attribute groups so the output geometry uses a single material —
// simplifies downstream export.
evaluator.useGroups = false;

function toBrush(mesh: THREE.Mesh): Brush {
  // If it's already a Brush, just make sure matrixWorld is current.
  if (mesh instanceof Brush) {
    mesh.updateMatrixWorld();
    return mesh;
  }
  const brush = new Brush(mesh.geometry, mesh.material);
  brush.matrix.copy(mesh.matrix);
  brush.matrixWorld.copy(mesh.matrixWorld);
  brush.matrixAutoUpdate = false;
  // Mark as updated so the evaluator doesn't try to recompute.
  brush.updateMatrixWorld(true);
  return brush;
}

/**
 * Subtract one or more brush meshes from the target mesh. Returns a new Mesh.
 *
 * The evaluator writes the result geometry in the TARGET's local frame (i.e.,
 * it applies the inverse of the target's matrixWorld to the result). To keep
 * the result positioned correctly in world space, we transfer the target's
 * matrix to the returned mesh.
 */
export function subtract(target: THREE.Mesh, ...brushes: THREE.Mesh[]): THREE.Mesh {
  let result = toBrush(target);
  const targetMatrix = result.matrixWorld.clone();
  for (const b of brushes) {
    const brushB = toBrush(b);
    const out = new Brush();
    out.material = target.material;
    evaluator.evaluate(result, brushB, SUBTRACTION, out);
    out.material = target.material;
    result = out;
  }
  // Wrap in a vanilla Mesh. Carry over the target's world matrix.
  const mesh = new THREE.Mesh(result.geometry, target.material);
  mesh.matrixWorld.copy(targetMatrix);
  mesh.matrix.copy(targetMatrix); // also set local matrix in case parent is null
  mesh.matrixAutoUpdate = false;
  mesh.updateMatrixWorld(true);
  return mesh;
}

/**
 * Union the target with one or more brushes. Returns a new Mesh.
 */
export function union(target: THREE.Mesh, ...brushes: THREE.Mesh[]): THREE.Mesh {
  let result = toBrush(target);
  const targetMatrix = result.matrixWorld.clone();
  for (const b of brushes) {
    const brushB = toBrush(b);
    const out = new Brush();
    out.material = target.material;
    evaluator.evaluate(result, brushB, ADDITION, out);
    out.material = target.material;
    result = out;
  }
  const mesh = new THREE.Mesh(result.geometry, target.material);
  mesh.matrixWorld.copy(targetMatrix);
  mesh.matrix.copy(targetMatrix);
  mesh.matrixAutoUpdate = false;
  mesh.updateMatrixWorld(true);
  return mesh;
}

/**
 * Intersect the target with one or more brushes. Returns a new Mesh.
 */
export function intersect(target: THREE.Mesh, ...brushes: THREE.Mesh[]): THREE.Mesh {
  let result = toBrush(target);
  const targetMatrix = result.matrixWorld.clone();
  for (const b of brushes) {
    const brushB = toBrush(b);
    const out = new Brush();
    out.material = target.material;
    evaluator.evaluate(result, brushB, INTERSECTION, out);
    out.material = target.material;
    result = out;
  }
  const mesh = new THREE.Mesh(result.geometry, target.material);
  mesh.matrixWorld.copy(targetMatrix);
  mesh.matrix.copy(targetMatrix);
  mesh.matrixAutoUpdate = false;
  mesh.updateMatrixWorld(true);
  return mesh;
}

/**
 * Create a brush mesh from a geometry + position. Brush is positioned at the
 * given (x, y, z) world coordinates with optional rotation (Euler in radians).
 *
 * The returned Mesh is positioned and ready for CSG.
 */
export function makeBrush(
  geometry: THREE.BufferGeometry,
  position: THREE.Vector3 | [number, number, number],
  rotation?: THREE.Euler | [number, number, number],
  material?: THREE.Material
): THREE.Mesh {
  const m = new THREE.Mesh(
    geometry,
    material ?? new THREE.MeshStandardMaterial({ color: 0x88aacc })
  );
  if (Array.isArray(position)) {
    m.position.set(position[0], position[1], position[2]);
  } else {
    m.position.copy(position);
  }
  if (rotation) {
    if (Array.isArray(rotation)) {
      m.rotation.set(rotation[0], rotation[1], rotation[2]);
    } else {
      m.rotation.copy(rotation);
    }
  }
  m.updateMatrixWorld();
  return m;
}
