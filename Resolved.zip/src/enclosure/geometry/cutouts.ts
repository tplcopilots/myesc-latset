/**
 * Cutout brush builder.
 *
 * Given a cutout definition + the face it lives on + the wall thickness, this
 * module produces a `THREE.Mesh` "brush" positioned correctly so the caller
 * can subtract it from a part mesh.
 *
 * Face convention (enclosure centered at origin, X = width, Y = depth,
 * Z = height; bottom of enclosure sits at z=0):
 *
 *   front  = -Y face
 *   back   = +Y face
 *   left   = -X face
 *   right  = +X face
 *   top    = +Z face (lid)
 *   bottom = -Z face (enclosure floor)
 *
 * The cutout's positionX / positionY are the offsets from the FACE CENTER
 * (in the face's local plane).
 */
import * as THREE from 'three';
import type { Cutout, EnclosureProject, CutoutFace } from '../types';
import {
  boxGeometry,
  cylinderGeometry,
  slotGeometry,
  polygonGeometry,
} from './primitives';

/**
 * Compute the world position of the face center, plus two orthonormal axes
 * (u, v) that span the face plane, and the outward normal `n`.
 *
 * The face's local 2D coordinate (positionX, positionY) maps to:
 *   faceCenter + positionX * u + positionY * v
 */
export function faceBasis(
  face: CutoutFace,
  dims: { width: number; depth: number; height: number }
): {
  center: THREE.Vector3;
  u: THREE.Vector3;
  v: THREE.Vector3;
  n: THREE.Vector3;
  faceSize: { u: number; v: number };
} {
  const { width, depth, height } = dims;
  const cx = 0;
  const cy = 0;
  const cz = height / 2;
  switch (face) {
    case 'front': // -Y face
      return {
        center: new THREE.Vector3(cx, -depth / 2, cz),
        u: new THREE.Vector3(1, 0, 0),
        v: new THREE.Vector3(0, 0, 1),
        n: new THREE.Vector3(0, -1, 0),
        faceSize: { u: width, v: height },
      };
    case 'back': // +Y face
      return {
        center: new THREE.Vector3(cx, depth / 2, cz),
        u: new THREE.Vector3(1, 0, 0),
        v: new THREE.Vector3(0, 0, 1),
        n: new THREE.Vector3(0, 1, 0),
        faceSize: { u: width, v: height },
      };
    case 'left': // -X face
      return {
        center: new THREE.Vector3(-width / 2, cy, cz),
        u: new THREE.Vector3(0, 1, 0),
        v: new THREE.Vector3(0, 0, 1),
        n: new THREE.Vector3(-1, 0, 0),
        faceSize: { u: depth, v: height },
      };
    case 'right': // +X face
      return {
        center: new THREE.Vector3(width / 2, cy, cz),
        u: new THREE.Vector3(0, 1, 0),
        v: new THREE.Vector3(0, 0, 1),
        n: new THREE.Vector3(1, 0, 0),
        faceSize: { u: depth, v: height },
      };
    case 'top': // +Z face (lid)
      return {
        center: new THREE.Vector3(cx, cy, height),
        u: new THREE.Vector3(1, 0, 0),
        v: new THREE.Vector3(0, 1, 0),
        n: new THREE.Vector3(0, 0, 1),
        faceSize: { u: width, v: depth },
      };
    case 'bottom': // -Z face (floor — used for drain holes / cable glands)
      return {
        center: new THREE.Vector3(cx, cy, 0),
        u: new THREE.Vector3(1, 0, 0),
        v: new THREE.Vector3(0, 1, 0),
        n: new THREE.Vector3(0, 0, -1),
        faceSize: { u: width, v: depth },
      };
  }
}

/**
 * Build the brush mesh for a cutout. The brush is a positive mesh positioned
 * slightly larger than the wall, so that subtracting it cleanly punches a hole.
 */
export function buildCutoutBrush(
  cutout: Cutout,
  project: EnclosureProject
): THREE.Mesh {
  const dims = project.dimensions;
  const wall = Math.max(dims.wallThickness, cutout.depth);
  const { center, u, v, n } = faceBasis(cutout.face, dims);

  // Position of cutout center on the face plane (local face coords).
  const pos = center.clone().addScaledVector(u, cutout.positionX).addScaledVector(v, cutout.positionY);
  // Push the brush slightly into the wall (+ along normal by wall/2) so the
  // brush spans the entire wall thickness.
  const startPos = pos.clone().addScaledVector(n, -0.01);
  // Total extrude depth — must clear the wall fully; use 1.5× wall to be safe.
  const extrudeDepth = Math.max(wall + 1.0, cutout.depth + 1.0);

  let geom: THREE.BufferGeometry;
  switch (cutout.shape) {
    case 'rectangle': {
      geom = boxGeometry(cutout.width, cutout.height, extrudeDepth);
      break;
    }
    case 'rounded-rectangle': {
      geom = slotGeometry(cutout.width, cutout.height, extrudeDepth, cutout.cornerRadius);
      break;
    }
    case 'circle': {
      geom = cylinderGeometry(cutout.diameter / 2, extrudeDepth, 32, false, 'z');
      break;
    }
    case 'slot': {
      geom = slotGeometry(cutout.width, cutout.height, extrudeDepth, cutout.cornerRadius || Math.min(cutout.height, cutout.width) / 2 - 0.1);
      break;
    }
    case 'polygon': {
      geom = polygonGeometry(cutout.points, extrudeDepth);
      break;
    }
    default: {
      geom = boxGeometry(cutout.width || 5, cutout.height || 5, extrudeDepth);
    }
  }

  // The geometry is created with axis along Z (extrude along Z). We need to
  // rotate so its Z axis aligns with the face normal `n`. Then translate to
  // startPos.
  const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial());
  // Orient: Z axis of mesh -> n. Use Quaternion.setFromUnitVectors.
  mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0, 0, 1), n.clone().normalize());
  mesh.position.copy(startPos);
  // If rotation (about face normal) is provided, apply it AFTER the initial
  // quaternion orientation. We pre-multiply with a rotation about Z.
  if (cutout.rotation) {
    const r = (cutout.rotation * Math.PI) / 180;
    const q = new THREE.Quaternion().setFromAxisAngle(n.clone().normalize(), r);
    mesh.quaternion.premultiply(q);
  }
  mesh.updateMatrixWorld();
  return mesh;
}

/**
 * Get the face dimensions (width along u, depth along v) for a face on the
 * given project dimensions. Useful for the cutout UI to clamp positions.
 */
export function faceSize(
  face: CutoutFace,
  dims: { width: number; depth: number; height: number }
): { u: number; v: number } {
  return faceBasis(face, dims).faceSize;
}
