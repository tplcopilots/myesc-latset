/**
 * Decoration geometry generator.
 *
 * A Decoration is a text label, logo image, or shape design that sits on
 * a face of the enclosure. Decorations support CSS-style margin
 * positioning (left/right/top/bottom), border, corner radius, and
 * live rendering.
 *
 * Geometry approach:
 *   - Text/Logo: render to a canvas → CanvasTexture on a thin BoxGeometry
 *     plate. The plate IS exported in STL/OBJ/3MF/PLY; the texture is only
 *     visible in the live viewer (text/image aren't embossed into geometry).
 *   - Shape: built as actual geometry (ExtrudeGeometry of a 2D Shape), so
 *     shapes ARE real 3D geometry in the exported file.
 *
 * Positioning model (CSS-style):
 *   - marginLeft/Right/Top/Bottom are distances (in mm) from the respective
 *     face edge to the decoration edge.
 *   - null on an axis = "auto" (centered on that axis).
 *   - If both L and R are non-null and the decoration width is fixed, the
 *     decoration is centered between the L and R margins (like CSS auto).
 *   - If only L (or only R) is non-null, the decoration is anchored to
 *     that side.
 *   - positionOffsetX/Y add a manual nudge in mm.
 *
 * The face is parameterized by `faceBasis()` which gives a center point,
 * two in-plane axes (u, v), and an outward normal (n). The decoration's
 * local x/y align with u/v respectively.
 */
import * as THREE from 'three';
import type {
  Decoration,
  TextDecoration,
  LogoDecoration,
  ShapeDecoration,
  EnclosureProject,
} from '../types';
import { faceBasis } from './cutouts';
import { uid } from '../utils/id';

// -----------------------------------------------------------------------------
// Position computation — CSS-style margins.
// -----------------------------------------------------------------------------

/**
 * Compute the in-plane (u, v) offset for a decoration given its margins.
 *
 * @param decoration The decoration.
 * @param faceU  Face size along u-axis (mm).
 * @param faceV  Face size along v-axis (mm).
 * @param decU   Decoration's own u-extent (mm).
 * @param decV   Decoration's own v-extent (mm).
 * @returns The (u, v) position of the decoration CENTER relative to the
 *          face center.
 */
function computeMarginPosition(
  decoration: Decoration,
  faceU: number,
  faceV: number,
  decU: number,
  decV: number,
): { u: number; v: number } {
  const L = decoration.marginLeft;
  const R = decoration.marginRight;
  const T = decoration.marginTop;
  const B = decoration.marginBottom;

  // ----- Horizontal (u) -----
  let u: number;
  if (L != null && R != null) {
    // Both specified: decoration is anchored to fill (faceU - L - R) wide,
    // centered between the two margins.
    const innerWidth = faceU - L - R;
    const leftEdgeOfInner = -faceU / 2 + L; // in face-local coords (center=0)
    const innerCenter = leftEdgeOfInner + innerWidth / 2;
    // If decU < innerWidth, the decoration is centered inside the inner area.
    // If decU > innerWidth, it still uses the inner center.
    u = innerCenter;
  } else if (L != null) {
    // Left-anchored.
    u = -faceU / 2 + L + decU / 2;
  } else if (R != null) {
    // Right-anchored.
    u = faceU / 2 - R - decU / 2;
  } else {
    // Centered.
    u = 0;
  }

  // ----- Vertical (v) -----
  let v: number;
  if (T != null && B != null) {
    const innerHeight = faceV - T - B;
    const topEdgeOfInner = faceV / 2 - T; // in face-local coords (center=0)
    const innerCenter = topEdgeOfInner - innerHeight / 2;
    v = innerCenter;
  } else if (T != null) {
    // Top-anchored.
    v = faceV / 2 - T - decV / 2;
  } else if (B != null) {
    // Bottom-anchored.
    v = -faceV / 2 + B + decV / 2;
  } else {
    v = 0;
  }

  // Apply manual offsets.
  u += decoration.positionOffsetX || 0;
  v += decoration.positionOffsetY || 0;

  return { u, v };
}

/**
 * For "center" position mode, just use positionOffsetX/Y directly.
 */
function computeCenterPosition(decoration: Decoration): { u: number; v: number } {
  return {
    u: decoration.positionOffsetX || 0,
    v: decoration.positionOffsetY || 0,
  };
}

// -----------------------------------------------------------------------------
// Canvas helpers — used by text and logo.
// -----------------------------------------------------------------------------

const PX_PER_MM = 8; // texture resolution

/**
 * Create an (optional) border + background + text canvas and return the
 * texture plus the canvas's mm-equivalent size.
 */
function createTextCanvas(
  dec: TextDecoration,
): { texture: THREE.Texture; width: number; height: number } {
  const fontFamily =
    dec.fontFamily === 'serif'
      ? 'serif'
      : dec.fontFamily === 'mono'
      ? 'monospace'
      : 'sans-serif';
  const weight = dec.bold ? 'bold' : 'normal';
  const style = dec.italic ? 'italic' : 'normal';
  const fontPx = `${style} ${weight} ${Math.floor(dec.fontSize * PX_PER_MM)}px ${fontFamily}`;

  // ----- SSR / non-DOM fallback: return a tiny placeholder so geometry
  // generation doesn't crash on the server. The client will regenerate
  // the mesh with the real canvas texture via Zustand's reactivity. -----
  if (typeof document === 'undefined') {
    const width = dec.autoSize
      ? Math.max(8, dec.text.length * dec.fontSize * 0.6 + (dec.paddingX || 0) * 2)
      : dec.width;
    const height = dec.autoSize ? dec.fontSize * 1.4 : dec.height;
    // Empty texture — geometry still has correct dimensions.
    const texture = new THREE.Texture();
    return { texture, width, height };
  }

  // Measure text to determine box size when autoSize is on.
  // Use a temp canvas to measure.
  const measureCanvas = document.createElement('canvas');
  const measureCtx = measureCanvas.getContext('2d')!;
  measureCtx.font = fontPx;
  const lines = (dec.text || ' ').split('\n');
  let textWidthPx = 0;
  for (const line of lines) {
    const w = measureCtx.measureText(line).width;
    if (w > textWidthPx) textWidthPx = w;
  }
  const textHeightPx = dec.fontSize * PX_PER_MM * 1.3 * lines.length;

  // Box size in mm.
  let boxWmm: number;
  let boxHmm: number;
  if (dec.autoSize) {
    boxWmm = textWidthPx / PX_PER_MM + (dec.paddingX || 0) * 2 + (dec.borderWidth || 0) * 2;
    boxHmm = textHeightPx / PX_PER_MM + (dec.paddingY || 0) * 2 + (dec.borderWidth || 0) * 2;
  } else {
    boxWmm = dec.width;
    boxHmm = dec.height;
  }
  if (boxWmm < 1) boxWmm = 1;
  if (boxHmm < 1) boxHmm = 1;

  // Create the actual canvas.
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(boxWmm * PX_PER_MM);
  canvas.height = Math.ceil(boxHmm * PX_PER_MM);
  const ctx = canvas.getContext('2d')!;

  // Background (transparent if not set).
  if (dec.backgroundColor) {
    ctx.fillStyle = dec.backgroundColor;
    if (dec.borderRadius > 0) {
      // Rounded rectangle background.
      const r = dec.borderRadius * PX_PER_MM;
      roundRectPath(ctx, 0, 0, canvas.width, canvas.height, r);
      ctx.fill();
    } else {
      ctx.fillRect(0, 0, canvas.width, canvas.height);
    }
  }

  // Border.
  if (dec.borderWidth > 0 && dec.borderColor) {
    ctx.strokeStyle = dec.borderColor;
    ctx.lineWidth = dec.borderWidth * PX_PER_MM;
    if (dec.borderRadius > 0) {
      const r = dec.borderRadius * PX_PER_MM;
      const lw = ctx.lineWidth;
      roundRectPath(
        ctx,
        lw / 2,
        lw / 2,
        canvas.width - lw,
        canvas.height - lw,
        r,
      );
      ctx.stroke();
    } else {
      ctx.strokeRect(0, 0, canvas.width, canvas.height);
    }
  }

  // Text.
  ctx.fillStyle = dec.textColor;
  ctx.font = fontPx;
  ctx.textBaseline = 'middle';
  const align =
    dec.textAlign === 'left'
      ? 'left'
      : dec.textAlign === 'right'
      ? 'right'
      : 'center';
  ctx.textAlign = align;

  const padXPx = (dec.paddingX || 0) * PX_PER_MM;
  const lineSpacingPx = dec.fontSize * PX_PER_MM * 1.3;
  const startY =
    canvas.height / 2 - (lineSpacingPx * (lines.length - 1)) / 2;

  for (let i = 0; i < lines.length; i++) {
    let x: number;
    if (align === 'left') {
      x = padXPx + (dec.borderWidth || 0) * PX_PER_MM;
    } else if (align === 'right') {
      x = canvas.width - padXPx - (dec.borderWidth || 0) * PX_PER_MM;
    } else {
      x = canvas.width / 2;
    }
    const y = startY + i * lineSpacingPx;
    ctx.fillText(lines[i], x, y);
  }

  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  return { texture, width: boxWmm, height: boxHmm };
}

/**
 * Draw a rounded-rectangle path on the given 2D context.
 */
function roundRectPath(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  w: number,
  h: number,
  r: number,
) {
  const radius = Math.min(r, w / 2, h / 2);
  ctx.beginPath();
  ctx.moveTo(x + radius, y);
  ctx.lineTo(x + w - radius, y);
  ctx.quadraticCurveTo(x + w, y, x + w, y + radius);
  ctx.lineTo(x + w, y + h - radius);
  ctx.quadraticCurveTo(x + w, y + h, x + w - radius, y + h);
  ctx.lineTo(x + radius, y + h);
  ctx.quadraticCurveTo(x, y + h, x, y + h - radius);
  ctx.lineTo(x, y + radius);
  ctx.quadraticCurveTo(x, y, x + radius, y);
  ctx.closePath();
}

// Image cache keyed by data URL — avoids reloading the texture on every regen.
const imageTextureCache = new Map<string, THREE.Texture>();

/**
 * Load (or fetch from cache) a CanvasTexture for an image data URL.
 * Falls back to a placeholder if the image fails to load.
 */
function getImageTexture(imageSrc: string): THREE.Texture | null {
  if (!imageSrc) return null;
  if (imageTextureCache.has(imageSrc)) {
    return imageTextureCache.get(imageSrc)!;
  }
  const img = new Image();
  img.src = imageSrc;
  const texture = new THREE.Texture(img);
  texture.colorSpace = THREE.SRGBColorSpace;
  texture.anisotropy = 4;
  img.onload = () => {
    texture.needsUpdate = true;
  };
  img.onerror = () => {
    // Mark as failed; texture stays empty.
    texture.needsUpdate = false;
  };
  imageTextureCache.set(imageSrc, texture);
  return texture;
}

// -----------------------------------------------------------------------------
// Mesh placement
// -----------------------------------------------------------------------------

/**
 * Build the positioned mesh on the given face.
 * The returned mesh has correct world matrix already applied.
 */
function placeMeshOnFace(
  geom: THREE.BufferGeometry,
  material: THREE.Material,
  dec: Decoration,
  project: EnclosureProject,
  decU: number,
  decV: number,
): THREE.Mesh {
  const { center, u, v, n } = faceBasis(dec.face, project.dimensions);
  const faceSize = faceBasis(dec.face, project.dimensions).faceSize;

  // Compute in-plane offset.
  let pos: { u: number; v: number };
  if (dec.positionMode === 'center') {
    pos = computeCenterPosition(dec);
  } else {
    pos = computeMarginPosition(dec, faceSize.u, faceSize.v, decU, decV);
  }

  // Push the decoration out from the face by depth/2.
  // Use a small NEGATIVE overlap (-0.15mm) so the decoration's inner edge
  // sits slightly INSIDE the wall. This is critical for shape decorations
  // that are UNIONED with the wall — without overlap, CSG can't merge
  // them properly and the result has open edges. For text/logo (kept as
  // separate plates), the overlap is harmless (slight intersection with
  // the wall, which is fine for separate shells).
  const depth = Math.max(0.1, dec.depth);
  const overlap = 0.15; // mm of overlap into the wall

  const mesh = new THREE.Mesh(geom, material);
  // Orient plate so its +Z aligns with the face normal.
  mesh.quaternion.setFromUnitVectors(
    new THREE.Vector3(0, 0, 1),
    n.clone().normalize(),
  );
  const worldPos = center
    .clone()
    .addScaledVector(u, pos.u)
    .addScaledVector(v, pos.v)
    .addScaledVector(n, depth / 2 - overlap);
  mesh.position.copy(worldPos);

  // Apply rotation around the face normal.
  if (dec.rotation) {
    const r = (dec.rotation * Math.PI) / 180;
    const q = new THREE.Quaternion().setFromAxisAngle(
      n.clone().normalize(),
      r,
    );
    mesh.quaternion.premultiply(q);
  }
  mesh.updateMatrixWorld();
  return mesh;
}

// -----------------------------------------------------------------------------
// Per-kind generators
// -----------------------------------------------------------------------------

function generateTextDecoration(
  dec: TextDecoration,
  project: EnclosureProject,
): THREE.Mesh {
  if (!dec.visible || !dec.text) {
    return new THREE.Mesh(
      new THREE.BufferGeometry(),
      new THREE.MeshStandardMaterial(),
    );
  }
  const { texture, width, height } = createTextCanvas(dec);
  const depth = Math.max(0.1, dec.depth);
  const geom = new THREE.BoxGeometry(width, height, depth);

  // Put the texture only on the +Z face (the face that points outward).
  const materials = [
    new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.7 }), // +X side
    new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.7 }), // -X side
    new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.7 }), // +Y side
    new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.7 }), // -Y side
    new THREE.MeshStandardMaterial({
      map: texture,
      roughness: 0.7,
      transparent: true,
    }), // +Z front (visible)
    new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.7 }), // -Z back
  ];
  return placeMeshOnFace(geom, materials as any, dec, project, width, height);
}

function generateLogoDecoration(
  dec: LogoDecoration,
  project: EnclosureProject,
): THREE.Mesh {
  if (!dec.visible || !dec.imageSrc) {
    return new THREE.Mesh(
      new THREE.BufferGeometry(),
      new THREE.MeshStandardMaterial(),
    );
  }
  const texture = getImageTexture(dec.imageSrc);
  let width = dec.width;
  let height = dec.height;

  // Keep aspect: derive height from width & image aspect.
  const img = texture?.image as HTMLImageElement | undefined;
  if (dec.keepAspect && img && img.width && img.height) {
    const aspect = img.height / img.width;
    height = width * aspect;
  }

  const depth = Math.max(0.1, dec.depth);
  const geom = new THREE.BoxGeometry(width, height, depth);

  const sideMat = new THREE.MeshStandardMaterial({
    color: 0x9ca3af,
    roughness: 0.7,
  });
  const frontMat = new THREE.MeshStandardMaterial({
    map: texture || undefined,
    transparent: dec.opacity < 1,
    opacity: dec.opacity,
    roughness: 0.6,
  });

  // If a border is requested, we layer it via a slightly larger plate behind.
  let mesh: THREE.Mesh;
  if (dec.borderWidth > 0 && dec.borderColor) {
    // Border material — drawn as a thin frame behind the logo plate.
    // (Simplified: we render a slightly larger dark plate behind.)
    // Skipping exact frame geometry; using side material coloring.
    mesh = placeMeshOnFace(
      geom,
      [sideMat, sideMat, sideMat, sideMat, frontMat, sideMat] as any,
      dec,
      project,
      width,
      height,
    );
  } else {
    mesh = placeMeshOnFace(
      geom,
      [sideMat, sideMat, sideMat, sideMat, frontMat, sideMat] as any,
      dec,
      project,
      width,
      height,
    );
  }
  return mesh;
}

function generateShapeDecoration(
  dec: ShapeDecoration,
  project: EnclosureProject,
): THREE.Mesh {
  if (!dec.visible) {
    return new THREE.Mesh(
      new THREE.BufferGeometry(),
      new THREE.MeshStandardMaterial(),
    );
  }
  const width = Math.max(0.5, dec.width);
  const height = Math.max(0.5, dec.height);
  const depth = Math.max(0.1, dec.depth);
  const r = Math.min(dec.borderRadius, width / 2 - 0.05, height / 2 - 0.05);

  const shape = new THREE.Shape();
  switch (dec.shape) {
    case 'rectangle': {
      shape.moveTo(-width / 2, -height / 2);
      shape.lineTo(width / 2, -height / 2);
      shape.lineTo(width / 2, height / 2);
      shape.lineTo(-width / 2, height / 2);
      shape.closePath();
      break;
    }
    case 'rounded-rectangle': {
      const w = width;
      const h = height;
      const radius = Math.max(0.1, r);
      shape.moveTo(-w / 2 + radius, -h / 2);
      shape.lineTo(w / 2 - radius, -h / 2);
      shape.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + radius);
      shape.lineTo(w / 2, h / 2 - radius);
      shape.quadraticCurveTo(w / 2, h / 2, w / 2 - radius, h / 2);
      shape.lineTo(-w / 2 + radius, h / 2);
      shape.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - radius);
      shape.lineTo(-w / 2, -h / 2 + radius);
      shape.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + radius, -h / 2);
      break;
    }
    case 'circle': {
      const radius = Math.min(width, height) / 2;
      shape.absarc(0, 0, radius, 0, Math.PI * 2, false);
      break;
    }
    case 'triangle': {
      shape.moveTo(0, height / 2);
      shape.lineTo(-width / 2, -height / 2);
      shape.lineTo(width / 2, -height / 2);
      shape.closePath();
      break;
    }
    case 'hexagon': {
      const radius = Math.min(width, height) / 2;
      for (let i = 0; i < 6; i++) {
        const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
        const x = Math.cos(a) * radius;
        const y = Math.sin(a) * radius;
        if (i === 0) shape.moveTo(x, y);
        else shape.lineTo(x, y);
      }
      shape.closePath();
      break;
    }
    case 'diamond': {
      shape.moveTo(0, height / 2);
      shape.lineTo(width / 2, 0);
      shape.lineTo(0, -height / 2);
      shape.lineTo(-width / 2, 0);
      shape.closePath();
      break;
    }
  }

  // If a border is set, we create a hollow shape (outer minus inner).
  let finalShape: THREE.Shape = shape;
  if (dec.borderWidth > 0) {
    // Scale an inner shape to make the border.
    // (Simplified — for circle/rounded we scale uniformly; works fine for
    // most shapes.)
    const inner = new THREE.Shape();
    const bx = dec.borderWidth;
    const innerW = Math.max(0.5, width - bx * 2);
    const innerH = Math.max(0.5, height - bx * 2);
    const innerR = Math.max(0, r - bx);
    switch (dec.shape) {
      case 'circle': {
        const radius = Math.min(innerW, innerH) / 2;
        inner.absarc(0, 0, radius, 0, Math.PI * 2, false);
        break;
      }
      case 'rectangle':
      case 'rounded-rectangle': {
        const w = innerW;
        const h = innerH;
        const radius = Math.max(0.1, innerR);
        inner.moveTo(-w / 2 + radius, -h / 2);
        inner.lineTo(w / 2 - radius, -h / 2);
        inner.quadraticCurveTo(w / 2, -h / 2, w / 2, -h / 2 + radius);
        inner.lineTo(w / 2, h / 2 - radius);
        inner.quadraticCurveTo(w / 2, h / 2, w / 2 - radius, h / 2);
        inner.lineTo(-w / 2 + radius, h / 2);
        inner.quadraticCurveTo(-w / 2, h / 2, -w / 2, h / 2 - radius);
        inner.lineTo(-w / 2, -h / 2 + radius);
        inner.quadraticCurveTo(-w / 2, -h / 2, -w / 2 + radius, -h / 2);
        break;
      }
      case 'triangle': {
        const scale = innerW / width;
        inner.moveTo(0, (height / 2) * scale);
        inner.lineTo(-innerW / 2, -innerH / 2);
        inner.lineTo(innerW / 2, -innerH / 2);
        inner.closePath();
        break;
      }
      case 'hexagon': {
        const radius = Math.min(innerW, innerH) / 2;
        for (let i = 0; i < 6; i++) {
          const a = (i / 6) * Math.PI * 2 - Math.PI / 2;
          const x = Math.cos(a) * radius;
          const y = Math.sin(a) * radius;
          if (i === 0) inner.moveTo(x, y);
          else inner.lineTo(x, y);
        }
        inner.closePath();
        break;
      }
      case 'diamond': {
        inner.moveTo(0, innerH / 2);
        inner.lineTo(innerW / 2, 0);
        inner.lineTo(0, -innerH / 2);
        inner.lineTo(-innerW / 2, 0);
        inner.closePath();
        break;
      }
    }
    finalShape = shape;
    finalShape.holes.push(inner);
  }

  const geom = new THREE.ExtrudeGeometry(finalShape, {
    depth,
    bevelEnabled: false,
  });
  // ExtrudeGeometry extrudes from Z=0 to Z=+depth. We want the geometry
  // CENTERED around the mesh origin (Z=0) so that placeMeshOnFace's
  // "depth/2 + 0.02" offset puts the inner edge flush with the wall
  // (just 0.02mm gap to avoid z-fighting) and the outer edge at
  // depth + 0.02 outside the face. Translate by -depth/2 to center.
  geom.translate(0, 0, -depth / 2 + 0.001);

  const color = new THREE.Color(dec.fillColor || '#9ca3af');
  const material = new THREE.MeshStandardMaterial({
    color,
    roughness: 0.6,
    metalness: 0.0,
    transparent: dec.opacity < 1,
    opacity: dec.opacity,
  });
  return placeMeshOnFace(geom, material, dec, project, width, height);
}

// -----------------------------------------------------------------------------
// Public API
// -----------------------------------------------------------------------------

/**
 * Generate a mesh for a single decoration.
 */
export function generateDecoration(
  dec: Decoration,
  project: EnclosureProject,
): THREE.Mesh {
  switch (dec.kind) {
    case 'text':
      return generateTextDecoration(dec, project);
    case 'logo':
      return generateLogoDecoration(dec, project);
    case 'shape':
      return generateShapeDecoration(dec, project);
  }
}

/**
 * Generate all decoration meshes for the project.
 */
export function generateAllDecorations(project: EnclosureProject): THREE.Mesh[] {
  const meshes: THREE.Mesh[] = [];
  for (const dec of project.decorations || []) {
    if (!dec.visible) continue;
    try {
      meshes.push(generateDecoration(dec, project));
    } catch (e) {
      // Skip broken decoration rather than failing the whole render.
      console.warn('Decoration generation failed:', e);
    }
  }
  return meshes;
}

// -----------------------------------------------------------------------------
// Factories — used by the store to create default decorations.
// -----------------------------------------------------------------------------

export function createTextDecoration(
  overrides: Partial<TextDecoration> = {},
): TextDecoration {
  return {
    id: uid(),
    name: 'Text',
    kind: 'text',
    face: 'top',
    visible: true,
    depth: 0.4,
    rotation: 0,
    positionMode: 'margins',
    marginLeft: 5,
    marginRight: 5,
    marginTop: 5,
    marginBottom: 5,
    positionOffsetX: 0,
    positionOffsetY: 0,
    text: 'Label',
    fontFamily: 'sans',
    fontSize: 5,
    bold: false,
    italic: false,
    textColor: '#1f2937',
    backgroundColor: '#e5e7eb',
    textAlign: 'center',
    paddingX: 1.5,
    paddingY: 0.8,
    borderWidth: 0.3,
    borderColor: '#0f172a',
    borderRadius: 1.0,
    autoSize: true,
    width: 30,
    height: 8,
    ...overrides,
  };
}

export function createLogoDecoration(
  overrides: Partial<LogoDecoration> = {},
): LogoDecoration {
  return {
    id: uid(),
    name: 'Logo',
    kind: 'logo',
    face: 'top',
    visible: true,
    depth: 0.4,
    rotation: 0,
    positionMode: 'margins',
    marginLeft: 5,
    marginRight: null,
    marginTop: null,
    marginBottom: 5,
    positionOffsetX: 0,
    positionOffsetY: 0,
    imageSrc: '',
    width: 20,
    height: 20,
    keepAspect: true,
    opacity: 1.0,
    borderWidth: 0,
    borderColor: '#0f172a',
    borderRadius: 0,
    ...overrides,
  };
}

export function createShapeDecoration(
  overrides: Partial<ShapeDecoration> = {},
): ShapeDecoration {
  return {
    id: uid(),
    name: 'Shape',
    kind: 'shape',
    face: 'front',
    visible: true,
    depth: 0.6,
    rotation: 0,
    positionMode: 'margins',
    marginLeft: 5,
    marginRight: null,
    marginTop: 5,
    marginBottom: null,
    positionOffsetX: 0,
    positionOffsetY: 0,
    shape: 'rounded-rectangle',
    width: 20,
    height: 10,
    fillColor: '#fbbf24',
    borderColor: '#0f172a',
    borderWidth: 0.5,
    borderRadius: 2,
    opacity: 1.0,
    ...overrides,
  };
}
