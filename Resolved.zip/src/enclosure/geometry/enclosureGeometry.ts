/**
 * Main enclosure geometry generator.
 *
 * Produces:
 *   - bottom: the bottom half of the enclosure (walls + floor), with cutouts
 *     and ventilation subtracted, plus screw bosses added on the floor.
 *   - lid: the top lid (varies by type).
 *
 * Convention: enclosure is centered on the origin in X and Y, with the floor
 * at z=0 and walls extending upward to z=height. This makes PCB standoffs and
 * feet placement straightforward.
 */
import * as THREE from 'three';
import type { EnclosureProject, GeneratedPart } from '../types';
import {
  boxGeometry,
  roundedBoxGeometry,
  cylinderGeometry,
} from './primitives';
import { subtract, union } from './csg';
import { buildCutoutBrush } from './cutouts';
import { applyVentilationTo } from './ventilation';
import {
  generateScrewBoss,
  generateCountersinkBoss,
  generateThroughHole,
  generateCounterbore,
} from './screws';
import { generateLabel } from './labels';
import { generateDecoration } from './decorations';
import {
  generateScrewMounts,
  generateBatteryCompartmentBrush,
  generateBackFeaturesBrushes,
} from './internalLayout';
import { generateAllPcbBoards } from './pcbBoard';

/**
 * Material used by all generated parts. The viewer replaces this with the
 * project material (color/roughness/metalness) at render time.
 */
function defaultMaterial(): THREE.Material {
  return new THREE.MeshStandardMaterial({
    color: 0x9ca3af,
    roughness: 0.5,
    metalness: 0.0,
  });
}

/** Convenience type alias — Mesh whose material may be a single Material. */
type AnyMesh = THREE.Mesh;

/**
 * Build the outer shell of the enclosure: a rounded box (or sharp box) of the
 * full outer dimensions. Centered on the X/Y plane, floor at z=0, top at
 * z=height.
 */
function buildOuterShell(project: EnclosureProject): THREE.Mesh {
  const { width, depth, height, cornerRadius, edgeBevel, draftAngle } = project.dimensions;
  // Use rounded box if corner radius or edge bevel is specified.
  const effectiveRadius = Math.max(cornerRadius, edgeBevel || 0);
  let geom: THREE.BufferGeometry;
  if (effectiveRadius > 0.01) {
    geom = roundedBoxGeometry(width, depth, height, effectiveRadius, 8);
  } else {
    geom = boxGeometry(width, depth, height);
  }

  // Apply draft angle — taper walls inward from bottom to top.
  // Only affects vertices on the TOP face (z > height/2 - epsilon) to
  // avoid distorting the curved corners/bevels which would break manifold.
  if (draftAngle && draftAngle > 0.01) {
    const halfH = height / 2;
    const draftRad = (draftAngle * Math.PI) / 180;
    const taper = Math.tan(draftRad) * halfH * 0.5; // taper amount at the top
    const pos = geom.getAttribute('position');
    for (let i = 0; i < pos.count; i++) {
      const z = pos.getZ(i);
      // Only taper vertices that are at the TOP of the box (within 0.1mm of the top).
      if (z > halfH - 0.5) {
        const factor = 1 - taper / Math.max(width, depth);
        pos.setX(i, pos.getX(i) * factor);
        pos.setY(i, pos.getY(i) * factor);
      }
    }
    pos.needsUpdate = true;
    geom.computeVertexNormals();
  }

  // Both geometries are centered at origin. Move so the floor is at z=0.
  geom.translate(0, 0, height / 2);
  const mesh = new THREE.Mesh(geom, defaultMaterial());
  mesh.updateMatrixWorld();
  return mesh;
}

/**
 * Build the interior cavity brush: a slightly smaller box that we subtract
 * from the outer shell to hollow it out.
 */
function buildCavityBrush(project: EnclosureProject): THREE.Mesh {
  const { width, depth, height, wallThickness, floorThickness } = project.dimensions;
  const innerW = Math.max(0.5, width - 2 * wallThickness);
  const innerD = Math.max(0.5, depth - 2 * wallThickness);
  const innerH = Math.max(0.5, height - floorThickness - wallThickness);
  const geom = boxGeometry(innerW, innerD, innerH);
  // Position the cavity so the bottom of the cavity sits at z = floorThickness.
  geom.translate(0, 0, floorThickness + innerH / 2);
  const mesh = new THREE.Mesh(geom, defaultMaterial());
  mesh.updateMatrixWorld();
  return mesh;
}

/**
 * Generate the bottom part of the enclosure: outer shell minus interior
 * cavity, with cutouts, ventilation, and screw bosses.
 */
export function generateBottom(project: EnclosureProject): GeneratedPart {
  const material = defaultMaterial();
  let mesh: AnyMesh = buildOuterShell(project);

  // Hollow out: subtract the cavity.
  const cavity = buildCavityBrush(project);
  mesh = subtract(mesh, cavity);
  mesh.material = material;

  // Apply cutouts on every face. Skip the top face — that's the lid's job.
  for (const cutout of project.cutouts) {
    if (!cutout.visible) continue;
    if (cutout.face === 'top') continue; // top is the lid
    const brush = buildCutoutBrush(cutout, project);
    mesh = subtract(mesh, brush);
  }
  mesh.material = material;

  // Apply ventilation.
  mesh = applyVentilationTo(mesh, project);
  mesh.material = material;

  // Add screw bosses at the four interior corners (for screw-style lids).
  if (
    project.lid.type === 'screw' ||
    project.lid.type === 'captive-screw'
  ) {
    const { width, depth, height, wallThickness, floorThickness } = project.dimensions;
    const inset = Math.max(wallThickness + 3, project.screw.headDiameter + 1);
    const bossH = Math.max(3, height - floorThickness - wallThickness - 3);
    const bossD = Math.max(project.screw.headDiameter + 2, 6);
    const corners: [number, number][] = [
      [width / 2 - inset, depth / 2 - inset],
      [-width / 2 + inset, depth / 2 - inset],
      [width / 2 - inset, -depth / 2 + inset],
      [-width / 2 + inset, -depth / 2 + inset],
    ];
    for (const [x, y] of corners) {
      let boss: THREE.Mesh;
      if (project.lid.type === 'captive-screw') {
        boss = generateCountersinkBoss(
          project.screw,
          new THREE.Vector3(x, y, floorThickness),
          bossH,
          bossD
        );
      } else {
        boss = generateScrewBoss(
          project.screw,
          new THREE.Vector3(x, y, floorThickness),
          bossH,
          bossD
        );
      }
      boss.material = material;
      mesh = union(mesh, boss);
    }
    mesh.material = material;
  }

  // Snap-fit: create snap-fit hooks as SEPARATE closed meshes.
  // OLD code used CSG union to merge hooks with the wall, but this produced
  // ~770 open edges per enclosure (CSG numerical issues along the intersection
  // curve between the hook cylinder and the wall). Keeping hooks as separate
  // closed-solid meshes eliminates those open edges. Slicers handle
  // overlapping shells correctly (they merge coincident geometry during slicing).
  const snapFitHooks: THREE.Mesh[] = [];
  if (project.snapFit.enabled) {
    snapFitHooks.push(...createSnapFitHooks(project, material));
  }

  // Internal support posts: same approach — keep as separate closed meshes.
  const internalSupports: THREE.Mesh[] = [];
  if (project.internalSupport.enabled) {
    internalSupports.push(...createInternalSupports(project, material));
  }

  // Labels.
  const labels: THREE.Mesh[] = [];
  for (const label of project.labels) {
    if (!label.enabled) continue;
    labels.push(generateLabel(label, project));
  }

  // PCB boards (thin green boards visible in the 3D viewer).
  const pcbBoards = generateAllPcbBoards(project);

  // Internal layout: battery compartment, back features (belt clip + strap slots).
  if (project.internalLayout) {
    const batBrush = generateBatteryCompartmentBrush(project);
    if (batBrush) {
      try {
        mesh = subtract(mesh, batBrush);
        mesh.material = material;
      } catch (e) {
        console.warn('Battery compartment subtraction failed:', e);
      }
    }
    const backBrushes = generateBackFeaturesBrushes(project);
    for (const brush of backBrushes) {
      try {
        mesh = subtract(mesh, brush);
        mesh.material = material;
      } catch (e) {
        console.warn('Back feature subtraction failed:', e);
      }
    }
  }

  // Screw mounts (from internal layout) — separate closed-solid meshes.
  const screwMounts: THREE.Mesh[] = [];
  if (project.internalLayout) {
    screwMounts.push(...generateScrewMounts(project));
  }

  // Decorations (text / logo / shape) on any face.
  // All decorations are kept as separate closed-solid meshes. The bottom
  // enclosure is a closed solid, and each decoration (text plate = closed
  // Box, logo plate = closed Box, shape = closed ExtrudeGeometry) is also a
  // closed solid. The slicer treats them as separate shells, which is the
  // standard way multi-part models are exported. Slicers handle multi-shell
  // meshes well — what they DON'T handle is open edges, which we avoid by
  // keeping each shell closed.
  const decorations: THREE.Mesh[] = [];
  for (const dec of project.decorations || []) {
    if (!dec.visible) continue;
    try {
      const decMesh = generateDecoration(dec, project);
      // Skip empty meshes (e.g., text with no content).
      const posAttr = decMesh.geometry.getAttribute('position');
      if (!posAttr || posAttr.count === 0) continue;
      decorations.push(decMesh);
    } catch (e) {
      console.warn('Decoration generation failed:', e);
    }
  }

  // Re-orient: rotate so Z is up (we built everything assuming Z is up).
  // Already Z-up. Update world matrix.
  mesh.updateMatrixWorld();
  return {
    id: 'bottom',
    name: 'Bottom Enclosure',
    meshes: [mesh, ...pcbBoards, ...labels, ...decorations, ...snapFitHooks, ...internalSupports, ...screwMounts],
  };
}

/**
 * Generate the lid mesh for the project. Lid shape varies by lid type.
 */
export function generateLid(project: EnclosureProject): GeneratedPart {
  const material = defaultMaterial();
  const lid = project.lid;
  const { width, depth, height, wallThickness, cornerRadius } = project.dimensions;
  const lidThickness = lid.thickness;

  switch (lid.type) {
    case 'none': {
      return { id: 'lid', name: 'Lid', meshes: [] };
    }
    case 'flat-removable':
    case 'screw':
    case 'captive-screw':
    case 'sliding':
    case 'snap-fit':
    case 'hinged': {
      // All flat-style lids share the same shape: a thin plate covering the
      // top. For screw lids, drill countersink/countersink holes at the screw
      // boss positions. For snap-fit, the hooks are on the bottom (we
      // approximate with cylindrical bumps on the underside).
      const lidW = width - 2 * lid.clearance;
      const lidD = depth - 2 * lid.clearance;
      const geom =
        cornerRadius > 0.01
          ? roundedBoxGeometry(lidW, lidD, lidThickness, Math.max(0, cornerRadius - lid.clearance), 6)
          : boxGeometry(lidW, lidD, lidThickness);
      // Translate so the lid sits on top of the enclosure.
      geom.translate(0, 0, height + lidThickness / 2);
      let mesh: AnyMesh = new THREE.Mesh(geom, material);
      mesh.updateMatrixWorld();

      // Apply top-face cutouts.
      for (const cutout of project.cutouts) {
        if (!cutout.visible) continue;
        if (cutout.face !== 'top') continue;
        const brush = buildCutoutBrush(cutout, project);
        mesh = subtract(mesh, brush);
        mesh.material = material;
      }

      // Apply top-face ventilation.
      mesh = applyVentilationTo(mesh, project);
      mesh.material = material;

      // Screw holes — drill through the lid at the screw boss positions.
      if (lid.type === 'screw' || lid.type === 'captive-screw') {
        const inset = Math.max(wallThickness + 3, project.screw.headDiameter + 1);
        const corners: [number, number][] = [
          [width / 2 - inset, depth / 2 - inset],
          [-width / 2 + inset, depth / 2 - inset],
          [width / 2 - inset, -depth / 2 + inset],
          [-width / 2 + inset, -depth / 2 + inset],
        ];
        for (const [x, y] of corners) {
          // Position is at the top of the lid (z = height + lidThickness).
          const pos = new THREE.Vector3(x, y, height + lidThickness / 2);
          let brush: THREE.Mesh;
          if (lid.type === 'captive-screw') {
            // Countersink — a cone.
            const halfAngle = ((project.screw.countersinkAngle * Math.PI) / 180 / 2);
            const headR = project.screw.headDiameter / 2;
            const coneH = headR / Math.tan(halfAngle);
            const cone = new THREE.ConeGeometry(headR * 1.05, coneH + 0.5, 32, 1, false);
            cone.rotateX(Math.PI);
            const coneMesh = new THREE.Mesh(cone, material);
            coneMesh.position.set(x, y, height + lidThickness);
            coneMesh.updateMatrixWorld();
            const throughHole = generateThroughHole(project.screw, pos, lidThickness);
            brush = union(throughHole, coneMesh);
          } else {
            // Counterbore.
            brush = generateCounterbore(project.screw, pos, lidThickness);
          }
          mesh = subtract(mesh, brush);
          mesh.material = material;
        }
      }

      // Snap-fit hooks: keep as SEPARATE closed meshes (no CSG union).
      // Same approach as the bottom's snap-fit hooks — avoids ~770 open edges
      // from CSG union. The hooks are returned as separate meshes in the lid
      // part. Slicers merge overlapping geometry during slicing.
      const lidHooks: THREE.Mesh[] = [];
      if (lid.type === 'snap-fit' && project.snapFit.enabled) {
        const hookH = project.snapFit.hookHeight;
        const hookR = 1.5;
        const positions = snapFitPositions(project);
        for (const [x, y] of positions) {
          const hookGeom = cylinderGeometry(hookR, hookH, 16, false, 'z');
          const hook = new THREE.Mesh(hookGeom, material);
          hook.position.set(x, y, height - hookH / 2);
          hook.updateMatrixWorld();
          lidHooks.push(hook);
        }
      }

      mesh.updateMatrixWorld();
      return { id: 'lid', name: 'Lid', meshes: [mesh, ...lidHooks] };
    }
    default: {
      return { id: 'lid', name: 'Lid', meshes: [] };
    }
  }
}

/**
 * Compute the snap-fit hook positions on the inside of the enclosure rim.
 */
function snapFitPositions(project: EnclosureProject): [number, number][] {
  const { width, depth, wallThickness } = project.dimensions;
  const inset = wallThickness + 1;
  const positions: [number, number][] = [];
  if (project.snapFit.flexDirection === 'x') {
    // Hooks on the long (X-axis) walls.
    const count = Math.max(2, project.snapFit.count);
    for (let i = 0; i < count; i++) {
      const x = (count === 1 ? 0 : (i / (count - 1) - 0.5) * (width - 2 * inset));
      positions.push([x, depth / 2 - inset]);
      positions.push([x, -depth / 2 + inset]);
    }
  } else {
    const count = Math.max(2, project.snapFit.count);
    for (let i = 0; i < count; i++) {
      const y = (count === 1 ? 0 : (i / (count - 1) - 0.5) * (depth - 2 * inset));
      positions.push([width / 2 - inset, y]);
      positions.push([-width / 2 + inset, y]);
    }
  }
  return positions;
}

/**
 * Create snap-fit hooks as SEPARATE closed-solid meshes (no CSG union).
 *
 * OLD code used CSG union to merge hooks with the wall, producing ~770 open
 * edges per enclosure due to three-bvh-csg numerical issues along the
 * intersection curve. Keeping hooks as separate closed cylinders eliminates
 * those open edges. Slicers handle overlapping shells correctly — they merge
 * coincident geometry during slicing, so the hook + wall print as one solid.
 *
 * Each hook is a small cylinder (radius 1.5mm, height = hookHeight) positioned
 * on the inside of the wall, near the top rim. They overlap the wall by ~50%
 * to ensure they're physically attached when printed.
 */
function createSnapFitHooks(project: EnclosureProject, material: THREE.Material): THREE.Mesh[] {
  const { height, wallThickness } = project.dimensions;
  const hookH = Math.max(1, project.snapFit.hookHeight);
  const hookR = 1.5;
  const positions = snapFitPositions(project);
  const hooks: THREE.Mesh[] = [];
  for (const [x, y] of positions) {
    const hookGeom = cylinderGeometry(hookR, hookH, 16, false, 'z');
    const hook = new THREE.Mesh(hookGeom, material);
    // Position the hook so it overlaps the wall (extends into the interior
    // and into the wall). The hook's center is at the wall's inner surface.
    hook.position.set(x, y, height - hookH / 2);
    hook.updateMatrixWorld();
    hooks.push(hook);
  }
  return hooks;
}

/**
 * Create internal support posts as SEPARATE closed-solid meshes (no CSG union).
 * Same approach as snap-fit hooks — avoids CSG open-edge issues.
 */
function createInternalSupports(project: EnclosureProject, material: THREE.Material): THREE.Mesh[] {
  const { width, depth, height, wallThickness, floorThickness } = project.dimensions;
  const innerW = Math.max(0.5, width - 2 * wallThickness);
  const innerD = Math.max(0.5, depth - 2 * wallThickness);
  const postH = Math.max(1, height - floorThickness - wallThickness);
  const spacing = Math.max(10, project.internalSupport.spacing);
  const cols = Math.max(1, Math.floor(innerW / spacing) - 1);
  const rows = Math.max(1, Math.floor(innerD / spacing) - 1);
  const startX = -((cols - 1) * spacing) / 2;
  const startY = -((rows - 1) * spacing) / 2;
  const posts: THREE.Mesh[] = [];
  for (let r = 0; r < rows; r++) {
    for (let c = 0; c < cols; c++) {
      const x = startX + c * spacing;
      const y = startY + r * spacing;
      const geom = cylinderGeometry(project.internalSupport.diameter / 2, postH, 16, false, 'z');
      const post = new THREE.Mesh(geom, material);
      post.position.set(x, y, floorThickness + postH / 2);
      post.updateMatrixWorld();
      posts.push(post);
    }
  }
  return posts;
}
