/**
 * Rubber feet generator. Produces `count` cylindrical feet positioned at the
 * bottom corners of the enclosure.
 */
import * as THREE from 'three';
import type { EnclosureProject, GeneratedPart } from '../types';
import { cylinderGeometry } from './primitives';

export function generateFeet(project: EnclosureProject): GeneratedPart {
  const meshes: THREE.Mesh[] = [];
  if (!project.feet.enabled) return { id: 'feet', name: 'Feet', meshes };
  const { width, depth } = project.dimensions;
  // Place feet at corners, inset by foot radius + 1mm.
  const inset = Math.min(width, depth) * 0.1 + 1;
  const positions: [number, number][] = [
    [width / 2 - inset, depth / 2 - inset],
    [-width / 2 + inset, depth / 2 - inset],
    [width / 2 - inset, -depth / 2 + inset],
    [-width / 2 + inset, -depth / 2 + inset],
  ];
  const count = Math.max(0, Math.min(project.feet.count, positions.length));
  for (let i = 0; i < count; i++) {
    const [x, y] = positions[i];
    const r = project.feet.diameter / 2;
    const h = project.feet.height;
    const geom = cylinderGeometry(r, h, 24, false, 'z');
    const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial({ color: 0x224422 }));
    mesh.position.set(x, y, -h / 2 - 0.001);
    mesh.updateMatrixWorld();
    meshes.push(mesh);
  }
  return { id: 'feet', name: 'Feet', meshes };
}
