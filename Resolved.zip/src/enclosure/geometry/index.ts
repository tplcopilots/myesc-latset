/**
 * Geometry Engine — orchestrator.
 *
 * Calls all part-generators and aggregates the result. Also computes global
 * stats: bounding box, triangle count, material volume, bbox volume.
 */
import * as THREE from 'three';
import type { EnclosureProject, GeneratedPart, PartId } from '../types';
import { generateBottom, generateLid } from './enclosureGeometry';
import { generateStandoffs } from './standoffs';
import { generateFeet } from './feet';

export interface GeometryResult {
  parts: GeneratedPart[];
  /** Combined bounding box of all parts (mm). */
  boundingBox: { min: THREE.Vector3; max: THREE.Vector3 };
  /** Total triangle count across all parts. */
  triangleCount: number;
  /** Total material volume in mm³. */
  materialVolume: number;
  /** Bounding-box volume in mm³. */
  boundingBoxVolume: number;
}

export interface GeometryContext {
  project: EnclosureProject;
}

/**
 * Synchronously generate all parts of the enclosure. (three-bvh-csg is sync.)
 */
export function generateEnclosureGeometry(ctx: GeometryContext): GeometryResult {
  const parts: GeneratedPart[] = [];

  // Bottom (with cutouts, ventilation, screw bosses, snap-fit, supports,
  // labels).
  parts.push(generateBottom(ctx.project));

  // Lid (if visible and not 'none').
  if (ctx.project.lid.visible && ctx.project.lid.type !== 'none') {
    parts.push(generateLid(ctx.project));
  }

  // Standoffs.
  const standoffs = generateStandoffs(ctx.project);
  if (standoffs.meshes.length > 0) parts.push(standoffs);

  // Feet.
  const feet = generateFeet(ctx.project);
  if (feet.meshes.length > 0) parts.push(feet);

  // Vents placeholder part — always present so the object tree shows it.
  parts.push({ id: 'vents', name: 'Ventilation', meshes: [] });

  // Compute aggregate stats.
  const stats = computeStats(parts);
  return { parts, ...stats };
}

/**
 * Compute combined bounding box, triangle count, material volume.
 *
 * For the bounding box, we transform ALL 8 corners of each mesh's local
 * bbox by its world matrix and take the min/max. This correctly handles
 * rotated meshes (e.g., decorations on the front/left/right/back faces
 * whose geometry is rotated so its local Z aligns with the face normal).
 * Naively transforming only bbox.min and bbox.max separately gives the
 * wrong answer for any rotation that swaps axes.
 */
function computeStats(parts: GeneratedPart[]): Omit<GeometryResult, 'parts'> {
  const min = new THREE.Vector3(+Infinity, +Infinity, +Infinity);
  const max = new THREE.Vector3(-Infinity, -Infinity, -Infinity);
  let tri = 0;
  let vol = 0;
  const corner = new THREE.Vector3();
  for (const part of parts) {
    for (const mesh of part.meshes) {
      mesh.geometry.computeBoundingBox();
      const bb = mesh.geometry.boundingBox;
      if (bb) {
        // Transform all 8 corners and take min/max.
        const corners = [
          [bb.min.x, bb.min.y, bb.min.z],
          [bb.max.x, bb.min.y, bb.min.z],
          [bb.min.x, bb.max.y, bb.min.z],
          [bb.max.x, bb.max.y, bb.min.z],
          [bb.min.x, bb.min.y, bb.max.z],
          [bb.max.x, bb.min.y, bb.max.z],
          [bb.min.x, bb.max.y, bb.max.z],
          [bb.max.x, bb.max.y, bb.max.z],
        ];
        for (const [x, y, z] of corners) {
          corner.set(x, y, z).applyMatrix4(mesh.matrixWorld);
          min.min(corner);
          max.max(corner);
        }
      }
      const pos = mesh.geometry.getAttribute('position');
      if (pos) {
        const index = mesh.geometry.getIndex();
        const triCount = index ? index.count / 3 : pos.count / 3;
        tri += Math.floor(triCount);
      }
      vol += meshVolume(mesh);
    }
  }
  if (!isFinite(min.x)) {
    min.set(0, 0, 0);
    max.set(0, 0, 0);
  }
  const bboxVolume =
    Math.max(0, max.x - min.x) *
    Math.max(0, max.y - min.y) *
    Math.max(0, max.z - min.z);
  return {
    boundingBox: { min, max },
    triangleCount: tri,
    materialVolume: vol,
    boundingBoxVolume: bboxVolume,
  };
}

/**
 * Compute the signed volume of a mesh using the divergence theorem.
 *
 * For each triangle with vertices v0, v1, v2 (CCW from outside), the signed
 * volume of the tetrahedron (origin, v0, v1, v2) is (v0 · (v1 × v2)) / 6.
 * Summing all such tetrahedra gives the enclosed (signed) volume. Taking the
 * absolute value gives the geometric volume.
 *
 * NOTE: this assumes the mesh is manifold, watertight, and consistently
 * wound. Non-manifold CSG output may produce inaccurate volumes. We label
 * these as ESTIMATES in the UI per the spec.
 */
export function meshVolume(mesh: THREE.Mesh): number {
  const g = mesh.geometry as THREE.BufferGeometry;
  const pos = g.getAttribute('position');
  if (!pos) return 0;
  const index = g.getIndex();
  const v0 = new THREE.Vector3();
  const v1 = new THREE.Vector3();
  const v2 = new THREE.Vector3();
  const cross = new THREE.Vector3();
  const matrix = mesh.matrixWorld;
  let vol = 0;
  const triCount = index ? index.count / 3 : pos.count / 3;
  for (let i = 0; i < triCount; i++) {
    const a = index ? index.getX(i * 3) : i * 3;
    const b = index ? index.getX(i * 3 + 1) : i * 3 + 1;
    const c = index ? index.getX(i * 3 + 2) : i * 3 + 2;
    v0.fromBufferAttribute(pos, a).applyMatrix4(matrix);
    v1.fromBufferAttribute(pos, b).applyMatrix4(matrix);
    v2.fromBufferAttribute(pos, c).applyMatrix4(matrix);
    cross.crossVectors(v1, v2);
    vol += v0.dot(cross) / 6;
  }
  return Math.abs(vol);
}

/**
 * Helper: convert a PartId to a human-readable name.
 */
export function partName(id: PartId): string {
  switch (id) {
    case 'bottom':
      return 'Bottom Enclosure';
    case 'lid':
      return 'Lid';
    case 'standoffs':
      return 'PCB Standoffs';
    case 'mounts':
      return 'Mounting Bosses';
    case 'feet':
      return 'Feet';
    case 'vents':
      return 'Ventilation';
  }
}

