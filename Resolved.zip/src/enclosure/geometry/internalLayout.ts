/**
 * Internal layout geometry — battery compartment, screw mounts, belt clip, strap slots.
 */
import * as THREE from 'three';
import type { EnclosureProject, InternalLayout } from '../types';
import { boxGeometry, cylinderGeometry } from './primitives';

export function generateScrewMounts(project: EnclosureProject): THREE.Mesh[] {
  const layout = project.internalLayout;
  if (!layout) return [];
  const sm = layout.screwMount;
  const { width, depth, height, floorThickness, wallThickness } = project.dimensions;
  const inset = sm.inset + wallThickness;
  const x = width / 2 - inset;
  const y = depth / 2 - inset;
  const bossH = Math.max(1, sm.height);
  const bossZ = sm.startFrom === 'bottom' ? floorThickness + bossH / 2 : height - wallThickness - bossH / 2;
  const outerR = Math.max(1, sm.diameter / 2);
  const innerR = Math.min(outerR - 0.5, Math.max(0.5, sm.holeDiameter / 2));
  const positions: [number, number][] = [[x,y],[-x,y],[x,-y],[-x,-y]];
  const meshes: THREE.Mesh[] = [];
  for (const [px, py] of positions) {
    const interiorW = width - 2 * wallThickness;
    const interiorD = depth - 2 * wallThickness;
    if (Math.abs(px) > interiorW/2 - 2 || Math.abs(py) > interiorD/2 - 2) continue;
    const shape = new THREE.Shape();
    shape.absarc(0, 0, outerR, 0, Math.PI * 2, false);
    const hole = new THREE.Path();
    hole.absarc(0, 0, innerR, 0, Math.PI * 2, false);
    shape.holes.push(hole);
    const geom = new THREE.ExtrudeGeometry(shape, { depth: bossH, bevelEnabled: false, curveSegments: 24 });
    geom.translate(0, 0, -bossH / 2);
    geom.computeVertexNormals();
    const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial());
    mesh.position.set(px, py, bossZ);
    mesh.updateMatrixWorld();
    meshes.push(mesh);
  }
  return meshes;
}

export function generateBatteryCompartmentBrush(project: EnclosureProject): THREE.Mesh | null {
  const layout = project.internalLayout;
  if (!layout || !layout.battery || !layout.battery.enabled) return null;
  const bat = layout.battery;
  const { floorThickness } = project.dimensions;
  const clearance = 0.5;
  const compW = bat.width + clearance * 2;
  const compD = bat.depth + clearance * 2;
  const compH = bat.height + clearance * 2;
  const z = floorThickness + compH / 2;
  const geom = boxGeometry(compW, compD, compH);
  const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial());
  mesh.position.set(bat.positionX, bat.positionY, z);
  mesh.updateMatrixWorld();
  return mesh;
}

export function generateBackFeaturesBrushes(project: EnclosureProject): THREE.Mesh[] {
  const layout = project.internalLayout;
  if (!layout) return [];
  const { width, depth, height, wallThickness } = project.dimensions;
  const brushes: THREE.Mesh[] = [];
  if (layout.beltClipWidth > 0) {
    const geom = boxGeometry(layout.beltClipWidth, Math.max(2, wallThickness * 2 + 1), 6);
    const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial());
    mesh.position.set(0, depth / 2, height / 2);
    mesh.updateMatrixWorld();
    brushes.push(mesh);
  }
  if (layout.strapSlotWidth > 0) {
    const slotH = Math.max(2, wallThickness * 2 + 1);
    const topGeom = boxGeometry(layout.strapSlotWidth, slotH, layout.strapSlotHeight);
    const topMesh = new THREE.Mesh(topGeom, new THREE.MeshStandardMaterial());
    topMesh.position.set(0, depth / 2, height - wallThickness - layout.strapSlotHeight / 2);
    topMesh.updateMatrixWorld();
    brushes.push(topMesh);
    const botGeom = boxGeometry(layout.strapSlotWidth, slotH, layout.strapSlotHeight);
    const botMesh = new THREE.Mesh(botGeom, new THREE.MeshStandardMaterial());
    botMesh.position.set(0, depth / 2, wallThickness + layout.strapSlotHeight / 2);
    botMesh.updateMatrixWorld();
    brushes.push(botMesh);
  }
  return brushes;
}
