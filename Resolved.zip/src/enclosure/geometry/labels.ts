/**
 * Label / text geometry.
 *
 * Approach: We use a CanvasTexture-based flat plane with text rendered onto a
 * canvas. This avoids loading external fonts (helvetiker_regular.typeface.json
 * from three/examples) which would require fetching from a CDN. The plane is
 * a thin extruded box with the text texture on its front face.
 *
 * Trade-off: the text is a texture, not real geometry, so it is visible but
 * not embossed. The user can still see and position labels; this is acceptable
 * for a parametric preview tool. The exported STL will contain a flat plate
 * where the label sits.
 */
import * as THREE from 'three';
import type { LabelParameters, EnclosureProject } from '../types';
import { faceBasis } from './cutouts';

/**
 * Create a canvas texture with the given text. Returns a Texture plus the
 * canvas dimensions in mm-equivalent units.
 */
function createTextTexture(text: string, size: number): {
  texture: THREE.Texture;
  width: number;
  height: number;
} {
  // Use a canvas with a generous pixel size for crispness.
  const pxPerMm = 8;
  // Estimate text width: 0.6 * size per character.
  const textWidthMm = Math.max(size * 2, text.length * size * 0.6);
  const textHeightMm = size * 1.4;
  const canvas = document.createElement('canvas');
  canvas.width = Math.ceil(textWidthMm * pxPerMm);
  canvas.height = Math.ceil(textHeightMm * pxPerMm);
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.fillStyle = '#000000';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = '#f5f5f5';
    ctx.font = `${Math.floor(size * pxPerMm)}px sans-serif`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(text, canvas.width / 2, canvas.height / 2);
  }
  const texture = new THREE.CanvasTexture(canvas);
  texture.colorSpace = THREE.SRGBColorSpace;
  return { texture, width: textWidthMm, height: textHeightMm };
}

/**
 * Build a label mesh for the given label parameters. The label sits on the
 * chosen face with the text texture facing outward.
 */
export function generateLabel(label: LabelParameters, project: EnclosureProject): THREE.Mesh {
  if (!label.enabled || !label.text) {
    return new THREE.Mesh(new THREE.BufferGeometry(), new THREE.MeshStandardMaterial());
  }
  const { center, u, v, n } = faceBasis(label.face, project.dimensions);
  const { texture, width, height } = createTextTexture(label.text, label.size);

  // The label is a thin plate positioned flush with the face surface.
  const depth = Math.max(0.5, label.depth);
  const geom = new THREE.BoxGeometry(width, height, depth);
  const material = new THREE.MeshStandardMaterial({
    map: texture,
    roughness: 0.7,
  });
  const mesh = new THREE.Mesh(geom, material);
  // Orient plate so its +Z aligns with the face normal.
  mesh.quaternion.setFromUnitVectors(
    new THREE.Vector3(0, 0, 1),
    n.clone().normalize()
  );
  const pos = center
    .clone()
    .addScaledVector(u, label.positionX)
    .addScaledVector(v, label.positionY)
    .addScaledVector(n, depth / 2 + 0.05);
  mesh.position.copy(pos);
  if (label.rotation) {
    const r = (label.rotation * Math.PI) / 180;
    const q = new THREE.Quaternion().setFromAxisAngle(n.clone().normalize(), r);
    mesh.quaternion.premultiply(q);
  }
  mesh.updateMatrixWorld();
  return mesh;
}
