/**
 * PCB board + individual screws + internal compartments geometry.
 */
import * as THREE from 'three';
import type { EnclosureProject, PCB } from '../types';
import { boxGeometry, cylinderGeometry } from './primitives';
import { generateScrewBoss } from './screws';

/**
 * Generate a PCB board mesh (thin green board at the standoff height).
 */
export function generatePcbBoard(pcb: PCB, floorThickness: number): THREE.Mesh {
  const w = Math.max(1, pcb.width);
  const h = Math.max(1, pcb.height);
  const t = Math.max(0.4, pcb.thickness);
  const z = floorThickness + pcb.standoffHeight + t / 2;
  const geom = boxGeometry(w, h, t);
  const mat = new THREE.MeshStandardMaterial({
    color: 0x0f5132,  // PCB green
    roughness: 0.6,
    metalness: 0.1,
  });
  const mesh = new THREE.Mesh(geom, mat);
  mesh.position.set(0, 0, z);
  mesh.updateMatrixWorld();
  mesh.userData = { partType: 'bottom' };
  return mesh;
}

/**
 * Generate all PCB boards for the project.
 */
export function generateAllPcbBoards(project: EnclosureProject): THREE.Mesh[] {
  const { floorThickness } = project.dimensions;
  const meshes: THREE.Mesh[] = [];
  for (const pcb of project.pcbs) {
    if (!pcb.visible) continue;
    meshes.push(generatePcbBoard(pcb, floorThickness));
  }
  return meshes;
}
