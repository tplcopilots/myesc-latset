/**
 * Primitive geometry helpers for the enclosure designer.
 *
 * All helpers return THREE.BufferGeometry centered at the origin (translation
 * is left to the caller). Geometry returned is non-indexed where possible to
 * simplify CSG (three-bvh-csg requires manifold, well-formed geometry — using
 * BoxGeometry / CylinderGeometry / ExtrudeGeometry gives us manifold output).
 */
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three-stdlib';

/**
 * Standard centered box geometry. THREE.BoxGeometry is already centered at
 * origin when width/height/depth are positive.
 */
export function boxGeometry(w: number, h: number, d: number): THREE.BufferGeometry {
  return new THREE.BoxGeometry(Math.max(0.001, w), Math.max(0.001, h), Math.max(0.001, d));
}

/**
 * Rounded-corner box. Uses three-stdlib's RoundedBoxGeometry which produces
 * a manifold mesh with rounded edges and corners.
 *
 * @param w          Width  (X)
 * @param h          Height (Z) — three-stdlib uses "height" along Y, we re-orient
 * @param d          Depth  (Y)
 * @param r          Corner radius in mm
 * @param segments   Smoothness of corners (higher = rounder)
 */
export function roundedBoxGeometry(
  w: number,
  h: number,
  d: number,
  r = 2,
  segments = 6
): THREE.BufferGeometry {
  const minDim = Math.min(w, h, d);
  const radius = Math.max(0, Math.min(r, minDim / 2 - 0.01));
  // three-stdlib's RoundedBoxGeometry(width, height, depth, segments, radius)
  const geom = new RoundedBoxGeometry(
    Math.max(0.001, w),
    Math.max(0.001, h),
    Math.max(0.001, d),
    segments,
    radius
  );
  return geom;
}

/**
 * Cylinder with axis along Y. Three's CylinderGeometry is centered at origin
 * with the axis along Y by default. We rotate to align with Z (so that
 * "height" means Z-axis height) — this matches our convention of "height"
 * meaning the vertical (Z) axis for the enclosure.
 *
 * Use `axis: 'x' | 'y' | 'z'` to control orientation.
 */
export function cylinderGeometry(
  radius: number,
  height: number,
  segments = 24,
  openEnded = false,
  axis: 'x' | 'y' | 'z' = 'z'
): THREE.BufferGeometry {
  const r = Math.max(0.001, radius);
  const hgt = Math.max(0.001, height);
  const geom = new THREE.CylinderGeometry(r, r, hgt, segments, 1, openEnded);
  // Cylinder is along Y by default. Rotate to the desired axis.
  if (axis === 'x') {
    geom.rotateZ(Math.PI / 2);
  } else if (axis === 'z') {
    geom.rotateX(Math.PI / 2);
  }
  return geom;
}

/**
 * Rounded slot (rounded rectangle) extruded along Z.
 *
 * @param width          X size
 * @param height         Y size
 * @param depth          Z extrude depth
 * @param cornerRadius   Corner radius in mm (clamped to half of min(w,h))
 */
export function slotGeometry(
  width: number,
  height: number,
  depth: number,
  cornerRadius = 0
): THREE.BufferGeometry {
  const w = Math.max(0.001, width);
  const h = Math.max(0.001, height);
  const d = Math.max(0.001, depth);
  const r = Math.max(0, Math.min(cornerRadius, Math.min(w, h) / 2 - 0.001));
  const shape = new THREE.Shape();
  const x = -w / 2;
  const y = -h / 2;
  if (r > 0.001) {
    shape.moveTo(x + r, y);
    shape.lineTo(x + w - r, y);
    shape.quadraticCurveTo(x + w, y, x + w, y + r);
    shape.lineTo(x + w, y + h - r);
    shape.quadraticCurveTo(x + w, y + h, x + w - r, y + h);
    shape.lineTo(x + r, y + h);
    shape.quadraticCurveTo(x, y + h, x, y + h - r);
    shape.lineTo(x, y + r);
    shape.quadraticCurveTo(x, y, x + r, y);
  } else {
    shape.moveTo(x, y);
    shape.lineTo(x + w, y);
    shape.lineTo(x + w, y + h);
    shape.lineTo(x, y + h);
    shape.lineTo(x, y);
  }
  const geom = new THREE.ExtrudeGeometry(shape, {
    depth: d,
    bevelEnabled: false,
  });
  // ExtrudeGeometry extrudes along +Z, centered around z=0..d. Move to center
  // around z=0.
  geom.translate(0, 0, -d / 2);
  return geom;
}

/**
 * Extruded polygon (custom cutout shape). Points are in XY plane (Z=0), extruded
 * along Z by `depth`. The polygon is assumed closed (we close it if not).
 *
 * @param points  Array of {x, y} points in mm
 * @param depth   Extrude depth in mm
 */
export function polygonGeometry(
  points: { x: number; y: number }[],
  depth: number
): THREE.BufferGeometry {
  if (points.length < 3) {
    return new THREE.BoxGeometry(0.001, 0.001, Math.max(0.001, depth));
  }
  const shape = new THREE.Shape();
  shape.moveTo(points[0].x, points[0].y);
  for (let i = 1; i < points.length; i++) {
    shape.lineTo(points[i].x, points[i].y);
  }
  shape.lineTo(points[0].x, points[0].y);
  const d = Math.max(0.001, depth);
  const geom = new THREE.ExtrudeGeometry(shape, { depth: d, bevelEnabled: false });
  geom.translate(0, 0, -d / 2);
  return geom;
}

/**
 * Disk (filled circle) — used for labels and flat features.
 * Returns a circle in the XY plane with thickness `depth` along Z.
 */
export function diskGeometry(radius: number, depth: number, segments = 32): THREE.BufferGeometry {
  const r = Math.max(0.001, radius);
  const d = Math.max(0.001, depth);
  const shape = new THREE.Shape();
  shape.absarc(0, 0, r, 0, Math.PI * 2, false);
  const geom = new THREE.ExtrudeGeometry(shape, { depth: d, bevelEnabled: false });
  geom.translate(0, 0, -d / 2);
  return geom;
}
