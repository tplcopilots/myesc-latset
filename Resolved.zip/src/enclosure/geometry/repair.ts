/**
 * Mesh repair utilities.
 *
 * CSG operations (three-bvh-csg) and Three.js's per-face vertex duplication
 * (BoxGeometry has 24 vertices for 6 faces × 4 each) produce meshes with
 * many "duplicate" vertices — vertices occupying the same physical
 * position but with different indices. This causes:
 *
 *   - Slicers report many "boundary edges" because each face's vertex
 *     is a separate vertex (no edges are shared between faces).
 *   - Open-edge warnings in PrusaSlicer / Bambu Studio / Cura.
 *   - Inability to compute volume (divergence theorem requires shared
 *     vertices to know which triangles share an edge).
 *
 * The repair pipeline:
 *   1. Weld vertices: mergeVertices(geom, tolerance) — merges vertices
 *      within `tolerance` mm. Default 0.01mm (10µm, well below typical
 *      3D-printer resolution of 200µm layer height).
 *   2. Remove degenerate triangles (zero area).
 *   3. Recompute vertex normals so shading is consistent.
 *
 * This produces a mesh where edges are properly shared between triangles,
 * dramatically reducing boundary-edge counts in slicer diagnostics.
 *
 * Note: This does NOT fix non-manifold geometry (edges shared by 3+
 * triangles) or fill holes. For those, use the slicer's mesh-repair tool.
 */
import * as THREE from 'three';
import { mergeVertices } from 'three-stdlib';

const { BufferAttribute, BufferGeometry } = THREE;

/**
 * Repair a single BufferGeometry: weld vertices, remove degenerate tris.
 * Returns a new geometry (does not modify the input).
 *
 * CRITICAL: We delete the normal and uv attributes BEFORE calling
 * mergeVertices. three-stdlib's mergeVertices hashes vertices by position
 * AND normal AND uv — so vertices at the SAME position but with DIFFERENT
 * normals (e.g., on sharp edges like the corner of a box) are NOT merged.
 * This leaves duplicate vertices in the geometry, which creates "open edges"
 * in 3MF exports (since two triangles sharing an edge use different vertex
 * indices even though they're at the same position).
 *
 * By deleting normals/uvs first, we force mergeVertices to merge by position
 * only. Then we recompute normals afterward for consistent shading.
 */
export function repairGeometry(
  geom: THREE.BufferGeometry,
  tolerance = 0.01,
): THREE.BufferGeometry {
  // 0. Clone the geometry and strip normal/uv attributes so mergeVertices
  //    merges by position only (not by position+normal+uv).
  const geomCopy = geom.clone();
  geomCopy.deleteAttribute('normal');
  geomCopy.deleteAttribute('uv');
  geomCopy.deleteAttribute('color');

  // 1. Weld vertices within `tolerance` mm — by position only.
  let repaired: THREE.BufferGeometry;
  try {
    repaired = mergeVertices(geomCopy, tolerance);
  } catch (e) {
    console.warn('mergeVertices failed, returning original geometry:', e);
    // Fall back to the original geometry (with normals stripped).
    return geomCopy;
  }

  // 2. Remove degenerate triangles (zero area). These produce NaN normals
  //    in the STL/3MF/OBJ/PLY exporters.
  repaired = removeDegenerateTriangles(repaired);

  // 3. Recompute normals consistently (all outward-facing).
  repaired.computeVertexNormals();
  repaired.computeBoundingBox();
  repaired.computeBoundingSphere();

  return repaired;
}

/**
 * Remove degenerate (zero-area) triangles from a geometry.
 *
 * A triangle is degenerate if its three vertices are colinear or if two
 * vertices coincide. Such triangles have zero area and produce NaN normals
 * when normalized (cross product is zero, normalize divides by zero).
 *
 * The removal preserves the rest of the geometry; only the bad triangles
 * are dropped from the index.
 */
function removeDegenerateTriangles(geom: THREE.BufferGeometry): THREE.BufferGeometry {
  const pos = geom.getAttribute('position');
  if (!pos) return geom;

  const index = geom.getIndex();
  if (!index) {
    // Non-indexed geometry — convert to indexed first for efficient removal.
    // (mergeVertices should have produced an indexed geometry.)
    return geom;
  }

  const v0 = new THREE.Vector3();
  const v1 = new THREE.Vector3();
  const v2 = new THREE.Vector3();
  const e1 = new THREE.Vector3();
  const e2 = new THREE.Vector3();
  const cross = new THREE.Vector3();

  const newIndices: number[] = [];
  const triCount = Math.floor(index.count / 3);
  let removed = 0;
  for (let i = 0; i < triCount; i++) {
    const a = index.getX(i * 3);
    const b = index.getX(i * 3 + 1);
    const c = index.getX(i * 3 + 2);
    v0.fromBufferAttribute(pos, a);
    v1.fromBufferAttribute(pos, b);
    v2.fromBufferAttribute(pos, c);
    e1.subVectors(v1, v0);
    e2.subVectors(v2, v0);
    cross.crossVectors(e1, e2);
    // Skip if cross product is too small (degenerate triangle).
    if (cross.lengthSq() < 1e-12) {
      removed++;
      continue;
    }
    newIndices.push(a, b, c);
  }

  if (removed === 0) return geom;

  const newGeom = new BufferGeometry();
  newGeom.setAttribute('position', pos.clone());
  if (geom.getAttribute('normal')) {
    newGeom.setAttribute('normal', geom.getAttribute('normal').clone());
  }
  if (geom.getAttribute('uv')) {
    newGeom.setAttribute('uv', geom.getAttribute('uv').clone());
  }
  newGeom.setIndex(new BufferAttribute(new Uint32Array(newIndices), 1));
  return newGeom;
}

/**
 * Repair all meshes in a list. Returns new meshes with repaired geometry.
 * Preserves each mesh's world matrix and material.
 */
export function repairMeshes(
  meshes: THREE.Mesh[],
  tolerance = 0.01,
): THREE.Mesh[] {
  return meshes.map(mesh => {
    const repaired = repairGeometry(mesh.geometry as THREE.BufferGeometry, tolerance);
    const newMesh = new THREE.Mesh(repaired, mesh.material);
    newMesh.matrix.copy(mesh.matrix);
    newMesh.matrixWorld.copy(mesh.matrixWorld);
    newMesh.matrixAutoUpdate = false;
    newMesh.updateMatrixWorld(true);
    return newMesh;
  });
}
