/**
 * Screw boss and through-hole generators.
 *
 * Note: We DO NOT generate real threads. The boss has a clearance hole for a
 * self-tapping screw; the user must tap the plastic or use thread-forming
 * screws. We expose parameters for countersinks and counterbores so the user
 * can also use machine screws with nuts.
 *
 * Implementation note: We use ExtrudeGeometry with a hole (annulus shape)
 * instead of CSG subtraction for the boss. CSG subtraction of two cylinders
 * (outer - inner) produces meshes with many open edges (~290 per boss)
 * because three-bvh-csg has numerical issues along the intersection curve.
 * ExtrudeGeometry with a hole produces a clean, closed, manifold tube
 * with 0 open edges.
 */
import * as THREE from 'three';
import type { ScrewSpec } from '../types';
import { cylinderGeometry } from './primitives';
import { subtract, union } from './csg';

/**
 * Generate a screw boss: a cylinder with a hole drilled down its center.
 *
 * Uses ExtrudeGeometry with an annulus (outer circle with inner hole) — this
 * produces a closed tube without CSG. Avoids the open-edge issues that
 * CSG subtraction of two cylinders produces.
 *
 * @returns a Mesh positioned at `position` with base at z=position.z and apex
 *          upward.
 */
export function generateScrewBoss(
  screw: ScrewSpec,
  position: THREE.Vector3,
  height: number,
  bossDiameter: number
): THREE.Mesh {
  const h = Math.max(1, height);
  const outerR = Math.max(0.5, bossDiameter / 2);
  // Inner radius — ensure it's smaller than outer (so we have a tube wall).
  const innerR = Math.min(outerR - 0.4, Math.max(0.3, screw.clearanceHole / 2));

  // Build an annulus shape: outer circle with inner hole.
  const shape = new THREE.Shape();
  shape.absarc(0, 0, outerR, 0, Math.PI * 2, false);
  const hole = new THREE.Path();
  hole.absarc(0, 0, innerR, 0, Math.PI * 2, false);
  shape.holes.push(hole);

  // Extrude along +Z by `h`. Result is from z=0 to z=h in local coords.
  const geom = new THREE.ExtrudeGeometry(shape, {
    depth: h,
    bevelEnabled: false,
    curveSegments: 24,
  });
  // Center the geometry around Z=0 in local coords. The mesh's position
  // will be `position + (0, 0, h/2)` so the BOSS BASE sits at position.z
  // (matches the original CSG-based behavior where position.z was the base).
  geom.translate(0, 0, -h / 2);
  geom.computeVertexNormals();

  const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial());
  mesh.position.copy(position);
  mesh.position.z += h / 2; // base at position.z, top at position.z + h
  mesh.updateMatrixWorld();
  return mesh;
}

/**
 * Generate a countersink version of a screw boss: boss with a countersink
 * (cone) drilled into the top.
 */
export function generateCountersinkBoss(
  screw: ScrewSpec,
  position: THREE.Vector3,
  height: number,
  bossDiameter: number
): THREE.Mesh {
  const baseBoss = generateScrewBoss(screw, position, height, bossDiameter);
  // Countersink cone: at the top of the boss. The cone half-angle is half of
  // `countersinkAngle` (typically 90° means a 45° half-angle from the axis).
  const halfAngle = ((screw.countersinkAngle || 90) * Math.PI) / 180 / 2;
  const headR = screw.headDiameter / 2;
  // Cone height such that the head fits flush with the boss top.
  const coneH = headR / Math.tan(halfAngle);
  // ConeGeometry(radius, height, radialSegments, heightSegments, openEnded)
  const cone = new THREE.ConeGeometry(headR * 1.05, coneH, 32, 1, false);
  // ConeGeometry's apex is at +Y by default; we rotate so its axis is along Z
  // (apex pointing down into the boss top).
  cone.rotateX(Math.PI);
  const coneMesh = new THREE.Mesh(cone, new THREE.MeshStandardMaterial());
  coneMesh.position.copy(position);
  coneMesh.position.z += height; // top of boss
  coneMesh.updateMatrixWorld();
  return subtract(baseBoss, coneMesh);
}

/**
 * Generate a through-hole brush — a cylinder to subtract from a target mesh.
 * Used to drill a clearance hole through a wall.
 *
 * @returns a Mesh positioned with its axis along Z, centered at `position`.
 */
export function generateThroughHole(
  screw: ScrewSpec,
  position: THREE.Vector3,
  depth: number
): THREE.Mesh {
  const holeR = screw.clearanceHole / 2;
  const d = depth + 2;
  const geom = cylinderGeometry(holeR, d, 24, false, 'z');
  const mesh = new THREE.Mesh(geom, new THREE.MeshStandardMaterial());
  mesh.position.copy(position);
  mesh.updateMatrixWorld();
  return mesh;
}

/**
 * Generate a counterbore brush — a cylinder + a smaller cylinder (for the
 * screw head clearance). Used to subtract a stepped hole from a wall.
 */
export function generateCounterbore(
  screw: ScrewSpec,
  position: THREE.Vector3,
  wallThickness: number
): THREE.Mesh {
  const holeR = screw.clearanceHole / 2;
  const headR = screw.headDiameter / 2;
  const headH = screw.headHeight;
  // Through hole.
  const throughH = wallThickness + 2;
  const throughGeom = cylinderGeometry(holeR, throughH, 24, false, 'z');
  const through = new THREE.Mesh(throughGeom, new THREE.MeshStandardMaterial());
  through.position.copy(position);
  through.updateMatrixWorld();

  // Head pocket (counterbore).
  const headGeom = cylinderGeometry(headR, headH + 0.5, 24, false, 'z');
  const head = new THREE.Mesh(headGeom, new THREE.MeshStandardMaterial());
  // Place head pocket at the top of the wall (assuming wall is centered at
  // position.z).
  head.position.copy(position);
  head.position.z += wallThickness / 2 - headH / 2 + 0.25;
  head.updateMatrixWorld();

  return union(through, head);
}
