/**
 * Standoffs / PCB mounting bosses.
 *
 * For each PCB, for each mounting hole, generate a standoff cylinder at the
 * hole's position projected to the enclosure floor (z = floorThickness).
 *
 * The standoff has an axial clearance hole for a self-tapping screw.
 */
import * as THREE from 'three';
import type { EnclosureProject, GeneratedPart, PCB } from '../types';
import { generateScrewBoss } from './screws';

export function generateStandoffs(project: EnclosureProject): GeneratedPart {
  const meshes: THREE.Mesh[] = [];
  const { floorThickness, width, depth } = project.dimensions;
  // Center of the enclosure's interior floor is at (0, 0, floorThickness).
  // PCB mounting hole (hx, hy) is in PCB-local coordinates; PCB center inside
  // enclosure is at (0, 0, pcb.positionZ - standoffHeight - pcb.thickness/2).
  // We position the standoff at the floor and project the hole's X/Y onto the
  // enclosure interior.
  for (const pcb of project.pcbs) {
    if (!pcb.visible) continue;
    for (const hole of pcb.mountingHoles) {
      // Hole's position in world X/Y = PCB center + hole position
      // (PCB center is at (0, 0) in enclosure coords.)
      const wx = hole.x;
      const wy = hole.y;
      // Clamp inside interior so standoff doesn't intersect walls.
      const interiorW = width - 2 * project.dimensions.wallThickness;
      const interiorD = depth - 2 * project.dimensions.wallThickness;
      if (Math.abs(wx) > interiorW / 2 - 2 || Math.abs(wy) > interiorD / 2 - 2) {
        continue;
      }
      const base = new THREE.Vector3(wx, wy, floorThickness);
      const standoff = generateScrewBoss(
        {
          size: 'custom',
          threadDiameter: pcb.standoffHoleDiameter,
          clearanceHole: pcb.standoffHoleDiameter,
          headDiameter: pcb.standoffHoleDiameter * 1.5,
          headHeight: 0,
          countersinkAngle: 90,
        },
        base,
        pcb.standoffHeight,
        pcb.standoffDiameter
      );
      meshes.push(standoff);
    }
  }
  return { id: 'standoffs', name: 'PCB Standoffs', meshes };
}

/**
 * Helper: compute the world position of a PCB mounting hole (X, Y, Z).
 */
export function pcbHoleWorldPosition(
  pcb: PCB,
  holeIndex: number,
  floorThickness: number
): THREE.Vector3 | null {
  const hole = pcb.mountingHoles[holeIndex];
  if (!hole) return null;
  const z = floorThickness + pcb.standoffHeight + pcb.thickness / 2;
  return new THREE.Vector3(hole.x, hole.y, z);
}
