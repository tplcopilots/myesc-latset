/**
 * Ventilation pattern generator.
 *
 * Generates a set of "brush" meshes positioned on the chosen face. The caller
 * subtracts these brushes from the target mesh to create actual ventilation
 * holes.
 *
 * Patterns supported:
 *   - horizontal-slots
 *   - vertical-slots
 *   - circular-holes
 *   - honeycomb (hexagonal lattice)
 *   - grid (square holes)
 *   - none (returns [])
 */
import * as THREE from 'three';
import type { EnclosureProject, VentilationParameters } from '../types';
import { boxGeometry, cylinderGeometry } from './primitives';
import { faceBasis } from './cutouts';
import { subtract } from './csg';

export function generateVentilationBrushes(
  vent: VentilationParameters,
  project: EnclosureProject
): THREE.Mesh[] {
  if (!vent.visible || vent.pattern === 'none') return [];
  const dims = project.dimensions;
  const { center, u, v, n, faceSize } = faceBasis(vent.face, dims);

  // The ventilation region is inset by borderDistance from each edge.
  const totalU = faceSize.u - 2 * vent.borderDistance;
  const totalV = faceSize.v - 2 * vent.borderDistance;
  if (totalU <= 1 || totalV <= 1) return [];

  // Extrude depth: just over the wall thickness so brushes punch through.
  const wall = Math.max(dims.wallThickness, 1);
  const depth = wall + 1.0;

  // Helper: build a brush at (du, dv) on the face plane, with the brush's own
  // local +Z aligned with the outward face normal `n`.
  const place = (brushLocal: THREE.BufferGeometry, du: number, dv: number): THREE.Mesh => {
    const mesh = new THREE.Mesh(brushLocal, new THREE.MeshStandardMaterial());
    mesh.quaternion.setFromUnitVectors(
      new THREE.Vector3(0, 0, 1),
      n.clone().normalize()
    );
    const pos = center
      .clone()
      .addScaledVector(u, du)
      .addScaledVector(v, dv)
      .addScaledVector(n, -0.01);
    mesh.position.copy(pos);
    mesh.updateMatrixWorld();
    return mesh;
  };

  const meshes: THREE.Mesh[] = [];

  switch (vent.pattern) {
    case 'horizontal-slots': {
      // Slots laid out in `rows` horizontal rows; each row spans the full
      // width as a single slot (slotHeight tall).
      const rowSpacing = totalV / Math.max(1, vent.rows);
      for (let r = 0; r < vent.rows; r++) {
        const dv = -totalV / 2 + rowSpacing / 2 + r * rowSpacing;
        const w = Math.min(vent.slotWidth, totalU);
        meshes.push(place(boxGeometry(w, vent.slotHeight, depth), 0, dv));
      }
      break;
    }
    case 'vertical-slots': {
      const colSpacing = totalU / Math.max(1, vent.columns);
      for (let c = 0; c < vent.columns; c++) {
        const du = -totalU / 2 + colSpacing / 2 + c * colSpacing;
        const h = Math.min(vent.slotHeight, totalV);
        meshes.push(place(boxGeometry(vent.slotWidth, h, depth), du, 0));
      }
      break;
    }
    case 'circular-holes': {
      const cols = Math.max(1, vent.columns);
      const rows = Math.max(1, vent.rows);
      const cellU = totalU / cols;
      const cellV = totalV / rows;
      const radius = Math.max(0.5, Math.min(vent.slotWidth, cellU, cellV) / 2 - 0.2);
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const du = -totalU / 2 + cellU / 2 + c * cellU;
          const dv = -totalV / 2 + cellV / 2 + r * cellV;
          meshes.push(place(cylinderGeometry(radius, depth, 24, false, 'z'), du, dv));
        }
      }
      break;
    }
    case 'grid': {
      const cols = Math.max(1, vent.columns);
      const rows = Math.max(1, vent.rows);
      const cellU = totalU / cols;
      const cellV = totalV / rows;
      const w = Math.min(vent.slotWidth, cellU - 0.5);
      const h = Math.min(vent.slotHeight, cellV - 0.5);
      for (let r = 0; r < rows; r++) {
        for (let c = 0; c < cols; c++) {
          const du = -totalU / 2 + cellU / 2 + c * cellU;
          const dv = -totalV / 2 + cellV / 2 + r * cellV;
          meshes.push(place(boxGeometry(w, h, depth), du, dv));
        }
      }
      break;
    }
    case 'honeycomb': {
      // Hexagonal close-packed arrangement. Each cell is a circle of radius
      // `cellRadius`; rows are offset by cellRadius on alternate rows.
      const radius = Math.max(0.5, vent.cellRadius || 3);
      const stepU = radius * Math.sqrt(3); // horizontal spacing
      const stepV = radius * 1.5; // vertical spacing
      const cols = Math.max(1, Math.floor((totalU - radius) / stepU));
      const rows = Math.max(1, Math.floor((totalV - radius) / stepV));
      const totalH = (cols - 1) * stepU;
      const totalVd = (rows - 1) * stepV;
      const startU = -totalH / 2;
      const startV = -totalVd / 2;
      for (let r = 0; r < rows; r++) {
        const offsetX = r % 2 === 0 ? 0 : stepU / 2;
        for (let c = 0; c < cols; c++) {
          const du = startU + c * stepU + offsetX;
          const dv = startV + r * stepV;
          meshes.push(place(cylinderGeometry(radius * 0.95, depth, 24, false, 'z'), du, dv));
        }
      }
      break;
    }
  }

  return meshes;
}

/**
 * Apply ventilation to a target mesh by subtracting all ventilation brushes.
 * Returns the new mesh (does NOT mutate the input).
 */
export function applyVentilationTo(
  target: THREE.Mesh,
  project: EnclosureProject
): THREE.Mesh {
  const brushes = generateVentilationBrushes(project.ventilation, project);
  if (brushes.length === 0) return target;
  return subtract(target, ...brushes);
}
