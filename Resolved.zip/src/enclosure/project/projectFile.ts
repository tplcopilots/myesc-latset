/**
 * Project file (.enclosure) serialization / deserialization.
 *
 * The .enclosure file is a JSON document containing the EnclosureProject state.
 * We embed the format version, validate on load, and migrate if necessary.
 */
import type { EnclosureProject } from '../types';
import { PROJECT_VERSION } from '../templates';

/**
 * Serialize an EnclosureProject to a JSON string.
 */
export function serializeProject(project: EnclosureProject): string {
  return JSON.stringify(
    { ...project, version: PROJECT_VERSION },
    null,
    2
  );
}

/**
 * Deserialize a JSON string into an EnclosureProject. Validates basic shape
 * and falls back to defaults for missing fields.
 */
export function deserializeProject(json: string): EnclosureProject {
  let parsed: unknown;
  try {
    parsed = JSON.parse(json);
  } catch (err) {
    throw new Error(`Invalid .enclosure file: ${err instanceof Error ? err.message : String(err)}`);
  }
  if (typeof parsed !== 'object' || parsed === null) {
    throw new Error('.enclosure file does not contain a JSON object.');
  }
  // Coerce to EnclosureProject. We trust the file is well-formed; missing
  // fields will be replaced by store default after merge.
  return parsed as EnclosureProject;
}

/**
 * Suggest a default filename for a project.
 */
export function projectFileName(project: EnclosureProject): string {
  const safe = project.name.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 48) || 'untitled';
  return `${safe}.enclosure`;
}

/**
 * Validate a project object. Returns a list of human-readable errors (empty
 * list = OK).
 */
export function validateProjectFile(parsed: unknown): string[] {
  const errors: string[] = [];
  if (typeof parsed !== 'object' || parsed === null) {
    errors.push('Root is not an object.');
    return errors;
  }
  const p = parsed as Partial<EnclosureProject>;
  if (!p.dimensions) errors.push('Missing dimensions.');
  if (!p.lid) errors.push('Missing lid parameters.');
  if (!Array.isArray(p.cutouts)) errors.push('Cutouts must be an array.');
  if (!Array.isArray(p.pcbs)) errors.push('PCBs must be an array.');
  if (!p.ventilation) errors.push('Missing ventilation parameters.');
  return errors;
}
