/**
 * Photorealistic image renderer — studio-quality product shots.
 */
import * as THREE from 'three';
import { generateEnclosureGeometry } from '../geometry';
import { repairMeshes } from '../geometry/repair';
import { MATERIAL_PRESETS } from '../types';
import type { EnclosureProject, PartId } from '../types';

export type RenderViewMode = 'external' | 'internal' | 'exploded';
export type RenderBackground = 'transparent' | 'white' | 'dark' | 'studio';
export type RenderResolution = '720p' | '1080p' | '4k';

interface RenderOptions {
  view: RenderViewMode;
  background: RenderBackground;
  resolution: RenderResolution;
  useMaterialColors: boolean;
}

const RESOLUTION_MAP: Record<RenderResolution, { width: number; height: number }> = {
  '720p': { width: 1280, height: 720 },
  '1080p': { width: 1920, height: 1080 },
  '4k': { width: 3840, height: 2160 },
};

function getBackground(bg: RenderBackground): THREE.Color | null {
  switch (bg) {
    case 'transparent': return null;
    case 'white': return new THREE.Color(0xf8fafc);
    case 'dark': return new THREE.Color(0x0f172a);
    case 'studio': return new THREE.Color(0x1e262b);
  }
}

function getExplodedOffset(partId: PartId, modelHeight: number): THREE.Vector3 {
  const lift = Math.max(20, modelHeight * 0.3);
  switch (partId) {
    case 'bottom': return new THREE.Vector3(0, 0, 0);
    case 'lid': return new THREE.Vector3(0, 0, lift);
    case 'feet': return new THREE.Vector3(0, 0, -lift * 0.5);
    default: return new THREE.Vector3(0, 0, 0);
  }
}

export async function renderProjectImage(project: EnclosureProject, options: RenderOptions): Promise<Blob> {
  const { width, height } = RESOLUTION_MAP[options.resolution];
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const repaired = repairMeshes(allMeshes, 0.01);

  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const renderer = new THREE.WebGLRenderer({ canvas, antialias: true, alpha: options.background === 'transparent', preserveDrawingBuffer: true });
  renderer.setPixelRatio(1);
  renderer.setSize(width, height);
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.PCFShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.0;
  renderer.localClippingEnabled = true;

  const scene = new THREE.Scene();
  scene.background = getBackground(options.background);

  // Subtle environment map for PBR diffuse
  const pmrem = new THREE.PMREMGenerator(renderer);
  const skyCanvas = document.createElement('canvas');
  skyCanvas.width = 2; skyCanvas.height = 256;
  const skyCtx = skyCanvas.getContext('2d')!;
  const grad = skyCtx.createLinearGradient(0, 0, 0, 256);
  grad.addColorStop(0, '#3a5070'); grad.addColorStop(0.5, '#5a7a9a'); grad.addColorStop(1, '#8aafcf');
  skyCtx.fillStyle = grad; skyCtx.fillRect(0, 0, 2, 256);
  const skyTex = new THREE.CanvasTexture(skyCanvas);
  skyTex.mapping = THREE.EquirectangularReflectionMapping;
  const skyScene = new THREE.Scene(); skyScene.background = skyTex;
  const envRT = pmrem.fromScene(skyScene, 0.04);
  scene.environment = envRT.texture;

  // 3-point lighting (DirectionalLights — no decay)
  scene.add(new THREE.AmbientLight(0xffffff, 0.3));
  const keyLight = new THREE.DirectionalLight(0xffffff, 1.5);
  keyLight.position.set(150, 250, 200);
  keyLight.castShadow = true;
  keyLight.shadow.mapSize.width = 2048; keyLight.shadow.mapSize.height = 2048;
  keyLight.shadow.camera.near = 10; keyLight.shadow.camera.far = 1000;
  keyLight.shadow.camera.left = -200; keyLight.shadow.camera.right = 200;
  keyLight.shadow.camera.top = 200; keyLight.shadow.camera.bottom = -200;
  keyLight.shadow.bias = -0.0005; keyLight.shadow.radius = 8;
  scene.add(keyLight);
  const fillLight = new THREE.DirectionalLight(0xa0c4ff, 0.6);
  fillLight.position.set(-180, 80, 150); scene.add(fillLight);
  const rimLight = new THREE.DirectionalLight(0xffffff, 0.8);
  rimLight.position.set(0, 150, -200); scene.add(rimLight);

  // Ground plane
  if (options.background !== 'transparent') {
    const groundGeom = new THREE.PlaneGeometry(1000, 1000);
    const groundMat = new THREE.ShadowMaterial({ opacity: 0.3 });
    const ground = new THREE.Mesh(groundGeom, groundMat);
    ground.rotation.x = -Math.PI / 2; ground.receiveShadow = true;
    scene.add(ground);
  }

  const materialPreset = MATERIAL_PRESETS[project.material];
  const meshes: THREE.Mesh[] = [];

  for (const mesh of repaired) {
    mesh.updateMatrixWorld(true);
    const partType = (mesh.userData?.partType || mesh.userData?.partId || 'bottom') as PartId;
    let color = new THREE.Color(materialPreset.color);
    if (mesh.material) {
      const mat = Array.isArray(mesh.material) ? mesh.material[0] : mesh.material;
      if (mat && 'color' in mat) color = (mat as THREE.MeshStandardMaterial).color.clone();
    }
    const roughness = Math.max(0.4, Math.min(0.6, materialPreset.roughness));
    const newMat = new THREE.MeshStandardMaterial({
      color, roughness, metalness: 0.0,
      transparent: materialPreset.opacity < 1, opacity: materialPreset.opacity,
      side: THREE.DoubleSide,
    });
    if (options.view === 'internal') {
      const clipPlane = new THREE.Plane(new THREE.Vector3(0, 0, -1), 0);
      newMat.clippingPlanes = [clipPlane]; newMat.clipShadows = true;
    }
    const newMesh = new THREE.Mesh(mesh.geometry, newMat);
    newMesh.applyMatrix4(mesh.matrixWorld);
    newMesh.castShadow = true; newMesh.receiveShadow = true;
    if (options.view === 'exploded') {
      const offset = getExplodedOffset(partType, result.boundingBox.max.z - result.boundingBox.min.z);
      newMesh.position.x += offset.x; newMesh.position.y += offset.y; newMesh.position.z += offset.z;
    }
    scene.add(newMesh); meshes.push(newMesh);
  }

  // Camera — 3/4 perspective
  const bbox = new THREE.Box3();
  for (const m of meshes) bbox.expandByObject(m);
  const center = new THREE.Vector3(); const size = new THREE.Vector3();
  bbox.getCenter(center); bbox.getSize(size);
  const maxDim = Math.max(size.x, size.y, size.z, 1);
  const camera = new THREE.PerspectiveCamera(45, width / height, 0.1, maxDim * 100);
  const dist = maxDim * 3.0;
  const angleH = 35 * Math.PI / 180; const angleV = 25 * Math.PI / 180;
  camera.position.set(
    center.x + dist * Math.sin(angleH),
    center.y + dist * Math.sin(angleV),
    center.z + dist * Math.cos(angleH) * Math.cos(angleV),
  );
  camera.lookAt(center);
  camera.near = maxDim / 100; camera.far = maxDim * 100;
  camera.updateProjectionMatrix();

  // Position ground
  if (options.background !== 'transparent') {
    const groundMesh = scene.children.find(c => c instanceof THREE.Mesh && c.material instanceof THREE.ShadowMaterial) as THREE.Mesh | undefined;
    if (groundMesh) groundMesh.position.y = bbox.min.y;
  }

  renderer.render(scene, camera);

  const blob = await new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(b => b ? resolve(b) : reject(new Error('Canvas toBlob failed')), 'image/png', 1.0);
  });

  pmrem.dispose(); renderer.dispose(); canvas.remove();
  return blob;
}

export function renderFileName(project: EnclosureProject, options: RenderOptions): string {
  const safe = project.name.replace(/[^a-zA-Z0-9_\-]/g, '_').slice(0, 48) || 'enclosure';
  const viewTag = options.view === 'external' ? '' : `_${options.view}`;
  const resTag = options.resolution === '1080p' ? '' : `_${options.resolution}`;
  return `${safe}${viewTag}${resTag}.png`;
}
