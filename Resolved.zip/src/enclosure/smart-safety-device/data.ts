/**
 * Smart Safety Harness Device — component data model.
 * Based on reference: 111mm H × 68mm W × 32mm D rugged wearable IoT device.
 */

export interface SafetyDeviceComponent {
  id: string;
  name: string;
  filename: string | null;
  category: 'enclosure' | 'mechanical' | 'electronic' | 'fastener';
  description: string;
  shape: string;
  purpose: string;
  dimensions: string;
  material: string;
  supportsRequired: boolean;
  assemblyOrder: number;
  hasSTL: boolean;
}

export const DEVICE_DIMENSIONS = { height: 111, width: 68, depth: 32 };

export const PRINT_SPECS = {
  material: 'PETG / ABS / PC',
  layerHeight: '0.20 mm',
  infill: '30–40%',
  wallThickness: '3.0 mm',
  topBottomThickness: '3.0 mm',
  supports: 'Yes (Top Case & Clip)',
  fasteners: 'M3 × 10 mm × 4 pieces',
};

export const ASSEMBLY_ORDER = [
  'Bottom Case', 'PCB Mount', 'PCB', 'Top Case',
  'Front Cover', 'USB Cover', 'Belt Clip', 'M3 × 10 mm Screws',
];

export const SAFETY_DEVICE_COMPONENTS: SafetyDeviceComponent[] = [
  { id: 'front_cover', name: 'Front Cover', filename: 'front_cover.stl', category: 'enclosure', description: 'Front protective/display cover. Compact rectangular with rounded corners and thin profile. Fits the front face to protect display and buttons.', shape: 'Compact rectangular, rounded corners, thin profile', purpose: 'Protects front display and button area from impact, dust, and moisture.', dimensions: 'Not specified', material: 'PETG / ABS / PC', supportsRequired: false, assemblyOrder: 5, hasSTL: false },
  { id: 'top_case', name: 'Top Case', filename: 'top_case.stl', category: 'enclosure', description: 'Upper protective shell. Rugged rectangular frame with chamfered edges, thick perimeter, central opening, and screw mounts.', shape: 'Rugged rectangular frame, chamfered edges, reinforced corners', purpose: 'Forms upper half of enclosure around electronics and display.', dimensions: 'Not specified', material: 'PETG / ABS / PC', supportsRequired: true, assemblyOrder: 4, hasSTL: false },
  { id: 'bottom_case', name: 'Bottom Case', filename: 'bottom_case.stl', category: 'enclosure', description: 'Lower half of enclosure. Rugged shell with chamfered corners, internal cavity, screw-post locations, raised perimeter wall.', shape: 'Rugged rectangular shell, chamfered corners, raised perimeter', purpose: 'Forms lower half. Contains internal cavity for PCB/electronics with screw mounts.', dimensions: 'Not specified', material: 'PETG / ABS / PC', supportsRequired: false, assemblyOrder: 1, hasSTL: false },
  { id: 'pcb_mount', name: 'PCB Mount', filename: 'pcb_mount.stl', category: 'mechanical', description: 'Internal mechanical component. Positions PCB securely. Narrow vertical structure with mounting points.', shape: 'Narrow vertical rectangular, mounting points', purpose: 'Positions and secures PCB inside enclosure.', dimensions: 'Not specified', material: 'PETG / ABS / PC', supportsRequired: false, assemblyOrder: 2, hasSTL: false },
  { id: 'belt_clip', name: 'Belt Clip', filename: 'belt_clip.stl', category: 'mechanical', description: 'Long vertical clip with chamfered edges, thick body, upper/lower mounting points, curved clip section.', shape: 'Long vertical clip, curved profile, thick body', purpose: 'Secures device to safety harness, belt, or strap.', dimensions: 'Not specified', material: 'PETG / ABS / PC', supportsRequired: true, assemblyOrder: 7, hasSTL: false },
  { id: 'usb_cover', name: 'USB Cover', filename: 'usb_cover.stl', category: 'mechanical', description: 'Small removable protective plug. Rounded profile. Fits USB port opening.', shape: 'Small rounded plug, compact profile', purpose: 'Protects USB port from dust, water, and physical damage.', dimensions: 'Not specified', material: 'PETG / ABS / PC', supportsRequired: false, assemblyOrder: 6, hasSTL: false },
  { id: 'screws', name: 'Screws / Fasteners', filename: null, category: 'fastener', description: 'M3 × 10mm screws, 4 pieces. Assembles enclosure components.', shape: 'Standard M3 machine screws', purpose: 'Fastens top case, bottom case, and PCB mount together.', dimensions: 'M3 × 10 mm × 4 pieces', material: 'Stainless Steel', supportsRequired: false, assemblyOrder: 8, hasSTL: false },
  { id: 'pcb', name: 'PCB', filename: null, category: 'electronic', description: 'Narrow vertical rectangular PCB with rounded corners, mounting holes, and components.', shape: 'Narrow vertical rectangle, rounded corners', purpose: 'Main electronics board with processor, sensors, and connectivity.', dimensions: 'Not specified', material: 'FR4', supportsRequired: false, assemblyOrder: 3, hasSTL: false },
  { id: 'display', name: 'Display', filename: null, category: 'electronic', description: 'Rectangular display with rounded corners. Shows status, signal, battery, timer, safety info.', shape: 'Rectangular, rounded corners', purpose: 'Displays device status and safety information.', dimensions: 'Not specified', material: 'Not specified', supportsRequired: false, assemblyOrder: 0, hasSTL: false },
  { id: 'buttons', name: 'Buttons', filename: null, category: 'electronic', description: 'Two physical buttons below display for interaction.', shape: 'Circular/rectangular tactile', purpose: 'User input for device control and safety functions.', dimensions: 'Not specified', material: 'Not specified', supportsRequired: false, assemblyOrder: 0, hasSTL: false },
];

export const DEVICE_VIEWS = [
  { id: 'front', name: 'Front View', description: 'Display, buttons, rugged protective frame.' },
  { id: 'back', name: 'Back View', description: 'Belt clip mounting, mechanical reinforcement.' },
  { id: 'top', name: 'Top View', description: 'Rounded rectangular, rugged outer shell.' },
  { id: 'bottom', name: 'Bottom View', description: 'Bottom Electrical Contact Interface.' },
  { id: 'left', name: 'Left View', description: 'Left Side Interface — circular mechanical element.' },
  { id: 'right', name: 'Right View', description: 'USB Port + USB Protective Cover.' },
];
