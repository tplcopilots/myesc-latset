/**
 * Enclosure designer state store (Zustand).
 *
 * Holds:
 *   - project: the current EnclosureProject (mutated through actions)
 *   - history / future: stacks for undo / redo
 *   - selectedPart, selectedCutoutId: UI selection state
 *   - viewMode, currentView: viewport state
 *   - validationIssues: cached result of validate(project)
 *
 * Undo/redo: every mutating action calls `commit()` first to push a deep
 * clone of the current project to `history`, then applies the mutation.
 */
import { create } from 'zustand';
import type {
  EnclosureProject,
  LidParameters,
  ScrewSpec,
  Cutout,
  PCB,
  VentilationParameters,
  SnapFitParameters,
  HingeParameters,
  FeetParameters,
  InternalSupportParameters,
  MaterialType,
  ApplicationSettings,
  PartId,
  ValidationIssue,
  EnclosureShape,
  CutoutFace,
  LabelParameters,
  Vec3,
  Decoration,
  TextDecoration,
  LogoDecoration,
  ShapeDecoration,
} from '../types';
import { defaultProject, TEMPLATES } from '../templates';
import { defaultSample } from '../templates/samples';
import { validate } from '../validation/validator';
import {
  createTextDecoration,
  createLogoDecoration,
  createShapeDecoration,
} from '../geometry/decorations';
import { uid } from '../utils/id';

const HISTORY_LIMIT = 100;

export type ViewMode = 'solid' | 'wireframe' | 'transparent' | 'section';
export type CameraView = 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom' | 'iso';

export interface EnclosureStoreState {
  project: EnclosureProject;
  history: EnclosureProject[];
  future: EnclosureProject[];
  selectedPart: PartId | null;
  selectedCutoutId: string | null;
  selectedPCBId: string | null;
  viewMode: ViewMode;
  currentView: CameraView;
  showGrid: boolean;
  showAxes: boolean;
  showBoundingBox: boolean;
  validationIssues: ValidationIssue[];
  /** Whether to force a geometry regen on next render. */
  dirty: boolean;

  // Mutation actions (each calls commit() first).
  setDimensions: (partial: Partial<EnclosureProject['dimensions']>) => void;
  setLid: (partial: Partial<LidParameters>) => void;
  setScrew: (partial: Partial<ScrewSpec>) => void;
  addCutout: (cutout?: Partial<Cutout>) => void;
  updateCutout: (id: string, partial: Partial<Cutout>) => void;
  removeCutout: (id: string) => void;
  addPCB: (pcb?: Partial<PCB>) => void;
  updatePCB: (id: string, partial: Partial<PCB>) => void;
  removePCB: (id: string) => void;
  setVentilation: (partial: Partial<VentilationParameters>) => void;
  setSnapFit: (partial: Partial<SnapFitParameters>) => void;
  setHinge: (partial: Partial<HingeParameters>) => void;
  setFeet: (partial: Partial<FeetParameters>) => void;
  setInternalSupport: (partial: Partial<InternalSupportParameters>) => void;
  addLabel: (label?: Partial<LabelParameters>) => void;
  removeLabel: (index: number) => void;
  // Decorations: text / logo / shape on any face.
  addTextDecoration: (overrides?: Partial<TextDecoration>) => void;
  addLogoDecoration: (overrides?: Partial<LogoDecoration>) => void;
  addShapeDecoration: (overrides?: Partial<ShapeDecoration>) => void;
  updateDecoration: (id: string, partial: Partial<Decoration>) => void;
  removeDecoration: (id: string) => void;
  setMaterial: (m: MaterialType) => void;
  setSettings: (partial: Partial<ApplicationSettings>) => void;
  setPrintOrientation: (partial: Partial<Vec3>) => void;
  renameProject: (name: string) => void;
  setShape: (shape: EnclosureShape) => void;

  // Project / template actions.
  newProject: () => void;
  loadProject: (project: EnclosureProject) => void;
  loadTemplate: (shape: EnclosureShape) => void;
  loadSample: (sampleId: string) => void;

  // Undo / redo.
  undo: () => void;
  redo: () => void;
  commit: () => void;

  // UI state.
  setViewMode: (m: ViewMode) => void;
  setCurrentView: (v: CameraView) => void;
  setSelectedPart: (p: PartId | null) => void;
  setSelectedCutoutId: (id: string | null) => void;
  setSelectedPCBId: (id: string | null) => void;
  setShowGrid: (b: boolean) => void;
  setShowAxes: (b: boolean) => void;
  setShowBoundingBox: (b: boolean) => void;
  setValidationIssues: (issues: ValidationIssue[]) => void;
  runValidation: () => void;
  markClean: () => void;
}

function deepCloneProject(p: EnclosureProject): EnclosureProject {
  return JSON.parse(JSON.stringify(p)) as EnclosureProject;
}

export const useEnclosureStore = create<EnclosureStoreState>((set, get) => {
  // `commit` push current to history (cloned), clear future.
  const commit = () => {
    const { project, history } = get();
    const newHistory = [...history, deepCloneProject(project)];
    if (newHistory.length > HISTORY_LIMIT) newHistory.shift();
    set({ history: newHistory, future: [], dirty: true });
  };

  return {
    project: defaultSample(),
    history: [],
    future: [],
    selectedPart: 'bottom',
    selectedCutoutId: null,
    selectedPCBId: null,
    viewMode: 'solid',
    currentView: 'iso',
    showGrid: true,
    showAxes: true,
    showBoundingBox: false,
    validationIssues: [],
    dirty: true,

    setDimensions: (partial) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          dimensions: { ...s.project.dimensions, ...partial },
        },
        dirty: true,
      }));
    },
    setLid: (partial) => {
      commit();
      set(s => ({
        project: { ...s.project, lid: { ...s.project.lid, ...partial } },
        dirty: true,
      }));
    },
    setScrew: (partial) => {
      commit();
      set(s => ({
        project: { ...s.project, screw: { ...s.project.screw, ...partial } },
        dirty: true,
      }));
    },
    addCutout: (cutout) => {
      commit();
      set(s => {
        const newCutout: Cutout = {
          id: uid('cutout'),
          name: cutout?.name ?? 'New Cutout',
          face: cutout?.face ?? ('back' as CutoutFace),
          shape: cutout?.shape ?? 'rectangle',
          positionX: cutout?.positionX ?? 0,
          positionY: cutout?.positionY ?? 0,
          width: cutout?.width ?? 10,
          height: cutout?.height ?? 10,
          diameter: cutout?.diameter ?? 0,
          cornerRadius: cutout?.cornerRadius ?? 0,
          rotation: cutout?.rotation ?? 0,
          depth: cutout?.depth ?? s.project.dimensions.wallThickness,
          points: cutout?.points ?? [],
          preset: cutout?.preset,
          visible: cutout?.visible ?? true,
        };
        return {
          project: { ...s.project, cutouts: [...s.project.cutouts, newCutout] },
          selectedCutoutId: newCutout.id,
          dirty: true,
        };
      });
    },
    updateCutout: (id, partial) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          cutouts: s.project.cutouts.map(c => (c.id === id ? { ...c, ...partial } : c)),
        },
        dirty: true,
      }));
    },
    removeCutout: (id) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          cutouts: s.project.cutouts.filter(c => c.id !== id),
        },
        selectedCutoutId: null,
        dirty: true,
      }));
    },
    addPCB: (pcb) => {
      commit();
      set(s => {
        const newPCB: PCB = {
          id: uid('pcb'),
          name: pcb?.name ?? 'PCB',
          width: pcb?.width ?? 50,
          height: pcb?.height ?? 30,
          thickness: pcb?.thickness ?? 1.6,
          positionZ: pcb?.positionZ ?? 10,
          mountingHoles: pcb?.mountingHoles ?? [
            { id: uid('hole'), x: -20, y: -10, diameter: 2.6 },
            { id: uid('hole'), x: 20, y: -10, diameter: 2.6 },
            { id: uid('hole'), x: -20, y: 10, diameter: 2.6 },
            { id: uid('hole'), x: 20, y: 10, diameter: 2.6 },
          ],
          standoffHeight: pcb?.standoffHeight ?? 6,
          standoffDiameter: pcb?.standoffDiameter ?? 6,
          standoffHoleDiameter: pcb?.standoffHoleDiameter ?? 2.6,
          visible: pcb?.visible ?? true,
        };
        return {
          project: { ...s.project, pcbs: [...s.project.pcbs, newPCB] },
          selectedPCBId: newPCB.id,
          dirty: true,
        };
      });
    },
    updatePCB: (id, partial) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          pcbs: s.project.pcbs.map(p => (p.id === id ? { ...p, ...partial } : p)),
        },
        dirty: true,
      }));
    },
    removePCB: (id) => {
      commit();
      set(s => ({
        project: { ...s.project, pcbs: s.project.pcbs.filter(p => p.id !== id) },
        selectedPCBId: null,
        dirty: true,
      }));
    },
    setVentilation: (partial) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          ventilation: { ...s.project.ventilation, ...partial },
        },
        dirty: true,
      }));
    },
    setSnapFit: (partial) => {
      commit();
      set(s => ({
        project: { ...s.project, snapFit: { ...s.project.snapFit, ...partial } },
        dirty: true,
      }));
    },
    setHinge: (partial) => {
      commit();
      set(s => ({
        project: { ...s.project, hinge: { ...s.project.hinge, ...partial } },
        dirty: true,
      }));
    },
    setFeet: (partial) => {
      commit();
      set(s => ({
        project: { ...s.project, feet: { ...s.project.feet, ...partial } },
        dirty: true,
      }));
    },
    setInternalSupport: (partial) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          internalSupport: { ...s.project.internalSupport, ...partial },
        },
        dirty: true,
      }));
    },
    addLabel: (label) => {
      commit();
      set(s => {
        const newLabel: LabelParameters = {
          enabled: label?.enabled ?? true,
          text: label?.text ?? 'Label',
          size: label?.size ?? 5,
          depth: label?.depth ?? 0.5,
          face: label?.face ?? 'top',
          positionX: label?.positionX ?? 0,
          positionY: label?.positionY ?? 0,
          rotation: label?.rotation ?? 0,
        };
        return {
          project: { ...s.project, labels: [...s.project.labels, newLabel] },
          dirty: true,
        };
      });
    },
    removeLabel: (index) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          labels: s.project.labels.filter((_, i) => i !== index),
        },
        dirty: true,
      }));
    },
    // ----- Decorations: text / logo / shape -----
    addTextDecoration: (overrides) => {
      commit();
      const dec = createTextDecoration(overrides);
      set(s => ({
        project: {
          ...s.project,
          decorations: [...(s.project.decorations || []), dec],
        },
        dirty: true,
      }));
    },
    addLogoDecoration: (overrides) => {
      commit();
      const dec = createLogoDecoration(overrides);
      set(s => ({
        project: {
          ...s.project,
          decorations: [...(s.project.decorations || []), dec],
        },
        dirty: true,
      }));
    },
    addShapeDecoration: (overrides) => {
      commit();
      const dec = createShapeDecoration(overrides);
      set(s => ({
        project: {
          ...s.project,
          decorations: [...(s.project.decorations || []), dec],
        },
        dirty: true,
      }));
    },
    updateDecoration: (id, partial) => {
      // No commit per keystroke — debounce handled in component.
      set(s => ({
        project: {
          ...s.project,
          decorations: (s.project.decorations || []).map(d =>
            d.id === id ? ({ ...d, ...partial } as Decoration) : d
          ),
        },
        dirty: true,
      }));
    },
    removeDecoration: (id) => {
      commit();
      set(s => ({
        project: {
          ...s.project,
          decorations: (s.project.decorations || []).filter(d => d.id !== id),
        },
        dirty: true,
      }));
    },
    setMaterial: (m) => {
      commit();
      set(s => ({ project: { ...s.project, material: m }, dirty: true }));
    },
    setSettings: (partial) => {
      commit();
      set(s => ({
        project: { ...s.project, settings: { ...s.project.settings, ...partial } },
        dirty: false, // Settings don't change geometry.
      }));
    },
    setPrintOrientation: (partial) => {
      // Print orientation doesn't mutate geometry, only the rendering matrix.
      // Still record to history so user can undo.
      commit();
      set(s => ({
        project: {
          ...s.project,
          printOrientation: { ...s.project.printOrientation, ...partial },
        },
        dirty: false,
      }));
    },
    renameProject: (name) => {
      commit();
      set(s => ({ project: { ...s.project, name }, dirty: false }));
    },
    setShape: (shape) => {
      commit();
      set(s => ({ project: { ...s.project, shape }, dirty: true }));
    },

    newProject: () => {
      commit();
      const p = defaultProject();
      set({ project: p, selectedPart: 'bottom', dirty: true });
      get().runValidation();
    },
    loadProject: (project) => {
      commit();
      // Merge with defaults to backfill any missing fields.
      const base = defaultProject();
      const merged: EnclosureProject = {
        ...base,
        ...project,
        dimensions: { ...base.dimensions, ...project.dimensions },
        lid: { ...base.lid, ...project.lid },
        screw: { ...base.screw, ...project.screw },
        ventilation: { ...base.ventilation, ...project.ventilation },
        snapFit: { ...base.snapFit, ...project.snapFit },
        hinge: { ...base.hinge, ...project.hinge },
        feet: { ...base.feet, ...project.feet },
        internalSupport: { ...base.internalSupport, ...project.internalSupport },
        settings: { ...base.settings, ...project.settings },
        printOrientation: { ...base.printOrientation, ...project.printOrientation },
        pcbs: project.pcbs ?? [],
        cutouts: project.cutouts ?? [],
        labels: project.labels ?? [],
        decorations: project.decorations ?? [],
      };
      set({ project: merged, selectedPart: 'bottom', dirty: true });
      get().runValidation();
    },
    loadTemplate: (shape) => {
      commit();
      const overrides = TEMPLATES[shape]();
      const base = defaultProject();
      const project: EnclosureProject = {
        ...base,
        ...overrides,
        dimensions: { ...base.dimensions, ...(overrides.dimensions ?? {}) },
        lid: { ...base.lid, ...(overrides.lid ?? {}) },
        screw: { ...base.screw, ...(overrides.screw ?? {}) },
        ventilation: { ...base.ventilation, ...(overrides.ventilation ?? {}) },
        snapFit: { ...base.snapFit, ...(overrides.snapFit ?? {}) },
        hinge: { ...base.hinge, ...(overrides.hinge ?? {}) },
        feet: { ...base.feet, ...(overrides.feet ?? {}) },
        internalSupport: { ...base.internalSupport, ...(overrides.internalSupport ?? {}) },
        settings: { ...base.settings, ...(overrides.settings ?? {}) },
        pcbs: overrides.pcbs ?? [],
        cutouts: overrides.cutouts ?? [],
        labels: overrides.labels ?? [],
        decorations: overrides.decorations ?? [],
        shape,
      };
      set({ project, selectedPart: 'bottom', dirty: true });
      get().runValidation();
    },
    loadSample: (sampleId) => {
      commit();
      // Lazy import to avoid bundling samples into the main store.
      import('../templates/samples').then(({ SAMPLE_PROJECTS }) => {
        const sample = SAMPLE_PROJECTS.find(s => s.id === sampleId);
        if (!sample) return;
        const project = sample.project();
        set({ project, selectedPart: 'bottom', dirty: true });
        get().runValidation();
      });
    },

    undo: () => {
      const { history, project, future } = get();
      if (history.length === 0) return;
      const prev = history[history.length - 1];
      const newHistory = history.slice(0, -1);
      const newFuture = [deepCloneProject(project), ...future].slice(0, HISTORY_LIMIT);
      set({ project: prev, history: newHistory, future: newFuture, dirty: true });
    },
    redo: () => {
      const { future, project, history } = get();
      if (future.length === 0) return;
      const next = future[0];
      const newFuture = future.slice(1);
      const newHistory = [...history, deepCloneProject(project)].slice(-HISTORY_LIMIT);
      set({ project: next, history: newHistory, future: newFuture, dirty: true });
    },
    commit: () => commit(),

    setViewMode: (m) => set({ viewMode: m }),
    setCurrentView: (v) => set({ currentView: v }),
    setSelectedPart: (p) => set({ selectedPart: p }),
    setSelectedCutoutId: (id) => set({ selectedCutoutId: id }),
    setSelectedPCBId: (id) => set({ selectedPCBId: id }),
    setShowGrid: (b) => set({ showGrid: b }),
    setShowAxes: (b) => set({ showAxes: b }),
    setShowBoundingBox: (b) => set({ showBoundingBox: b }),
    setValidationIssues: (issues) => set({ validationIssues: issues }),
    runValidation: () => {
      const issues = validate(get().project);
      set({ validationIssues: issues });
    },
    markClean: () => set({ dirty: false }),
  };
});

/** Selector: get the current project (deep-equality is the user's concern). */
export function selectProject(s: EnclosureStoreState): EnclosureProject {
  return s.project;
}
