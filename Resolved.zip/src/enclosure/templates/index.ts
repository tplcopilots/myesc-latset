/**
 * Default project + 12 enclosure templates.
 *
 * Each template returns a Partial<EnclosureProject> of overrides applied on
 * top of the default project. The store's `loadTemplate(shape)` merges them.
 *
 * Defaults follow the spec's example: width=120, depth=80, height=40,
 * wall=2.5, corner radius=5.
 */
import type {
  EnclosureProject,
  EnclosureShape,
  EnclosureDimensions,
  LidParameters,
  ScrewSpec,
  PCB,
  Cutout,
  VentilationParameters,
  SnapFitParameters,
  HingeParameters,
  FeetParameters,
  InternalSupportParameters,
  LabelParameters,
  MaterialType,
  ApplicationSettings,
  ExportFormat,
  UnitSystem,
  ScrewSize,
} from '../types';
import { SCREW_PRESETS, CUTOUT_PRESETS } from '../types';

export const PROJECT_VERSION = '1.0.0';

export const DEFAULT_DIMENSIONS: EnclosureDimensions = {
  width: 120,
  depth: 80,
  height: 40,
  wallThickness: 2.5,
  cornerRadius: 5,
  edgeBevel: 2.0,      // bevel all edges 2mm — makes it look professional
  draftAngle: 2,        // 2° draft angle — walls taper inward slightly
  floorThickness: 2.5,
};

export const DEFAULT_LID: LidParameters = {
  type: 'flat-removable',
  thickness: 2.5,
  clearance: 0.2,
  screwSpacing: 100,
  hingeSize: 8,
  snapFitTolerance: 0.2,
  visible: true,
};

export const DEFAULT_SCREW: ScrewSpec = {
  size: 'M3',
  ...SCREW_PRESETS.M3,
};

export const DEFAULT_VENTILATION: VentilationParameters = {
  pattern: 'none',
  face: 'back',
  slotWidth: 8,
  slotHeight: 3,
  spacing: 8,
  rows: 4,
  columns: 4,
  borderDistance: 5,
  cellRadius: 4,
  visible: true,
};

export const DEFAULT_SNAP_FIT: SnapFitParameters = {
  enabled: false,
  armLength: 8,
  armThickness: 1.6,
  hookHeight: 1.2,
  clearance: 0.2,
  flexDirection: 'x',
  count: 2,
};

export const DEFAULT_HINGE: HingeParameters = {
  enabled: false,
  size: 8,
  count: 2,
};

export const DEFAULT_FEET: FeetParameters = {
  enabled: false,
  diameter: 8,
  height: 2,
  count: 4,
};

export const DEFAULT_INTERNAL_SUPPORT: InternalSupportParameters = {
  enabled: false,
  diameter: 4,
  spacing: 30,
};

export const DEFAULT_SETTINGS: ApplicationSettings = {
  unit: 'mm',
  gridSize: 10,
  snapSize: 1,
  defaultWallThickness: 2.5,
  defaultClearance: 0.2,
  defaultScrew: 'M3' as ScrewSize,
  defaultExportFormat: 'stl-binary' as ExportFormat,
  theme: 'dark',
};

/**
 * The default project. The ESP32 sample overrides this on initial load.
 */
export function defaultProject(): EnclosureProject {
  return {
    version: PROJECT_VERSION,
    name: 'Untitled Enclosure',
    shape: 'rectangular',
    dimensions: { ...DEFAULT_DIMENSIONS },
    lid: { ...DEFAULT_LID },
    screw: { ...DEFAULT_SCREW },
    pcbs: [],
    cutouts: [],
    ventilation: { ...DEFAULT_VENTILATION },
    snapFit: { ...DEFAULT_SNAP_FIT },
    hinge: { ...DEFAULT_HINGE },
    feet: { ...DEFAULT_FEET },
    internalSupport: { ...DEFAULT_INTERNAL_SUPPORT },
    labels: [],
    decorations: [],
    material: 'PLA' as MaterialType,
    settings: { ...DEFAULT_SETTINGS },
    printOrientation: { x: 0, y: 0, z: 0 },
  };
}

// Helper for building a cutout quickly.
function cutoutFrom(presetId: string, face: Cutout['face'], x: number, y: number): Cutout {
  const preset = CUTOUT_PRESETS.find(p => p.id === presetId);
  if (!preset) {
    return {
      id: `cutout_${Math.random().toString(36).slice(2, 9)}`,
      name: 'Cutout',
      face,
      shape: 'rectangle',
      positionX: x,
      positionY: y,
      width: 10,
      height: 10,
      diameter: 0,
      cornerRadius: 0,
      rotation: 0,
      depth: 2.5,
      points: [],
      preset: presetId,
      visible: true,
    };
  }
  return {
    id: `cutout_${Math.random().toString(36).slice(2, 9)}`,
    name: preset.name,
    face,
    shape: preset.shape,
    positionX: x,
    positionY: y,
    width: preset.width,
    height: preset.height,
    diameter: preset.diameter,
    cornerRadius: preset.cornerRadius,
    rotation: 0,
    depth: 2.5,
    points: [],
    preset: preset.id,
    visible: true,
  };
}

function pcb(
  name: string,
  width: number,
  height: number,
  holes: { x: number; y: number; d: number }[],
  positionZ: number,
  standoffHeight = 6,
  standoffDiameter = 6,
  standoffHoleDiameter = 2.6
): PCB {
  return {
    id: `pcb_${Math.random().toString(36).slice(2, 9)}`,
    name,
    width,
    height,
    thickness: 1.6,
    positionZ,
    mountingHoles: holes.map(h => ({
      id: `hole_${Math.random().toString(36).slice(2, 9)}`,
      x: h.x,
      y: h.y,
      diameter: h.d,
    })),
    standoffHeight,
    standoffDiameter,
    standoffHoleDiameter,
    visible: true,
  };
}

export const TEMPLATES: Record<EnclosureShape, () => Partial<EnclosureProject>> = {
  rectangular: () => ({
    shape: 'rectangular',
    name: 'Rectangular Box',
    dimensions: { width: 100, depth: 60, height: 30, wallThickness: 2.5, cornerRadius: 3, edgeBevel: 2, draftAngle: 2, floorThickness: 2.5 },
    lid: { ...DEFAULT_LID, type: 'flat-removable' },
    cutouts: [],
    pcbs: [],
    ventilation: { ...DEFAULT_VENTILATION, pattern: 'none' },
  }),
  'electronics-project': () => ({
    shape: 'electronics-project',
    name: 'Electronics Project Box',
    dimensions: { width: 80, depth: 50, height: 25, wallThickness: 2.0, cornerRadius: 4, edgeBevel: 2.5, draftAngle: 2, floorThickness: 2.0 },
    lid: { ...DEFAULT_LID, type: 'screw' },
    screw: { size: 'M3', ...SCREW_PRESETS.M3 },
  }),
  'raspberry-pi': () => ({
    shape: 'raspberry-pi',
    name: 'Raspberry Pi Enclosure',
    dimensions: { width: 95, depth: 60, height: 30, wallThickness: 2.5, cornerRadius: 5, edgeBevel: 3, draftAngle: 2, floorThickness: 2.5 },
    lid: { ...DEFAULT_LID, type: 'flat-removable' },
    pcbs: [
      pcb(
        'Pi 4',
        85,
        56,
        [
          { x: -24.5, y: -49 / 2 + 3.5, d: 2.7 },
          { x: 24.5, y: -49 / 2 + 3.5, d: 2.7 },
          { x: -24.5, y: 49 / 2 - 3.5, d: 2.7 },
          { x: 24.5, y: 49 / 2 - 3.5, d: 2.7 },
        ],
        12
      ),
    ],
    cutouts: [
      cutoutFrom('usb-a', 'back', -30, 5),
      cutoutFrom('usb-a', 'back', -12, 5),
      cutoutFrom('usb-c', 'back', 14, 8),
      cutoutFrom('rj45', 'back', 32, 6),
      cutoutFrom('hdmi', 'back', 16, -8),
      cutoutFrom('dc-jack', 'back', -36, -8),
    ],
  }),
  arduino: () => ({
    shape: 'arduino',
    name: 'Arduino Enclosure',
    dimensions: { width: 80, depth: 55, height: 25, wallThickness: 2.0, cornerRadius: 3, edgeBevel: 2, draftAngle: 2, floorThickness: 2.0 },
    lid: { ...DEFAULT_LID, type: 'flat-removable' },
    pcbs: [
      pcb(
        'Arduino Uno',
        68.6,
        53.4,
        [
          { x: 14, y: 2.54, d: 3.0 },
          { x: -14, y: 2.54, d: 3.0 },
          { x: 14, y: -22.86, d: 3.0 },
          { x: -14, y: -22.86, d: 3.0 },
        ],
        10
      ),
    ],
    cutouts: [
      cutoutFrom('usb-b', 'back', 12, 6),
      cutoutFrom('dc-jack', 'back', -12, 6),
    ],
  }),
  sensor: () => ({
    shape: 'sensor',
    name: 'Sensor Enclosure',
    dimensions: { width: 40, depth: 30, height: 15, wallThickness: 1.6, cornerRadius: 2, edgeBevel: 1.5, draftAngle: 1.5, floorThickness: 1.6 },
    lid: { ...DEFAULT_LID, type: 'snap-fit' },
    snapFit: { ...DEFAULT_SNAP_FIT, enabled: true, count: 2, flexDirection: 'x' },
    cutouts: [
      cutoutFrom('led-3', 'front', 0, 4),
    ],
  }),
  'wall-mount': () => ({
    shape: 'wall-mount',
    name: 'Wall-Mount Enclosure',
    dimensions: { width: 80, depth: 50, height: 30, wallThickness: 2.5, cornerRadius: 4, edgeBevel: 2.5, draftAngle: 2, floorThickness: 2.5 },
    lid: { ...DEFAULT_LID, type: 'screw' },
    // Keyhole slots are represented as slot cutouts on the back face.
    cutouts: [
      {
        ...cutoutFrom('', 'back', -25, 0),
        name: 'Keyhole slot L',
        shape: 'slot',
        width: 8,
        height: 4,
      },
      {
        ...cutoutFrom('', 'back', 25, 0),
        name: 'Keyhole slot R',
        shape: 'slot',
        width: 8,
        height: 4,
      },
    ],
  }),
  handheld: () => ({
    shape: 'handheld',
    name: 'Handheld Enclosure',
    dimensions: { width: 100, depth: 60, height: 30, wallThickness: 3.0, cornerRadius: 10, edgeBevel: 4, draftAngle: 3, floorThickness: 3.0 },
    lid: { ...DEFAULT_LID, type: 'screw' },
    cutouts: [
      cutoutFrom('button', 'top', -30, -10),
      cutoutFrom('button', 'top', -15, -10),
      cutoutFrom('button', 'top', 0, -10),
      cutoutFrom('button', 'top', 15, -10),
      cutoutFrom('button', 'top', 30, -10),
      cutoutFrom('oled', 'top', 0, 10),
    ],
  }),
  junction: () => ({
    shape: 'junction',
    name: 'Junction Box',
    dimensions: { width: 100, depth: 80, height: 40, wallThickness: 3.0, cornerRadius: 5, edgeBevel: 3, draftAngle: 2, floorThickness: 3.0 },
    lid: { ...DEFAULT_LID, type: 'screw' },
    screw: { size: 'M4', ...SCREW_PRESETS.M4 },
  }),
  'din-rail': () => ({
    shape: 'din-rail',
    name: 'DIN-Rail Enclosure',
    dimensions: { width: 90, depth: 60, height: 35, wallThickness: 2.5, cornerRadius: 3, edgeBevel: 2, draftAngle: 2, floorThickness: 2.5 },
    lid: { ...DEFAULT_LID, type: 'snap-fit' },
    snapFit: { ...DEFAULT_SNAP_FIT, enabled: true },
    cutouts: [
      // DIN clip cutout on the back
      {
        ...cutoutFrom('', 'back', 0, 0),
        name: 'DIN clip',
        shape: 'slot',
        width: 35,
        height: 6,
      },
    ],
  }),
  waterproof: () => ({
    shape: 'waterproof',
    name: 'Waterproof Enclosure',
    dimensions: { width: 80, depth: 60, height: 30, wallThickness: 3.0, cornerRadius: 4, edgeBevel: 2.5, draftAngle: 2, floorThickness: 3.0 },
    lid: { ...DEFAULT_LID, type: 'screw', thickness: 3.0 },
    screw: { size: 'M3', ...SCREW_PRESETS.M3 },
    // Gasket groove: simulate as a slot cutout on the top of the bottom (lid
    // will sit on top of it). This is a simplification — a real gasket groove
    // is on the rim of the bottom part.
    cutouts: [
      {
        ...cutoutFrom('', 'top', 0, 0),
        name: 'Gasket groove',
        shape: 'slot',
        width: 70,
        height: 50,
        depth: 1.5,
      },
    ],
  }),
  ventilated: () => ({
    shape: 'ventilated',
    name: 'Ventilated Enclosure',
    dimensions: { width: 100, depth: 70, height: 30, wallThickness: 2.0, cornerRadius: 3, edgeBevel: 2, draftAngle: 2, floorThickness: 2.0 },
    lid: { ...DEFAULT_LID, type: 'flat-removable' },
    ventilation: {
      ...DEFAULT_VENTILATION,
      pattern: 'honeycomb',
      face: 'top',
      cellRadius: 3,
      rows: 6,
      columns: 8,
      borderDistance: 4,
      visible: true,
    },
  }),
  'smart-safety-device': () => ({
    shape: 'smart-safety-device',
    name: 'Smart Safety Device',
    // Rugged wearable IoT safety device — 111×68×32mm
    // Industrial design: large corner radius, edge bevel, draft angle
    // 4× M3 corner screws, display cutout, 2 buttons, USB-C, belt clip
    dimensions: { width: 68, depth: 32, height: 111, wallThickness: 3.0, cornerRadius: 8, edgeBevel: 3, draftAngle: 3, floorThickness: 3.0 },
    lid: { ...DEFAULT_LID, type: 'screw', thickness: 3.0, visible: true },
    snapFit: { ...DEFAULT_SNAP_FIT, enabled: false },
    screw: { ...SCREW_PRESETS['M3'], size: 'M3' as ScrewSize },
    pcbs: [{
      id: 'pcb_ssd', name: 'Smart Safety PCB', width: 50, height: 95, thickness: 1.6,
      positionZ: 12, mountingHoles: [
        { id: 'h1', x: -20, y: -38, diameter: 3.0 }, { id: 'h2', x: 20, y: -38, diameter: 3.0 },
        { id: 'h3', x: -20, y: 38, diameter: 3.0 }, { id: 'h4', x: 20, y: 38, diameter: 3.0 },
      ],
      standoffHeight: 6, standoffDiameter: 7, standoffHoleDiameter: 3.0, visible: true,
    }],
    internalLayout: {
      pcbOrientation: 'vertical', battery: null, arrangement: 'pcb-only', batteryPcbGap: 5,
      screwMount: { startFrom: 'bottom', height: 10, diameter: 10, inset: 5, holeDiameter: 3.0 },
      lidPanelHeight: 3, beltClipWidth: 50, strapSlotWidth: 0, strapSlotHeight: 6,
    },
    cutouts: [
      { id: 'c_display', name: 'Display', face: 'front', shape: 'rounded-rectangle', positionX: 0, positionY: 25, width: 40, height: 30, diameter: 0, cornerRadius: 3, rotation: 0, depth: 3, points: [], visible: true },
      { id: 'c_btn1', name: 'Button 1', face: 'front', shape: 'circle', positionX: -8, positionY: -10, width: 0, height: 0, diameter: 6, cornerRadius: 0, rotation: 0, depth: 3, points: [], visible: true },
      { id: 'c_btn2', name: 'Button 2', face: 'front', shape: 'circle', positionX: 8, positionY: -10, width: 0, height: 0, diameter: 6, cornerRadius: 0, rotation: 0, depth: 3, points: [], visible: true },
      { id: 'c_usb', name: 'USB-C', face: 'right', shape: 'rounded-rectangle', positionX: -20, positionY: 0, width: 9, height: 3.2, diameter: 0, cornerRadius: 1.5, rotation: 0, depth: 3, points: [], preset: 'usb-c', visible: true },
      { id: 'c_contacts', name: 'Bottom Contacts', face: 'bottom', shape: 'circle', positionX: 0, positionY: 0, width: 0, height: 0, diameter: 8, cornerRadius: 0, rotation: 0, depth: 3, points: [], visible: true },
    ],
  }),
  custom: () => ({
    shape: 'custom',
    name: 'Custom Enclosure',
    dimensions: { ...DEFAULT_DIMENSIONS },
    lid: { ...DEFAULT_LID },
    cutouts: [],
    pcbs: [],
  }),
  'esp32-s3-ec200u': () => ({
    shape: 'esp32-s3-ec200u',
    name: 'ESP32-S3 + A7672SA Kit',
    // Based on the ESP-S3-4G-DEV-Kit manual (KTRON.in).
    // Board: ESP32-S3-WROOM-1 + SIMCom A7672SA (4G LTE + 2G GSM).
    // PCB dimensions: 25.4 × 97mm, 1.6mm thick.
    // 4 mounting holes at (±10.16, ±43.18)mm, 3mm diameter.
    // 2 USB-C connectors on the right side (ESP_UART + 4G_USB).
    // 2 pin headers (2×22) on left + right edges.
    // U.FL antenna connector, status LED, boot/reset buttons.
    // SIM card slot on the back.
    //
    // Enclosure: 32 × 102 × 16mm — fits the 25.4×97mm PCB with 1.6mm walls.
    // The pin headers at ±11.43mm extend slightly beyond the PCB edge,
    // so the interior needs to be at least 28mm wide.
    dimensions: { width: 32, depth: 102, height: 16, wallThickness: 1.6, cornerRadius: 3, edgeBevel: 2, draftAngle: 2, floorThickness: 1.6 },
    lid: { ...DEFAULT_LID, type: 'snap-fit', visible: true },
    snapFit: { ...DEFAULT_SNAP_FIT, enabled: true, count: 2, flexDirection: 'x', armThickness: 1.4, hookHeight: 0.8 },
    screw: { ...SCREW_PRESETS['M2_5'], size: 'M2.5' as ScrewSize },
    // PCB: 25.4×97mm, 1.6mm thick, 4 M3 mounting holes at (±10.16, ±43.18)
    pcbs: [
      {
        id: 'pcb_esp32s3_a7672sa',
        name: 'ESP32-S3 + A7672SA',
        width: 25.4,
        height: 97,
        thickness: 1.6,
        positionZ: 8,
        mountingHoles: [
          { id: 'h1', x: -10.16, y: -43.18, diameter: 3.0 },
          { id: 'h2', x: 10.16, y: -43.18, diameter: 3.0 },
          { id: 'h3', x: -10.16, y: 43.18, diameter: 3.0 },
          { id: 'h4', x: 10.16, y: 43.18, diameter: 3.0 },
        ],
        standoffHeight: 5,
        standoffDiameter: 6,
        standoffHoleDiameter: 3.0,
        visible: true,
      },
    ],
    // Cutouts — based on actual component placement from the manual.
    // The board is held vertically (depth=102mm is the long Y axis).
    // Front = -Y (facing user), Back = +Y, Left = -X, Right = +X.
    cutouts: [
      // USB-C (ESP_UART) on the right side, upper area
      {
        id: 'cutout_usbc_esp',
        name: 'USB-C (ESP32)',
        face: 'right',
        shape: 'rounded-rectangle',
        positionX: 12.7,      // y position on the right face (u=Y)
        positionY: 0,         // z position (v=Z)
        width: 9,
        height: 3.2,
        diameter: 0,
        cornerRadius: 1.5,
        rotation: 0,
        depth: 1.6,
        points: [],
        preset: 'usb-c',
        visible: true,
      },
      // USB-C (4G_USB) on the right side, lower area
      {
        id: 'cutout_usbc_4g',
        name: 'USB-C (4G Modem)',
        face: 'right',
        shape: 'rounded-rectangle',
        positionX: 22.86,     // lower position
        positionY: 0,
        width: 9,
        height: 3.2,
        diameter: 0,
        cornerRadius: 1.5,
        rotation: 0,
        depth: 1.6,
        points: [],
        preset: 'usb-c',
        visible: true,
      },
      // U.FL antenna hole on the back (for A7672SA cellular antenna)
      {
        id: 'cutout_antenna',
        name: 'Cellular Antenna',
        face: 'back',
        shape: 'circle',
        positionX: -9.5,      // offset left
        positionY: -40.64,    // near bottom (A7672SA end)
        width: 0,
        height: 0,
        diameter: 2.2,
        cornerRadius: 0,
        rotation: 0,
        depth: 1.6,
        points: [],
        visible: true,
      },
      // SIM card slot on the back (A7672SA takes a micro-SIM)
      {
        id: 'cutout_sim',
        name: 'SIM Card Slot',
        face: 'back',
        shape: 'rectangle',
        positionX: 0,
        positionY: -35,      // near the A7672SA module
        width: 12,
        height: 11,
        diameter: 0,
        cornerRadius: 0,
        rotation: 0,
        depth: 1.6,
        points: [],
        visible: true,
      },
      // Boot/Reset button on the front (upper area, near ESP32-S3)
      {
        id: 'cutout_reset',
        name: 'Reset Button',
        face: 'front',
        shape: 'circle',
        positionX: -8.89,
        positionY: 15.24,
        width: 0,
        height: 0,
        diameter: 6.5,
        cornerRadius: 0,
        rotation: 0,
        depth: 1.6,
        points: [],
        preset: 'button',
        visible: true,
      },
      // Status LED (NETLIGHT) on the front (lower area, near A7672SA)
      {
        id: 'cutout_led',
        name: 'Status LED',
        face: 'front',
        shape: 'circle',
        positionX: 5.08,
        positionY: -40.64,
        width: 0,
        height: 0,
        diameter: 3.2,
        cornerRadius: 0,
        rotation: 0,
        depth: 1.6,
        points: [],
        preset: 'led-3',
        visible: true,
      },
    ],
  }),
};

// USB-B is now part of CUTOUT_PRESETS directly.

/** Helper exported for the inspector panel — list of (id, label) pairs. */
export const TEMPLATE_LIST: { id: EnclosureShape; name: string; description: string }[] = [
  { id: 'rectangular', name: 'Rectangular', description: 'Basic rectangular box' },
  { id: 'electronics-project', name: 'Electronics Project', description: 'Simple electronics box with screw lid' },
  { id: 'raspberry-pi', name: 'Raspberry Pi', description: '95×60×30 with Pi 4 cutouts' },
  { id: 'arduino', name: 'Arduino', description: '80×55×25 with Arduino Uno cutouts' },
  { id: 'sensor', name: 'Sensor', description: '40×30×15 small sensor box' },
  { id: 'wall-mount', name: 'Wall Mount', description: '80×50×30 with keyhole slots' },
  { id: 'handheld', name: 'Handheld', description: '100×60×30 with buttons + OLED' },
  { id: 'junction', name: 'Junction Box', description: '100×80×40 with screw lid' },
  { id: 'din-rail', name: 'DIN Rail', description: '90×60×35 with DIN clip cutout' },
  { id: 'waterproof', name: 'Waterproof', description: '80×60×30 with screw lid + gasket' },
  { id: 'ventilated', name: 'Ventilated', description: '100×70×30 with honeycomb vents' },
  { id: 'esp32-s3-ec200u', name: 'ESP32-S3 + A7672SA', description: '32×102×16 cellular dev kit — based on ESP-S3-4G-DEV-Kit manual (2× USB-C, SIM, antenna, LED, button)' },
  { id: 'smart-safety-device', name: 'Smart Safety Device', description: '68×32×111mm rugged wearable IoT device — display, buttons, USB, belt clip, 4× M3 screws (industrial design)' },
  { id: 'custom', name: 'Custom', description: 'Start from defaults' },
];
