/**
 * Sample projects that showcase the designer's major features. The app opens
 * with the ESP32 sample loaded by default.
 */
import type { EnclosureProject } from '../types';
import { SCREW_PRESETS, CUTOUT_PRESETS } from '../types';
import { defaultProject, TEMPLATES, PROJECT_VERSION, DEFAULT_LID, DEFAULT_SNAP_FIT } from './index';

function findPreset(id: string) {
  return CUTOUT_PRESETS.find(p => p.id === id);
}

function applyTemplate(project: EnclosureProject, shape: keyof typeof TEMPLATES): EnclosureProject {
  const overrides = TEMPLATES[shape]();
  return { ...project, ...overrides };
}

function esp32Project(): EnclosureProject {
  const base = defaultProject();
  base.name = 'ESP32 DevKit Enclosure';
  base.shape = 'custom';
  base.dimensions = {
    width: 60,
    depth: 28,
    height: 15,
    wallThickness: 1.6,
    cornerRadius: 3,
    floorThickness: 1.6,
  };
  base.lid = { ...base.lid, type: 'snap-fit', visible: true };
  base.snapFit = { ...base.snapFit, enabled: true, count: 2, flexDirection: 'y', armThickness: 1.4, hookHeight: 0.8 };
  base.material = 'PLA';
  // USB-C on the back-left, micro-USB on back-right (use button preset for
  // reset/boot buttons on the front).
  const usbc = findPreset('usb-c')!;
  const button = findPreset('button')!;
  base.cutouts = [
    {
      id: 'cutout_usbc',
      name: 'USB-C',
      face: 'back',
      shape: usbc.shape,
      positionX: -20,
      positionY: 0,
      width: usbc.width,
      height: usbc.height,
      diameter: 0,
      cornerRadius: usbc.cornerRadius,
      rotation: 0,
      depth: base.dimensions.wallThickness,
      points: [],
      preset: 'usb-c',
      visible: true,
    },
    {
      id: 'cutout_reset',
      name: 'Reset Button',
      face: 'front',
      shape: button.shape,
      positionX: -8,
      positionY: 0,
      width: 0,
      height: 0,
      diameter: button.diameter,
      cornerRadius: 0,
      rotation: 0,
      depth: base.dimensions.wallThickness,
      points: [],
      preset: 'button',
      visible: true,
    },
    {
      id: 'cutout_boot',
      name: 'Boot Button',
      face: 'front',
      shape: button.shape,
      positionX: 8,
      positionY: 0,
      width: 0,
      height: 0,
      diameter: button.diameter,
      cornerRadius: 0,
      rotation: 0,
      depth: base.dimensions.wallThickness,
      points: [],
      preset: 'button',
      visible: true,
    },
  ];
  // Add a couple of decorations to showcase the system on first load.
  base.decorations = [
    {
      id: 'dec_esp32_label',
      name: 'ESP32 Label',
      kind: 'text',
      face: 'top',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: 4,
      marginRight: 4,
      marginTop: null,
      marginBottom: 3,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: 'ESP32',
      fontFamily: 'sans',
      fontSize: 5,
      bold: true,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#e5e7eb',
      textAlign: 'center',
      paddingX: 2,
      paddingY: 1,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 1.2,
      autoSize: true,
      width: 30,
      height: 8,
    } as any,
    {
      id: 'dec_esp32_dot',
      name: 'Status LED surround',
      kind: 'shape',
      face: 'front',
      visible: true,
      depth: 0.6,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: null,
      marginRight: 4,
      marginTop: null,
      marginBottom: 4,
      positionOffsetX: 0,
      positionOffsetY: 0,
      shape: 'circle',
      width: 6,
      height: 6,
      fillColor: '#fbbf24',
      borderColor: '#0f172a',
      borderWidth: 0.3,
      borderRadius: 0,
      opacity: 1.0,
    } as any,
  ];
  return base;
}

function raspberryPiProject(): EnclosureProject {
  const p = applyTemplate(defaultProject(), 'raspberry-pi');
  p.name = 'Raspberry Pi 4 Enclosure';
  return p;
}

function arduinoProject(): EnclosureProject {
  const p = applyTemplate(defaultProject(), 'arduino');
  p.name = 'Arduino Uno Enclosure';
  return p;
}

function sensorProject(): EnclosureProject {
  const p = applyTemplate(defaultProject(), 'sensor');
  p.name = 'Sensor Box';
  // Add a small PCB
  p.pcbs = [
    {
      id: 'pcb_sensor',
      name: 'Sensor PCB',
      width: 30,
      height: 20,
      thickness: 1.6,
      positionZ: 8,
      mountingHoles: [
        { id: 'h1', x: -12, y: -6, diameter: 2.4 },
        { id: 'h2', x: 12, y: -6, diameter: 2.4 },
        { id: 'h3', x: -12, y: 6, diameter: 2.4 },
        { id: 'h4', x: 12, y: 6, diameter: 2.4 },
      ],
      standoffHeight: 4,
      standoffDiameter: 5,
      standoffHoleDiameter: 2.4,
      visible: true,
    },
  ];
  return p;
}

function wallMountProject(): EnclosureProject {
  const p = applyTemplate(defaultProject(), 'wall-mount');
  p.name = 'Wall-Mount Box';
  p.lid = { ...p.lid, type: 'screw' };
  p.screw = { size: 'M3', ...SCREW_PRESETS.M3 };
  return p;
}

function esp32S3EC200UProject(): EnclosureProject {
  const p = applyTemplate(defaultProject(), 'esp32-s3-ec200u');
  p.name = 'ESP32-S3 + A7672SA Cellular Kit';
  p.material = 'PLA';
  // Add a decorative text label on top + a small status LED indicator on front.
  p.decorations = [
    {
      id: 'dec_esp32s3_label',
      name: 'ESP32-S3 Label',
      kind: 'text',
      face: 'top',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: 4,
      marginRight: 4,
      marginTop: 4,
      marginBottom: null,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: 'ESP32-S3',
      fontFamily: 'sans',
      fontSize: 4,
      bold: true,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#e5e7eb',
      textAlign: 'center',
      paddingX: 1.5,
      paddingY: 0.8,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 1.0,
      autoSize: true,
      width: 30,
      height: 7,
    } as any,
    {
      id: 'dec_ec200u_label',
      name: 'A7672SA Label',
      kind: 'text',
      face: 'top',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: 4,
      marginRight: 4,
      marginTop: null,
      marginBottom: 4,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: '4G LTE',
      fontFamily: 'sans',
      fontSize: 3.5,
      bold: true,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#fbbf24',
      textAlign: 'center',
      paddingX: 1.2,
      paddingY: 0.6,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 0.8,
      autoSize: true,
      width: 20,
      height: 6,
    } as any,
  ];
  return p;
}

/**
 * Walkie-talkie styled enclosure for the ESP32-S3 + EC200U Cellular Kit.
 *
 * Cat-1 = LTE Category 1 (10Mbps down / 5Mbps up), which is the EC200U's
 * cellular capability. This sample designs a handheld "Push-to-Talk over
 * Cellular" (PoC) device shaped like a traditional walkie-talkie:
 *   - Tall, narrow body (110mm tall × 70mm wide × 35mm thick)
 *   - PTT (Push-to-Talk) button on the right side (thumb position)
 *   - Speaker grille + OLED display + microphone on the front
 *   - Volume up/down buttons + SIM slot on the left side
 *   - Power button + cellular antenna stub on the top
 *   - USB-C charging port on the bottom
 *   - Decorative "PoC" (amber) + "Cat-1" (green) labels on front
 */
function esp32S3EC200UWalkieTalkieProject(): EnclosureProject {
  const p = defaultProject();
  p.name = 'ESP32-S3 + EC200U Walkie-Talkie (Cat-1)';
  p.shape = 'custom';
  // Walkie-talkie form factor: tall (Z) × medium width (X) × narrow depth (Y).
  // The 66×31mm ESP32-S3-EC200U PCB fits flat with its long side along X.
  p.dimensions = {
    width: 70,         // X — wide enough for the 66mm PCB
    depth: 35,         // Y — narrow (walkie-talkie thickness)
    height: 110,       // Z — tall (walkie-talkie body length)
    wallThickness: 1.6,
    cornerRadius: 6,   // rounded for handheld comfort
    floorThickness: 1.6,
  };
  p.lid = { ...DEFAULT_LID, type: 'snap-fit', visible: true };
  p.snapFit = {
    ...DEFAULT_SNAP_FIT,
    enabled: true,
    count: 2,
    flexDirection: 'y',  // hooks on the long (Y) walls
    armThickness: 1.4,
    hookHeight: 0.8,
  };
  p.screw = { size: 'M2.5', ...SCREW_PRESETS.M2_5 };
  p.material = 'PLA';

  // PCB: ESP32-S3-EC200U (66×31mm), mounted flat with long side along X.
  // Standoffs are 6mm tall to leave room for the battery below.
  p.pcbs = [
    {
      id: 'pcb_wt',
      name: 'ESP32-S3-EC200U',
      width: 66,
      height: 31,
      thickness: 1.6,
      positionZ: 30,  // raised to leave room for a battery below
      mountingHoles: [
        { id: 'h1', x: -27, y: -10, diameter: 2.4 },
        { id: 'h2', x: 27, y: -10, diameter: 2.4 },
        { id: 'h3', x: -27, y: 10, diameter: 2.4 },
        { id: 'h4', x: 27, y: 10, diameter: 2.4 },
      ],
      standoffHeight: 6,
      standoffDiameter: 5,
      standoffHoleDiameter: 2.4,
      visible: true,
    },
  ];

  // Cutouts — walkie-talkie specific.
  // Face coordinate system (from faceBasis in cutouts.ts):
  //   front/back: u=X (width), v=Z (height) → positionX∈[-35,35], positionY∈[-55,55]
  //   left/right: u=Y (depth), v=Z (height) → positionX∈[-17.5,17.5], positionY∈[-55,55]
  //   top/bottom: u=X (width), v=Y (depth) → positionX∈[-35,35], positionY∈[-17.5,17.5]
  p.cutouts = [
    // 1. Speaker grille on front (upper area) — rounded rectangle
    {
      id: 'cutout_speaker',
      name: 'Speaker Grille',
      face: 'front',
      shape: 'rounded-rectangle',
      positionX: 0,
      positionY: 35,    // upper area (near top)
      width: 25,
      height: 8,
      diameter: 0,
      cornerRadius: 2,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 2. OLED display on front (middle area)
    {
      id: 'cutout_oled',
      name: 'OLED Display',
      face: 'front',
      shape: 'rectangle',
      positionX: 0,
      positionY: 15,   // middle
      width: 22,
      height: 12,
      diameter: 0,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 3. Microphone hole on front (lower area) — small circle
    {
      id: 'cutout_mic',
      name: 'Microphone',
      face: 'front',
      shape: 'circle',
      positionX: 0,
      positionY: -40,  // lower area (near bottom)
      width: 0,
      height: 0,
      diameter: 2,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 4. Status LED on front (near speaker, right side)
    {
      id: 'cutout_led',
      name: 'Status LED',
      face: 'front',
      shape: 'circle',
      positionX: 15,
      positionY: 35,
      width: 0,
      height: 0,
      diameter: 3.2,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 5. PTT (Push-to-Talk) button on the right side — large circle (thumb position)
    {
      id: 'cutout_ptt',
      name: 'PTT Button',
      face: 'right',
      shape: 'circle',
      positionX: 0,
      positionY: 20,   // upper-middle (where thumb naturally rests)
      width: 0,
      height: 0,
      diameter: 12,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 6. Volume Up button on the left side
    {
      id: 'cutout_vol_up',
      name: 'Volume Up',
      face: 'left',
      shape: 'circle',
      positionX: 0,
      positionY: 25,
      width: 0,
      height: 0,
      diameter: 4,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 7. Volume Down button on the left side (below Vol Up)
    {
      id: 'cutout_vol_dn',
      name: 'Volume Down',
      face: 'left',
      shape: 'circle',
      positionX: 0,
      positionY: 15,
      width: 0,
      height: 0,
      diameter: 4,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 8. SIM card slot on the left side (lower area)
    {
      id: 'cutout_sim_wt',
      name: 'SIM Card Slot',
      face: 'left',
      shape: 'rectangle',
      positionX: 0,
      positionY: -30,  // lower area
      width: 12,
      height: 11,
      diameter: 0,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 9. Power button on the top (offset to one side)
    {
      id: 'cutout_power',
      name: 'Power Button',
      face: 'top',
      shape: 'circle',
      positionX: 20,    // offset right
      positionY: 0,
      width: 0,
      height: 0,
      diameter: 5,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 10. Cellular antenna stub hole on the top (offset left) — U.FL external antenna
    {
      id: 'cutout_antenna_wt',
      name: 'Cellular Antenna',
      face: 'top',
      shape: 'circle',
      positionX: -20,   // offset left
      positionY: 0,
      width: 0,
      height: 0,
      diameter: 2.2,
      cornerRadius: 0,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
    // 11. USB-C charging port on the bottom
    {
      id: 'cutout_usbc_wt',
      name: 'USB-C Charging',
      face: 'bottom',
      shape: 'rounded-rectangle',
      positionX: 0,
      positionY: 0,
      width: 9,
      height: 3.2,
      diameter: 0,
      cornerRadius: 1.5,
      rotation: 0,
      depth: 1.6,
      points: [],
      visible: true,
    },
  ];

  // Decorations — "PoC" (Push-to-Talk over Cellular) + "Cat-1" labels on front.
  p.decorations = [
    // "PoC" label on front (upper-right, amber background)
    {
      id: 'dec_poc_label',
      name: 'PoC Label',
      kind: 'text',
      face: 'front',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: null,
      marginRight: 5,
      marginTop: 5,
      marginBottom: null,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: 'PoC',
      fontFamily: 'sans',
      fontSize: 4,
      bold: true,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#fbbf24',  // amber
      textAlign: 'center',
      paddingX: 1.5,
      paddingY: 0.8,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 1.0,
      autoSize: true,
      width: 15,
      height: 7,
    } as any,
    // "Cat-1" label on front (upper-left, green background)
    {
      id: 'dec_cat1_label',
      name: 'Cat-1 Label',
      kind: 'text',
      face: 'front',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: 5,
      marginRight: null,
      marginTop: 5,
      marginBottom: null,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: 'Cat-1',
      fontFamily: 'sans',
      fontSize: 3.5,
      bold: true,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#86efac',  // green
      textAlign: 'center',
      paddingX: 1.2,
      paddingY: 0.6,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 0.8,
      autoSize: true,
      width: 18,
      height: 6,
    } as any,
    // "PTT" label on the right side (below the PTT button)
    {
      id: 'dec_ptt_label',
      name: 'PTT Label',
      kind: 'text',
      face: 'right',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: null,
      marginRight: null,
      marginTop: null,
      marginBottom: 10,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: 'PTT',
      fontFamily: 'sans',
      fontSize: 3.5,
      bold: true,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#e5e7eb',
      textAlign: 'center',
      paddingX: 1.2,
      paddingY: 0.6,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 0.8,
      autoSize: true,
      width: 15,
      height: 6,
    } as any,
    // "ESP32-S3 + EC200U" label on the back
    {
      id: 'dec_model_label',
      name: 'Model Label',
      kind: 'text',
      face: 'back',
      visible: true,
      depth: 0.4,
      rotation: 0,
      positionMode: 'margins',
      marginLeft: 5,
      marginRight: 5,
      marginTop: null,
      marginBottom: 5,
      positionOffsetX: 0,
      positionOffsetY: 0,
      text: 'ESP32-S3 + EC200U',
      fontFamily: 'sans',
      fontSize: 3,
      bold: false,
      italic: false,
      textColor: '#0f172a',
      backgroundColor: '#e5e7eb',
      textAlign: 'center',
      paddingX: 1.5,
      paddingY: 0.6,
      borderWidth: 0.3,
      borderColor: '#0f172a',
      borderRadius: 0.5,
      autoSize: true,
      width: 40,
      height: 5,
    } as any,
  ];

  return p;
}

export interface SampleProject {
  id: string;
  name: string;
  description: string;
  project: () => EnclosureProject;
}

export const SAMPLE_PROJECTS: SampleProject[] = [
  {
    id: 'esp32',
    name: 'ESP32 Enclosure',
    description: 'Snap-fit enclosure for ESP32 DevKit with USB-C and buttons.',
    project: esp32Project,
  },
  {
    id: 'raspberry-pi',
    name: 'Raspberry Pi Enclosure',
    description: 'Raspberry Pi 4 enclosure with rear I/O cutouts.',
    project: raspberryPiProject,
  },
  {
    id: 'arduino',
    name: 'Arduino Enclosure',
    description: 'Arduino Uno enclosure with USB-B + DC jack cutouts.',
    project: arduinoProject,
  },
  {
    id: 'sensor',
    name: 'Sensor Box',
    description: 'Small snap-fit sensor box with PCB standoffs.',
    project: sensorProject,
  },
  {
    id: 'wall-mount',
    name: 'Wall Mount Box',
    description: 'Wall-mount enclosure with keyhole slots and screw lid.',
    project: wallMountProject,
  },
  {
    id: 'esp32-s3-ec200u',
    name: 'ESP32-S3 + A7672SA Kit',
    description: 'Cellular dev kit based on ESP-S3-4G-DEV-Kit manual — 2× USB-C, SIM, antenna, LED, button. 32×102×16mm.',
    project: esp32S3EC200UProject,
  },
  {
    id: 'esp32-s3-ec200u-walkie-talkie',
    name: 'ESP32-S3 + EC200U Walkie-Talkie (Cat-1)',
    description: 'Handheld walkie-talkie styled PoC device — PTT button, speaker grille, OLED, volume buttons, antenna stub. LTE Cat-1 cellular.',
    project: esp32S3EC200UWalkieTalkieProject,
  },
];

/** Default initial project for app startup. */
export function defaultSample(): EnclosureProject {
  return SAMPLE_PROJECTS[0].project();
}

void PROJECT_VERSION;
