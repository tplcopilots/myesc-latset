/**
 * Core type definitions for the 3D Enclosure Designer.
 *
 * All dimensions are stored in millimeters (mm) internally.
 * The UI may display other units (cm, inch) but values are converted to mm
 * before being passed to the geometry engine.
 */

// ---------------------------------------------------------------------------
// Units
// ---------------------------------------------------------------------------

export type UnitSystem = 'mm' | 'cm' | 'in';

export const UNIT_CONVERSION_TO_MM: Record<UnitSystem, number> = {
  mm: 1,
  cm: 10,
  in: 25.4,
};

// ---------------------------------------------------------------------------
// Vec2 / Vec3 helpers
// ---------------------------------------------------------------------------

export interface Vec2 {
  x: number;
  y: number;
}

export interface Vec3 {
  x: number;
  y: number;
  z: number;
}

// ---------------------------------------------------------------------------
// Enclosure shape
// ---------------------------------------------------------------------------

export type EnclosureShape =
  | 'rectangular'
  | 'electronics-project'
  | 'raspberry-pi'
  | 'arduino'
  | 'sensor'
  | 'wall-mount'
  | 'handheld'
  | 'junction'
  | 'din-rail'
  | 'waterproof'
  | 'ventilated'
  | 'esp32-s3-ec200u'
  | 'smart-safety-device'
  | 'custom';

export interface EnclosureDimensions {
  /** Outer width (X) in mm */
  width: number;
  /** Outer depth (Y) in mm */
  depth: number;
  /** Outer height (Z) in mm */
  height: number;
  /** Wall thickness in mm */
  wallThickness: number;
  /** Outer corner radius in mm (0 = sharp corners) */
  cornerRadius: number;
  /** Edge bevel/fillet radius in mm — bevels ALL external edges (0 = sharp) */
  edgeBevel: number;
  /** Draft angle in degrees — walls taper inward from bottom to top (0 = vertical) */
  draftAngle: number;
  /** Floor thickness in mm (bottom wall) */
  floorThickness: number;
}

// ---------------------------------------------------------------------------
// Lid system
// ---------------------------------------------------------------------------

export type LidType =
  | 'flat-removable'
  | 'screw'
  | 'hinged'
  | 'snap-fit'
  | 'sliding'
  | 'captive-screw'
  | 'none';

export interface LidParameters {
  type: LidType;
  thickness: number;
  /** Clearance between lid and walls in mm (FDM-friendly default ~0.2) */
  clearance: number;
  /** Screw spacing in mm (for screw lids) */
  screwSpacing: number;
  /** Hinge size in mm (for hinged lids) */
  hingeSize: number;
  /** Snap-fit tolerance in mm */
  snapFitTolerance: number;
  /** Whether lid is shown */
  visible: boolean;
}

// ---------------------------------------------------------------------------
// Screw system
// ---------------------------------------------------------------------------

export type ScrewSize = 'M2' | 'M2.5' | 'M3' | 'M4' | 'M5' | 'custom';

export interface ScrewSpec {
  size: ScrewSize;
  /** Nominal thread diameter in mm */
  threadDiameter: number;
  /** Clearance hole diameter in mm (slightly larger than thread) */
  clearanceHole: number;
  /** Head diameter in mm */
  headDiameter: number;
  /** Head height in mm */
  headHeight: number;
  /** Countersink angle in degrees (typically 90 for flat-head screws) */
  countersinkAngle: number;
}

export const SCREW_PRESETS: Record<Exclude<ScrewSize, 'custom'>, Omit<ScrewSpec, 'size'>> = {
  M2: {
    threadDiameter: 2.0,
    clearanceHole: 2.4,
    headDiameter: 3.8,
    headHeight: 1.2,
    countersinkAngle: 90,
  },
  'M2.5': {
    threadDiameter: 2.5,
    clearanceHole: 2.9,
    headDiameter: 4.5,
    headHeight: 1.5,
    countersinkAngle: 90,
  },
  M3: {
    threadDiameter: 3.0,
    clearanceHole: 3.4,
    headDiameter: 5.5,
    headHeight: 1.8,
    countersinkAngle: 90,
  },
  M4: {
    threadDiameter: 4.0,
    clearanceHole: 4.4,
    headDiameter: 7.0,
    headHeight: 2.3,
    countersinkAngle: 90,
  },
  M5: {
    threadDiameter: 5.0,
    clearanceHole: 5.5,
    headDiameter: 8.5,
    headHeight: 2.7,
    countersinkAngle: 90,
  },
};

// ---------------------------------------------------------------------------
// PCB / standoffs
// ---------------------------------------------------------------------------

export interface PCBMountingHole {
  id: string;
  x: number;
  y: number;
  diameter: number;
}

export interface PCB {
  id: string;
  name: string;
  /** PCB width (X) in mm */
  width: number;
  /** PCB height (Y) in mm */
  height: number;
  /** PCB thickness in mm (typical 1.6) */
  thickness: number;
  /** Position of PCB center inside enclosure (Z is the standoff top) */
  positionZ: number;
  /** Mounting holes (in PCB-local coordinates, origin = PCB center) */
  mountingHoles: PCBMountingHole[];
  /** Standoff height in mm */
  standoffHeight: number;
  /** Standoff diameter in mm */
  standoffDiameter: number;
  /** Standoff hole diameter (screw clearance) */
  standoffHoleDiameter: number;
  visible: boolean;
}

// ---------------------------------------------------------------------------
// Cutouts
// ---------------------------------------------------------------------------

export type CutoutFace = 'front' | 'back' | 'left' | 'right' | 'top' | 'bottom';

export type CutoutShape = 'rectangle' | 'rounded-rectangle' | 'circle' | 'slot' | 'polygon';

export interface CutoutPolygonPoint {
  x: number;
  y: number;
}

export interface Cutout {
  id: string;
  name: string;
  face: CutoutFace;
  shape: CutoutShape;
  /** Center X on face in mm, relative to face center */
  positionX: number;
  /** Center Y on face in mm, relative to face center */
  positionY: number;
  /** Width (rect/slot) in mm */
  width: number;
  /** Height (rect/slot) in mm */
  height: number;
  /** Diameter (circle) in mm */
  diameter: number;
  /** Corner radius (rounded-rect) in mm */
  cornerRadius: number;
  /** Rotation in degrees */
  rotation: number;
  /** Depth of cutout (defaults to wall thickness) */
  depth: number;
  /** Polygon points (for polygon shape) */
  points: CutoutPolygonPoint[];
  /** Optional preset label */
  preset?: string;
  visible: boolean;
}

// ---------------------------------------------------------------------------
// Ventilation
// ---------------------------------------------------------------------------

export type VentilationPattern =
  | 'horizontal-slots'
  | 'vertical-slots'
  | 'circular-holes'
  | 'honeycomb'
  | 'grid'
  | 'none';

export interface VentilationParameters {
  pattern: VentilationPattern;
  face: CutoutFace;
  slotWidth: number;
  slotHeight: number;
  spacing: number;
  rows: number;
  columns: number;
  borderDistance: number;
  /** Honeycomb cell radius (for honeycomb pattern) */
  cellRadius: number;
  visible: boolean;
}

// ---------------------------------------------------------------------------
// Snap-fit / hinges / feet
// ---------------------------------------------------------------------------

export interface SnapFitParameters {
  enabled: boolean;
  armLength: number;
  armThickness: number;
  hookHeight: number;
  clearance: number;
  flexDirection: 'x' | 'y';
  count: number;
}

export interface HingeParameters {
  enabled: boolean;
  size: number;
  count: number;
}

export interface FeetParameters {
  enabled: boolean;
  diameter: number;
  height: number;
  count: number;
}

// ---------------------------------------------------------------------------
// Internal supports / standoffs
// ---------------------------------------------------------------------------

export interface InternalSupportParameters {
  enabled: boolean;
  diameter: number;
  /** Spacing between supports (mm) */
  spacing: number;
}

// ---------------------------------------------------------------------------
// Materials (visual only)
// ---------------------------------------------------------------------------

export type MaterialType = 'PLA' | 'PETG' | 'ABS' | 'ASA' | 'TPU';

export interface MaterialPreset {
  type: MaterialType;
  color: string;
  roughness: number;
  metalness: number;
  opacity: number;
}

export const MATERIAL_PRESETS: Record<MaterialType, MaterialPreset> = {
  PLA: { type: 'PLA', color: '#7dd3fc', roughness: 0.4, metalness: 0.0, opacity: 1.0 },
  PETG: { type: 'PETG', color: '#86efac', roughness: 0.35, metalness: 0.0, opacity: 1.0 },
  ABS: { type: 'ABS', color: '#cbd5e1', roughness: 0.5, metalness: 0.0, opacity: 1.0 },
  ASA: { type: 'ASA', color: '#fbbf24', roughness: 0.45, metalness: 0.0, opacity: 1.0 },
  TPU: { type: 'TPU', color: '#f472b6', roughness: 0.6, metalness: 0.0, opacity: 0.95 },
};

// ---------------------------------------------------------------------------
// Cutout presets
// ---------------------------------------------------------------------------

export interface CutoutPreset {
  id: string;
  name: string;
  shape: CutoutShape;
  width: number;
  height: number;
  diameter: number;
  cornerRadius: number;
}

export const CUTOUT_PRESETS: CutoutPreset[] = [
  { id: 'usb-a',   name: 'USB-A',        shape: 'rectangle',         width: 13.5, height: 6.5, diameter: 0, cornerRadius: 0 },
  { id: 'usb-b',   name: 'USB-B',        shape: 'rectangle',         width: 12.0, height: 11.0, diameter: 0, cornerRadius: 0 },
  { id: 'usb-c',   name: 'USB-C',        shape: 'rounded-rectangle', width: 9.0,  height: 3.2, diameter: 0, cornerRadius: 1.5 },
  { id: 'hdmi',    name: 'HDMI',         shape: 'rounded-rectangle', width: 14.5, height: 5.0, diameter: 0, cornerRadius: 1.5 },
  { id: 'rj45',    name: 'RJ45',         shape: 'rectangle',         width: 16.0, height: 14.0, diameter: 0, cornerRadius: 0 },
  { id: 'dc-jack', name: 'DC Barrel',    shape: 'circle',            width: 0, height: 0, diameter: 8.5, cornerRadius: 0 },
  { id: 'toggle',  name: 'Toggle Switch',shape: 'circle',            width: 0, height: 0, diameter: 6.5, cornerRadius: 0 },
  { id: 'button',  name: 'Push Button',  shape: 'circle',            width: 0, height: 0, diameter: 6.5, cornerRadius: 0 },
  { id: 'oled',    name: 'OLED 0.96"',   shape: 'rectangle',         width: 27.0, height: 27.0, diameter: 0, cornerRadius: 0 },
  { id: 'lcd',     name: 'LCD 16x2',     shape: 'rectangle',         width: 80.0, height: 36.0, diameter: 0, cornerRadius: 0 },
  { id: 'fan-40',  name: 'Fan 40mm',     shape: 'circle',            width: 0, height: 0, diameter: 40.0, cornerRadius: 0 },
  { id: 'fan-30',  name: 'Fan 30mm',     shape: 'circle',            width: 0, height: 0, diameter: 30.0, cornerRadius: 0 },
  { id: 'gland',   name: 'Cable Gland',  shape: 'circle',            width: 0, height: 0, diameter: 10.0, cornerRadius: 0 },
  { id: 'led-5',   name: 'LED 5mm',      shape: 'circle',            width: 0, height: 0, diameter: 5.2, cornerRadius: 0 },
  { id: 'led-3',   name: 'LED 3mm',      shape: 'circle',            width: 0, height: 0, diameter: 3.2, cornerRadius: 0 },
];

// ---------------------------------------------------------------------------
// Label / text
// ---------------------------------------------------------------------------

export interface LabelParameters {
  enabled: boolean;
  text: string;
  /** Font size in mm */
  size: number;
  /** Depth (extrusion) in mm */
  depth: number;
  face: CutoutFace;
  positionX: number;
  positionY: number;
  rotation: number;
}

// ---------------------------------------------------------------------------
// Decorations (text / logo / shape on any face)
// ---------------------------------------------------------------------------
//
// CSS-style positioning model:
//   - marginLeft, marginRight, marginTop, marginBottom define distance from
//     the respective face edge to the decoration edge.
//   - If both L and R are non-null, the decoration is anchored to both sides,
//     effectively setting its width to (faceWidth - L - R). When width is
//     also specified explicitly, L and R are used for centering.
//   - If only L is non-null, the decoration is left-anchored.
//   - If only R is non-null, the decoration is right-anchored.
//   - If both are null, the decoration is horizontally centered on the face.
//   - Same logic vertically for top/bottom.
//   - positionOffsetX / positionOffsetY give an extra manual nudge (in mm)
//     on top of the margin-computed position.
//
// This mirrors CSS box-model positioning so designers familiar with CSS
// can position decorations intuitively.

export type DecorationKind = 'text' | 'logo' | 'shape';

/** Shape kinds for shape decorations. */
export type DecorationShapeKind =
  | 'rectangle'
  | 'rounded-rectangle'
  | 'circle'
  | 'triangle'
  | 'hexagon'
  | 'diamond';

/** Horizontal text alignment. */
export type TextAlign = 'left' | 'center' | 'right';

/** Font family choices (rendered to canvas). */
export type FontFamily = 'sans' | 'serif' | 'mono';

/**
 * Base fields shared by all decoration kinds.
 */
export interface DecorationBase {
  id: string;
  name: string;
  kind: DecorationKind;
  /** Which face the decoration sits on. */
  face: CutoutFace;
  visible: boolean;
  /** Extrusion depth (mm) — how far the decoration stands out from the face. */
  depth: number;
  /** Rotation in degrees (around the face normal). */
  rotation: number;
  /** Position mode. */
  positionMode: 'center' | 'margins';
  /** CSS-style margins in mm. null = "auto" (centered on that axis). */
  marginLeft: number | null;
  marginRight: number | null;
  marginTop: number | null;
  marginBottom: number | null;
  /** Extra manual nudge in mm on top of the margin-computed position. */
  positionOffsetX: number;
  positionOffsetY: number;
}

export interface TextDecoration extends DecorationBase {
  kind: 'text';
  text: string;
  fontFamily: FontFamily;
  fontSize: number;
  bold: boolean;
  italic: boolean;
  textColor: string;
  /** Optional background color — null = transparent. */
  backgroundColor: string | null;
  textAlign: TextAlign;
  /** Padding inside the text box in mm. */
  paddingX: number;
  paddingY: number;
  /** Border (drawn around the text box). 0 = no border. */
  borderWidth: number;
  borderColor: string;
  /** Corner radius for the text box border (mm). */
  borderRadius: number;
  /** Auto-size the box to fit the text (overrides width/height). */
  autoSize: boolean;
  /** Manual width if autoSize=false (mm). */
  width: number;
  /** Manual height if autoSize=false (mm). */
  height: number;
}

export interface LogoDecoration extends DecorationBase {
  kind: 'logo';
  /** Image data URL (PNG/JPG/SVG). */
  imageSrc: string;
  /** Display width in mm. */
  width: number;
  /** Display height in mm. */
  height: number;
  /** Keep aspect ratio (height auto-derived from width & image aspect). */
  keepAspect: boolean;
  /** Opacity 0..1. */
  opacity: number;
  /** Border around logo (mm). 0 = no border. */
  borderWidth: number;
  borderColor: string;
  /** Corner radius (mm). */
  borderRadius: number;
}

export interface ShapeDecoration extends DecorationBase {
  kind: 'shape';
  shape: DecorationShapeKind;
  /** Width in mm. */
  width: number;
  /** Height in mm (diameter for circle). */
  height: number;
  /** Fill color. */
  fillColor: string;
  /** Border (stroke) color. */
  borderColor: string;
  /** Border width in mm. */
  borderWidth: number;
  /** Corner radius (for rectangle/rounded-rectangle) in mm. */
  borderRadius: number;
  /** Opacity 0..1. */
  opacity: number;
}

export type Decoration = TextDecoration | LogoDecoration | ShapeDecoration;

// ---------------------------------------------------------------------------
// Settings
// ---------------------------------------------------------------------------

export interface ApplicationSettings {
  unit: UnitSystem;
  gridSize: number;
  snapSize: number;
  defaultWallThickness: number;
  defaultClearance: number;
  defaultScrew: ScrewSize;
  defaultExportFormat: ExportFormat;
  theme: 'dark' | 'light';
}

// ---------------------------------------------------------------------------
// Export
// ---------------------------------------------------------------------------

export type ExportFormat = 'stl-binary' | 'stl-ascii' | 'obj' | '3mf' | 'ply';

export interface ExportOptions {
  format: ExportFormat;
  /** Export all parts combined into one file vs. separate files */
  multiPart: boolean;
  /** Include lid */
  includeLid: boolean;
  /** Include standoffs */
  includeStandoffs: boolean;
  /** Include feet */
  includeFeet: boolean;
}

// ---------------------------------------------------------------------------
// Enclosure project (root state)
// ---------------------------------------------------------------------------

export interface EnclosureProject {
  /** Format version */
  version: string;
  name: string;
  shape: EnclosureShape;
  dimensions: EnclosureDimensions;
  lid: LidParameters;
  screw: ScrewSpec;
  pcbs: PCB[];
  cutouts: Cutout[];
  ventilation: VentilationParameters;
  snapFit: SnapFitParameters;
  hinge: HingeParameters;
  feet: FeetParameters;
  internalSupport: InternalSupportParameters;
  labels: LabelParameters[];
  /** Decorations: text, logos, and shape designs on any face. */
  decorations: Decoration[];
  material: MaterialType;
  settings: ApplicationSettings;
  /** Print orientation in degrees */
  printOrientation: Vec3;
}

// ---------------------------------------------------------------------------
// Generated geometry output (per part)
// ---------------------------------------------------------------------------

export type PartId = 'bottom' | 'lid' | 'standoffs' | 'mounts' | 'feet' | 'vents';

export interface GeneratedPart {
  id: PartId;
  name: string;
  /** Set of meshes (we keep meshes; final geometry can be extracted) */
  meshes: THREE.Mesh[];
}

// Will be referenced from geometry engine. Import THREE lazily.
import type * as THREE from 'three';

// ---------------------------------------------------------------------------
// Validation
// ---------------------------------------------------------------------------

export type ValidationSeverity = 'ok' | 'warning' | 'error';

export interface ValidationIssue {
  id: string;
  severity: ValidationSeverity;
  category:
    | 'wall-thickness'
    | 'thin-geometry'
    | 'overhang'
    | 'small-hole'
    | 'intersection'
    | 'non-manifold'
    | 'duplicate'
    | 'negative-dimension'
    | 'bridge'
    | 'snap-fit'
    | 'screw-boss'
    | 'misc';
  message: string;
  /** Which part(s) the issue concerns */
  part?: PartId;
  /** Position of the issue in 3D space (for highlighting) */
  position?: Vec3;
}
