/**
 * Simple debounce helper. Returns a function that delays invoking `fn` until
 * `wait` ms have elapsed since the last call. The trailing call receives the
 * latest arguments.
 */
export function debounce<Args extends unknown[]>(
  fn: (...args: Args) => void,
  wait: number
): (...args: Args) => void {
  let timer: ReturnType<typeof setTimeout> | null = null;
  return (...args: Args) => {
    if (timer) clearTimeout(timer);
    timer = setTimeout(() => {
      timer = null;
      fn(...args);
    }, wait);
  };
}
