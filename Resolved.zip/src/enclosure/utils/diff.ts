/**
 * Line-by-line diff utility.
 *
 * Computes the differences between two texts (line by line) using a simple
 * Longest Common Subsequence (LCS) based algorithm. The result is a list
 * of "diff lines" — each line is marked as:
 *   - 'equal'   : line is in both texts (unchanged)
 *   - 'added'   : line is only in the new text
 *   - 'removed' : line is only in the old text
 *
 * The algorithm is O(n*m) in time and space, where n and m are the line
 * counts. For typical project files (a few hundred lines), this is fast
 * enough. For very large files (10k+ lines), a more sophisticated
 * algorithm (like Myers' diff) would be needed.
 */

export type DiffLineType = 'equal' | 'added' | 'removed';

export interface DiffLine {
  type: DiffLineType;
  text: string;
  /** Line number in the old text (1-indexed, 0 if not in old) */
  oldLineNumber: number;
  /** Line number in the new text (1-indexed, 0 if not in new) */
  newLineNumber: number;
}

/**
 * Compute a line-by-line diff between two texts.
 *
 * @param oldText The original/snapshot text.
 * @param newText The current/modified text.
 * @returns Array of DiffLine entries.
 */
export function computeDiff(oldText: string, newText: string): DiffLine[] {
  // Handle empty strings: ''.split('\n') returns [''] (one empty line),
  // but we want 0 lines for an empty text.
  const oldLines = oldText === '' ? [] : oldText.split('\n');
  const newLines = newText === '' ? [] : newText.split('\n');
  const n = oldLines.length;
  const m = newLines.length;

  // Build LCS table. lcs[i][j] = length of LCS of oldLines[i..] and newLines[j..]
  // We use a 2D array of size (n+1) × (m+1).
  // For large inputs, this is memory-heavy. Cap at 5000 lines each side.
  const MAX_LINES = 5000;
  if (n > MAX_LINES || m > MAX_LINES) {
    // Fallback: just show all old as removed + all new as added.
    const result: DiffLine[] = [];
    for (let i = 0; i < n; i++) {
      result.push({ type: 'removed', text: oldLines[i], oldLineNumber: i + 1, newLineNumber: 0 });
    }
    for (let j = 0; j < m; j++) {
      result.push({ type: 'added', text: newLines[j], oldLineNumber: 0, newLineNumber: j + 1 });
    }
    return result;
  }

  const lcs: number[][] = Array.from({ length: n + 1 }, () => new Array(m + 1).fill(0));
  for (let i = n - 1; i >= 0; i--) {
    for (let j = m - 1; j >= 0; j--) {
      if (oldLines[i] === newLines[j]) {
        lcs[i][j] = lcs[i + 1][j + 1] + 1;
      } else {
        lcs[i][j] = Math.max(lcs[i + 1][j], lcs[i][j + 1]);
      }
    }
  }

  // Backtrack to produce the diff.
  const result: DiffLine[] = [];
  let i = 0, j = 0;
  while (i < n && j < m) {
    if (oldLines[i] === newLines[j]) {
      result.push({ type: 'equal', text: oldLines[i], oldLineNumber: i + 1, newLineNumber: j + 1 });
      i++;
      j++;
    } else if (lcs[i + 1][j] >= lcs[i][j + 1]) {
      result.push({ type: 'removed', text: oldLines[i], oldLineNumber: i + 1, newLineNumber: 0 });
      i++;
    } else {
      result.push({ type: 'added', text: newLines[j], oldLineNumber: 0, newLineNumber: j + 1 });
      j++;
    }
  }
  while (i < n) {
    result.push({ type: 'removed', text: oldLines[i], oldLineNumber: i + 1, newLineNumber: 0 });
    i++;
  }
  while (j < m) {
    result.push({ type: 'added', text: newLines[j], oldLineNumber: 0, newLineNumber: j + 1 });
    j++;
  }
  return result;
}

/**
 * Format a diff as an HTML string (for display in a popup window).
 * Removed lines are red, added lines are green, unchanged lines are gray.
 */
export function diffToHtml(diff: DiffLine[]): string {
  const escapeHtml = (s: string) =>
    s.replace(/&/g, '&amp;').replace(/</g, '&lt;').replace(/>/g, '&gt;');
  const lines: string[] = [];
  for (const dl of diff) {
    const cls = dl.type === 'added' ? 'diff-added' : dl.type === 'removed' ? 'diff-removed' : 'diff-equal';
    const prefix = dl.type === 'added' ? '+' : dl.type === 'removed' ? '-' : ' ';
    const oldLn = dl.oldLineNumber > 0 ? String(dl.oldLineNumber).padStart(4, ' ') : '    ';
    const newLn = dl.newLineNumber > 0 ? String(dl.newLineNumber).padStart(4, ' ') : '    ';
    lines.push(
      `<div class="${cls}"><span class="line-num">${oldLn}</span><span class="line-num">${newLn}</span><span class="line-prefix">${prefix}</span><span class="line-text">${escapeHtml(dl.text)}</span></div>`
    );
  }
  return lines.join('');
}

/**
 * Summarize a diff: count of added/removed/unchanged lines.
 */
export function summarizeDiff(diff: DiffLine[]): { added: number; removed: number; unchanged: number } {
  let added = 0, removed = 0, unchanged = 0;
  for (const dl of diff) {
    if (dl.type === 'added') added++;
    else if (dl.type === 'removed') removed++;
    else unchanged++;
  }
  return { added, removed, unchanged };
}
