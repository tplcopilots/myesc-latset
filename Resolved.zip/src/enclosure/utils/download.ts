/**
 * Browser file-download helper — native <a> download (always works).
 * For small files (< 4MB), also saves to /home/z/my-project/download/ via API.
 * For large files, just does the browser download (API would fail with large payloads).
 */

/**
 * Download a Blob as a file in the browser.
 * 1. Triggers native browser download via <a> element (primary, always works).
 * 2. For files < 4MB: also saves to /home/z/my-project/download/ via API.
 * 3. Never throws — the browser download is the primary mechanism.
 */
export function downloadBlob(blob: Blob, filename: string): void {
  // 1. Native browser download — primary, always works.
  try {
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = filename;
    a.style.display = 'none';
    document.body.appendChild(a);
    a.click();
    setTimeout(() => {
      document.body.removeChild(a);
      URL.revokeObjectURL(url);
    }, 200);
  } catch (e) {
    console.error('Browser download failed:', e);
  }

  // 2. Save to /home/z/my-project/download/ via API — only for files < 4MB.
  // Large STL files (5-10MB) would create 7-14MB base64 JSON payloads that
  // exceed practical limits. Skip the API save for those — the browser
  // download already works.
  const MAX_API_SIZE = 4 * 1024 * 1024; // 4MB
  if (blob.size > MAX_API_SIZE) {
    return; // Browser download only for large files
  }

  try {
    const reader = new FileReader();
    reader.onloadend = () => {
      try {
        const result = reader.result as string;
        const base64Part = result.split(',')[1] || '';
        if (!base64Part) return;
        // Fire-and-forget — never blocks, never throws.
        fetch('/api/download', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            filename,
            data: base64Part,
            mime: blob.type || 'application/octet-stream',
          }),
        }).catch(() => {}); // silently ignore
      } catch (e) { /* ignore */ }
    };
    reader.onerror = () => {}; // silently ignore
    reader.readAsDataURL(blob);
  } catch (e) { /* ignore */ }
}

/**
 * Download a text string as a file.
 */
export function downloadText(text: string, filename: string, mime = 'application/json'): void {
  downloadBlob(new Blob([text], { type: mime }), filename);
}
