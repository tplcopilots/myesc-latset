import type { UnitSystem } from '../types';
import { UNIT_CONVERSION_TO_MM } from '../types';

/**
 * Format a length given in millimeters in the requested unit system.
 */
export function formatLength(mm: number, unit: UnitSystem = 'mm', digits = 2): string {
  const factor = UNIT_CONVERSION_TO_MM[unit];
  const value = mm / factor;
  return `${value.toFixed(digits)} ${unit}`;
}

/**
 * Format a volume given in mm³.
 */
export function formatVolume(mm3: number, unit: UnitSystem = 'mm', digits = 2): string {
  const factor = UNIT_CONVERSION_TO_MM[unit];
  // Convert linear dimension factor — volume scales with cube of linear.
  const value = mm3 / (factor * factor * factor);
  return `${value.toFixed(digits)} ${unit}³`;
}

/**
 * Format a triangle count with thousands separators.
 */
export function formatCount(n: number): string {
  return n.toLocaleString();
}
