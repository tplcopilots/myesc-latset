/**
 * Generate a short unique id (good enough for client-side object ids).
 */
export function uid(prefix = 'id'): string {
  return `${prefix}_${Math.random().toString(36).slice(2, 9)}`;
}
