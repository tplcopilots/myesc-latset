/**
 * Mesh validation utilities.
 *
 * Detects problems that would make a slicer (PrusaSlicer, Cura, Bambu
 * Studio) complain about the exported STL/OBJ/3MF/PLY:
 *
 *   - Open edges (edges used by only one triangle) — means the surface
 *     isn't closed. Slicer reports "open edges" / "needs a closed surface".
 *   - Non-manifold edges (edges used by 3+ triangles) — means the surface
 *     self-intersects or has degenerate T-junctions.
 *   - Degenerate triangles (zero-area) — usually from coplanar CSG results.
 *   - Inverted normals (winding-order issues).
 *
 * The validator is conservative: it reports counts and a few example
 * locations. It does NOT modify the mesh. To repair, use the slicer's
 * built-in mesh-repair tools.
 *
 * Algorithm:
 *   For each triangle (a, b, c), we hash both directed edges (a→b, b→c, c→a)
 *   and check the undirected edge count. An edge used by exactly one
 *   triangle = open edge. An edge used by 3+ = non-manifold.
 */
import * as THREE from 'three';

export interface MeshValidationResult {
  /** Number of triangles in the mesh. */
  triangleCount: number;
  /** Number of vertices in the mesh. */
  vertexCount: number;
  /** Edges used by only one triangle (boundary edges). */
  openEdgeCount: number;
  /** Edges used by 3 or more triangles (non-manifold). */
  nonManifoldEdgeCount: number;
  /** Triangles with zero area (degenerate). */
  degenerateTriangleCount: number;
  /** Total unique edges. */
  totalEdgeCount: number;
  /** Sample positions of open edges (max 10) for highlighting. */
  openEdgeSamples: THREE.Vector3[];
  /** Whether the mesh is closed (no open edges). */
  isClosed: boolean;
  /** Whether the mesh is manifold (no edge used by 3+ triangles). */
  isManifold: boolean;
  /** Estimated surface area in mm². */
  surfaceArea: number;
  /** Estimated signed volume in mm³ (only meaningful if closed). */
  volume: number;
}

/**
 * Hash a 3D vertex position into a deterministic string key.
 * Uses 2-decimal precision (10µm resolution) so that vertices occupying
 * the same position (from per-face duplication in Box geometry, or from
 * numerical noise in CSG operations) hash to the same key. 10µm is well
 * below typical 3D-printer resolution (200µm layer height) so it's a
 * good threshold for "same position" in practice.
 */
function vertexKey(v: THREE.Vector3): string {
  const r = (n: number) => Math.round(n * 100) / 100; // 10µm precision
  return `${r(v.x)},${r(v.y)},${r(v.z)}`;
}

/** Hash an undirected edge as "min|max" position string. */
function edgeKey(a: THREE.Vector3, b: THREE.Vector3): string {
  const ka = vertexKey(a);
  const kb = vertexKey(b);
  return ka < kb ? `${ka}|${kb}` : `${kb}|${ka}`;
}

/**
 * Validate a single mesh. Returns counts and sample positions.
 */
export function validateMesh(mesh: THREE.Mesh): MeshValidationResult {
  const geom = mesh.geometry as THREE.BufferGeometry;
  const pos = geom.getAttribute('position');
  const index = geom.getIndex();

  if (!pos) {
    return {
      triangleCount: 0,
      vertexCount: 0,
      openEdgeCount: 0,
      nonManifoldEdgeCount: 0,
      degenerateTriangleCount: 0,
      totalEdgeCount: 0,
      openEdgeSamples: [],
      isClosed: true,
      isManifold: true,
      surfaceArea: 0,
      volume: 0,
    };
  }

  // Apply mesh's world matrix to get world-space vertices.
  const matrix = mesh.matrixWorld;
  const v0 = new THREE.Vector3();
  const v1 = new THREE.Vector3();
  const v2 = new THREE.Vector3();
  const cross = new THREE.Vector3();

  // Iterate triangles, build edge map, accumulate surface area and volume.
  const edgeCount = new Map<string, number>();
  const edgeMidpoint = new Map<string, THREE.Vector3>();
  let surfaceArea = 0;
  let volume = 0;
  let degenerate = 0;
  const triCount = index ? index.count / 3 : pos.count / 3;

  for (let i = 0; i < triCount; i++) {
    let ia: number, ib: number, ic: number;
    if (index) {
      ia = index.getX(i * 3);
      ib = index.getX(i * 3 + 1);
      ic = index.getX(i * 3 + 2);
    } else {
      ia = i * 3;
      ib = i * 3 + 1;
      ic = i * 3 + 2;
    }
    v0.fromBufferAttribute(pos, ia).applyMatrix4(matrix);
    v1.fromBufferAttribute(pos, ib).applyMatrix4(matrix);
    v2.fromBufferAttribute(pos, ic).applyMatrix4(matrix);

    // Triangle area = 0.5 * |(v1 - v0) x (v2 - v0)|
    const e1 = new THREE.Vector3().subVectors(v1, v0);
    const e2 = new THREE.Vector3().subVectors(v2, v0);
    cross.crossVectors(e1, e2);
    const triArea = cross.length() * 0.5;
    surfaceArea += triArea;
    if (triArea < 1e-9) degenerate++;

    // Signed volume contribution: (v0 . (v1 x v2)) / 6
    const c12 = new THREE.Vector3().crossVectors(v1, v2);
    volume += v0.dot(c12) / 6;

    // Three undirected edges (hash by POSITION, not vertex index —
    // Three.js Box geometry duplicates vertices per face, so the same
    // physical edge has different indices on each face).
    for (const [va, vb] of [
      [v0, v1],
      [v1, v2],
      [v2, v0],
    ] as const) {
      const key = edgeKey(va, vb);
      edgeCount.set(key, (edgeCount.get(key) ?? 0) + 1);
      if (!edgeMidpoint.has(key)) {
        const mid = new THREE.Vector3().addVectors(va, vb).multiplyScalar(0.5);
        edgeMidpoint.set(key, mid);
      }
    }
  }

  // Count open / non-manifold edges, collect samples.
  let openEdges = 0;
  let nonManifold = 0;
  const openSamples: THREE.Vector3[] = [];
  for (const [key, count] of edgeCount) {
    if (count === 1) {
      openEdges++;
      if (openSamples.length < 10) {
        const mid = edgeMidpoint.get(key);
        if (mid) openSamples.push(mid.clone());
      }
    } else if (count >= 3) {
      nonManifold++;
    }
  }

  return {
    triangleCount: triCount,
    vertexCount: pos.count,
    openEdgeCount: openEdges,
    nonManifoldEdgeCount: nonManifold,
    degenerateTriangleCount: degenerate,
    totalEdgeCount: edgeCount.size,
    openEdgeSamples: openSamples,
    isClosed: openEdges === 0,
    isManifold: nonManifold === 0,
    surfaceArea,
    volume: Math.abs(volume),
  };
}

export interface AggregateValidationResult {
  /** Per-mesh results. */
  meshes: { name: string; result: MeshValidationResult }[];
  /** Aggregated totals. */
  totalTriangles: number;
  totalOpenEdges: number;
  totalNonManifold: number;
  totalDegenerate: number;
  /** Whether all meshes are closed and manifold. */
  allClosed: boolean;
  allManifold: boolean;
  /** Total surface area (mm²). */
  totalSurfaceArea: number;
  /** Total volume (mm³). */
  totalVolume: number;
  /** Human-readable warnings. */
  warnings: string[];
  /** Sample positions of open edges across all meshes (max 20). */
  openEdgeSamples: THREE.Vector3[];
}

/**
 * Validate an array of meshes (typically the parts of the enclosure).
 */
export function validateMeshes(
  meshes: { name: string; mesh: THREE.Mesh }[]
): AggregateValidationResult {
  const perMesh = meshes.map(m => ({ name: m.name, result: validateMesh(m.mesh) }));
  let totalTriangles = 0;
  let totalOpenEdges = 0;
  let totalNonManifold = 0;
  let totalDegenerate = 0;
  let totalSurfaceArea = 0;
  let totalVolume = 0;
  const warnings: string[] = [];
  const openSamples: THREE.Vector3[] = [];

  for (const { name, result } of perMesh) {
    totalTriangles += result.triangleCount;
    totalOpenEdges += result.openEdgeCount;
    totalNonManifold += result.nonManifoldEdgeCount;
    totalDegenerate += result.degenerateTriangleCount;
    totalSurfaceArea += result.surfaceArea;
    totalVolume += result.volume;

    if (result.openEdgeCount > 0) {
      warnings.push(
        `${name}: ${result.openEdgeCount} open edge(s) — slicer may report "needs a closed surface".`
      );
      for (const s of result.openEdgeSamples) {
        if (openSamples.length < 20) openSamples.push(s);
      }
    }
    if (result.nonManifoldEdgeCount > 0) {
      warnings.push(
        `${name}: ${result.nonManifoldEdgeCount} non-manifold edge(s) — surface self-intersects.`
      );
    }
    if (result.degenerateTriangleCount > 0) {
      warnings.push(
        `${name}: ${result.degenerateTriangleCount} degenerate (zero-area) triangle(s).`
      );
    }
  }
  if (warnings.length === 0) {
    warnings.push('Mesh is closed and manifold — ready for slicing.');
  }

  return {
    meshes: perMesh,
    totalTriangles,
    totalOpenEdges,
    totalNonManifold,
    totalDegenerate,
    allClosed: totalOpenEdges === 0,
    allManifold: totalNonManifold === 0,
    totalSurfaceArea,
    totalVolume,
    warnings,
    openEdgeSamples: openSamples,
  };
}

/**
 * Format a mesh validation result as a human-readable summary.
 */
export function formatValidationResult(r: AggregateValidationResult): string {
  const lines: string[] = [];
  lines.push(`Triangles: ${r.totalTriangles.toLocaleString()}`);
  lines.push(`Open edges: ${r.totalOpenEdges}`);
  lines.push(`Non-manifold edges: ${r.totalNonManifold}`);
  lines.push(`Degenerate triangles: ${r.totalDegenerate}`);
  lines.push(`Surface area: ${(r.totalSurfaceArea / 100).toFixed(2)} cm²`);
  lines.push(`Volume: ${(r.totalVolume / 1000).toFixed(2)} cm³`);
  return lines.join('\n');
}
