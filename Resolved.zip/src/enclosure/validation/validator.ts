/**
 * Printability validator.
 *
 * Produces a list of ValidationIssue objects for the given project. Issues
 * fall into severity levels (ok / warning / error). The UI color-codes them
 * and highlights geometry when clicked.
 *
 * IMPORTANT: The checks here are heuristic. We do not actually analyze the
 * mesh for non-manifold edges or intersections — we only check the project's
 * parameters. We never claim guaranteed printability.
 */
import type {
  EnclosureProject,
  ValidationIssue,
  Cutout,
  PCB,
} from '../types';
import { uid } from '../utils/id';

/**
 * Generate a unique id for a validation issue.
 */
function issueId(prefix: string): string {
  return uid(`v_${prefix}`);
}

/**
 * Validate an enclosure project. Returns a list of issues. Empty list (or
 * only 'ok' severity) means no problems found.
 */
export function validate(project: EnclosureProject): ValidationIssue[] {
  const issues: ValidationIssue[] = [];
  const { dimensions, lid, screw, snapFit, feet } = project;

  // ---- Negative or zero dimensions ----
  const dimFields: (keyof typeof dimensions)[] = ['width', 'depth', 'height', 'wallThickness', 'floorThickness', 'cornerRadius'];
  for (const key of dimFields) {
    const v = dimensions[key];
    if (!isFinite(v) || v <= 0) {
      issues.push({
        id: issueId('negdim'),
        severity: 'error',
        category: 'negative-dimension',
        message: `${key} must be greater than 0 mm (current value: ${v}).`,
        part: 'bottom',
      });
    }
  }

  // Wall thickness too thin (FDM-friendly minimum is 0.8mm per the spec).
  if (dimensions.wallThickness > 0 && dimensions.wallThickness < 0.8) {
    issues.push({
      id: issueId('thinwall'),
      severity: 'warning',
      category: 'wall-thickness',
      message: `Wall thickness ${dimensions.wallThickness.toFixed(2)} mm is below the FDM minimum of 0.8 mm — walls may be fragile.`,
      part: 'bottom',
    });
  }

  // Wall thickness >= min(width,depth,height)/2 → error (enclosure is fully
  // consumed by walls).
  const minDim = Math.min(dimensions.width, dimensions.depth, dimensions.height);
  if (dimensions.wallThickness * 2 >= minDim) {
    issues.push({
      id: issueId('wallhuge'),
      severity: 'error',
      category: 'wall-thickness',
      message: `Wall thickness ${dimensions.wallThickness.toFixed(2)} mm is too large for the smallest dimension ${minDim.toFixed(2)} mm — the interior would be entirely consumed.`,
      part: 'bottom',
    });
  }

  // Corner radius too large.
  const maxCorner = Math.min(dimensions.width, dimensions.depth) / 2 - dimensions.wallThickness;
  if (dimensions.cornerRadius > maxCorner) {
    issues.push({
      id: issueId('cornerlarge'),
      severity: 'error',
      category: 'misc',
      message: `Corner radius ${dimensions.cornerRadius.toFixed(2)} mm is larger than the maximum allowed (${maxCorner.toFixed(2)} mm) given the wall thickness.`,
      part: 'bottom',
    });
  }

  // ---- Cutout placement and size ----
  const faceSizeMap: Record<Cutout['face'], { u: number; v: number }> = {
    front: { u: dimensions.width, v: dimensions.height },
    back: { u: dimensions.width, v: dimensions.height },
    left: { u: dimensions.depth, v: dimensions.height },
    right: { u: dimensions.depth, v: dimensions.height },
    top: { u: dimensions.width, v: dimensions.depth },
    bottom: { u: dimensions.width, v: dimensions.depth },
  };
  for (const cutout of project.cutouts) {
    if (!cutout.visible) continue;
    const { u, v } = faceSizeMap[cutout.face];
    // Compute cutout extents on the face.
    const wHalf =
      cutout.shape === 'circle'
        ? cutout.diameter / 2
        : cutout.width / 2;
    const hHalf =
      cutout.shape === 'circle'
        ? cutout.diameter / 2
        : cutout.height / 2;
    const left = cutout.positionX - wHalf;
    const right = cutout.positionX + wHalf;
    const top = cutout.positionY + hHalf;
    const bottom = cutout.positionY - hHalf;
    if (left < -u / 2 || right > u / 2 || bottom < -v / 2 || top > v / 2) {
      issues.push({
        id: issueId('cutout_oob'),
        severity: 'warning',
        category: 'misc',
        message: `Cutout "${cutout.name}" extends beyond its face bounds (${(u).toFixed(1)}×${(v).toFixed(1)} mm).`,
        part: cutout.face === 'top' ? 'lid' : 'bottom',
      });
    }
    if (cutout.shape === 'circle' && cutout.diameter < 1) {
      issues.push({
        id: issueId('cutout_small'),
        severity: 'warning',
        category: 'small-hole',
        message: `Cutout "${cutout.name}" has diameter ${cutout.diameter.toFixed(2)} mm — holes below 1 mm may not print cleanly on FDM.`,
        part: cutout.face === 'top' ? 'lid' : 'bottom',
      });
    }
  }

  // ---- Snap-fit checks ----
  if (snapFit.enabled) {
    if (snapFit.armThickness < 1.2) {
      issues.push({
        id: issueId('snap_thin'),
        severity: 'warning',
        category: 'snap-fit',
        message: `Snap-fit arm thickness ${snapFit.armThickness.toFixed(2)} mm is below the recommended 1.2 mm minimum for FDM — arms may be too brittle.`,
        part: 'bottom',
      });
    }
    if (snapFit.hookHeight < 0.5) {
      issues.push({
        id: issueId('snap_hook'),
        severity: 'warning',
        category: 'snap-fit',
        message: `Snap-fit hook height ${snapFit.hookHeight.toFixed(2)} mm is too short (< 0.5 mm) — the snap may not engage.`,
        part: 'bottom',
      });
    }
    if (snapFit.armLength > 5) {
      // Long arms are bridges when printed in flat orientation.
      issues.push({
        id: issueId('snap_bridge'),
        severity: 'warning',
        category: 'bridge',
        message: `Snap-fit arm length ${snapFit.armLength.toFixed(2)} mm exceeds 5 mm — long arms may sag during printing.`,
        part: 'bottom',
      });
    }
  }

  // ---- Screw boss checks ----
  if (lid.type === 'screw' || lid.type === 'captive-screw') {
    // Boss diameter must be larger than hole diameter.
    const bossD = Math.max(screw.headDiameter + 2, 6);
    if (screw.clearanceHole >= bossD) {
      issues.push({
        id: issueId('screw_huge_hole'),
        severity: 'error',
        category: 'screw-boss',
        message: `Screw clearance hole ${screw.clearanceHole.toFixed(2)} mm is larger than the boss diameter ${bossD.toFixed(2)} mm — boss walls would be too thin.`,
        part: 'bottom',
      });
    }
  }

  // ---- PCB mounting hole vs standoff diameter ----
  for (const pcb of project.pcbs) {
    if (!pcb.visible) continue;
    for (const hole of pcb.mountingHoles) {
      if (hole.diameter > pcb.standoffDiameter) {
        issues.push({
          id: issueId('pcb_huge_hole'),
          severity: 'error',
          category: 'screw-boss',
          message: `PCB "${pcb.name}" mounting hole (Ø${hole.diameter.toFixed(2)} mm) is larger than the standoff diameter (Ø${pcb.standoffDiameter.toFixed(2)} mm).`,
          part: 'standoffs',
        });
      }
      if (hole.diameter < 1) {
        issues.push({
          id: issueId('pcb_small_hole'),
          severity: 'warning',
          category: 'small-hole',
          message: `PCB "${pcb.name}" mounting hole (Ø${hole.diameter.toFixed(2)} mm) is below 1 mm — may not print cleanly on FDM.`,
          part: 'standoffs',
        });
      }
    }
    // PCB larger than enclosure interior
    const innerW = dimensions.width - 2 * dimensions.wallThickness;
    const innerD = dimensions.depth - 2 * dimensions.wallThickness;
    if (pcb.width > innerW || pcb.height > innerD) {
      issues.push({
        id: issueId('pcb_huge'),
        severity: 'error',
        category: 'misc',
        message: `PCB "${pcb.name}" (${pcb.width}×${pcb.height} mm) is larger than the enclosure interior (${innerW.toFixed(1)}×${innerD.toFixed(1)} mm).`,
        part: 'standoffs',
      });
    }
  }

  // ---- Overhang check on lid (snap-fit lid taller than 5mm = overhang) ----
  if (lid.type === 'snap-fit' && lid.thickness > 5) {
    issues.push({
      id: issueId('lid_overhang'),
      severity: 'warning',
      category: 'overhang',
      message: `Snap-fit lid is ${lid.thickness.toFixed(2)} mm thick with overhang features — may need support material.`,
      part: 'lid',
    });
  }

  // ---- Feet check ----
  if (feet.enabled && feet.diameter < 3) {
    issues.push({
      id: issueId('feet_small'),
      severity: 'warning',
      category: 'small-hole',
      message: `Feet diameter ${feet.diameter.toFixed(2)} mm is small — feet may detach from the build plate.`,
      part: 'feet',
    });
  }

  // If no issues found, emit a single OK entry so the UI can show "All checks
  // passed".
  if (issues.length === 0) {
    issues.push({
      id: issueId('ok'),
      severity: 'ok',
      category: 'misc',
      message: 'No printability issues detected by the heuristic validator. This is NOT a guarantee of printability.',
    });
  }

  return issues;
}
