/**
 * 3MF export tests — verify mesh indices follow the zero-based 3MF format.
 */
import { test, expect } from 'bun:test';
import * as THREE from 'three';
import JSZip from 'jszip';
import { export3MF } from '../../src/enclosure/export/3mf';

test('3MF export contains geometry with valid zero-based indices', async () => {
  const geometry = new THREE.BoxGeometry(10, 20, 30);
  const mesh = new THREE.Mesh(geometry);
  const blob = await export3MF([mesh], 'test enclosure');
  const zip = await JSZip.loadAsync(await blob.arrayBuffer());
  const modelFile = zip.file('3D/3dmodel.model');

  expect(modelFile).not.toBeNull();
  const xml = await modelFile!.async('string');
  const vertexCount = (xml.match(/<vertex\b/g) ?? []).length;
  const triangles = [...xml.matchAll(/<triangle\s+v1="(\d+)"\s+v2="(\d+)"\s+v3="(\d+)"\s*\/>/g)]
    .map(match => match.slice(1).map(Number));

  expect(vertexCount).toBeGreaterThan(0);
  expect(triangles.length).toBeGreaterThan(0);
  expect(triangles[0]).toContain(0);
  expect(triangles.flat()).toEqual(expect.arrayContaining([vertexCount - 1]));
  expect(triangles.flat().every(index => index >= 0 && index < vertexCount)).toBe(true);
});