/**
 * Cutout tests — verify cutout brush placement for each face.
 */
import { test, expect } from 'bun:test';
import { buildCutoutBrush, faceBasis } from '../../src/enclosure/geometry/cutouts';
import { defaultProject } from '../../src/enclosure/templates';
import type { Cutout, CutoutFace, CutoutShape } from '../../src/enclosure/types';

function makeCutout(face: CutoutFace, shape: CutoutShape = 'rectangle'): Cutout {
  return {
    id: 'test',
    name: 'Test',
    face,
    shape,
    positionX: 0,
    positionY: 0,
    width: 5,
    height: 5,
    diameter: 5,
    cornerRadius: 0,
    rotation: 0,
    depth: 2,
    points: [],
    visible: true,
  };
}

test('front-face brush is on the -Y side', () => {
  const project = defaultProject();
  const cutout = makeCutout('front');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.position.y).toBeLessThan(0);
});

test('back-face brush is on the +Y side', () => {
  const project = defaultProject();
  const cutout = makeCutout('back');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.position.y).toBeGreaterThan(0);
});

test('left-face brush is on the -X side', () => {
  const project = defaultProject();
  const cutout = makeCutout('left');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.position.x).toBeLessThan(0);
});

test('right-face brush is on the +X side', () => {
  const project = defaultProject();
  const cutout = makeCutout('right');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.position.x).toBeGreaterThan(0);
});

test('top-face brush is on the +Z side', () => {
  const project = defaultProject();
  const cutout = makeCutout('top');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.position.z).toBeGreaterThanOrEqual(project.dimensions.height - 1);
});

test('bottom-face brush is at z near 0', () => {
  const project = defaultProject();
  const cutout = makeCutout('bottom');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.position.z).toBeLessThanOrEqual(1);
});

test('face basis returns consistent normal magnitudes', () => {
  const dims = { width: 100, depth: 60, height: 30 };
  for (const face of ['front', 'back', 'left', 'right', 'top', 'bottom'] as CutoutFace[]) {
    const { n } = faceBasis(face, dims);
    expect(n.length()).toBeCloseTo(1, 5);
  }
});

test('circle cutout produces a cylinder brush', () => {
  const project = defaultProject();
  const cutout = makeCutout('front', 'circle');
  const brush = buildCutoutBrush(cutout, project);
  expect(brush.geometry.attributes.position.count).toBeGreaterThan(0);
});
