/**
 * Tests for the line-by-line diff algorithm.
 */
import { test, expect } from 'bun:test';
import { computeDiff, summarizeDiff, diffToHtml } from '../../src/enclosure/utils/diff';

test('identical texts produce all-equal diff', () => {
  const text = 'line 1\nline 2\nline 3';
  const diff = computeDiff(text, text);
  expect(diff.length).toBe(3);
  for (const dl of diff) {
    expect(dl.type).toBe('equal');
  }
});

test('added line at the end', () => {
  const old = 'line 1\nline 2';
  const newText = 'line 1\nline 2\nline 3';
  const diff = computeDiff(old, newText);
  const summary = summarizeDiff(diff);
  expect(summary.added).toBe(1);
  expect(summary.removed).toBe(0);
  expect(summary.unchanged).toBe(2);
  const addedLine = diff.find(dl => dl.type === 'added');
  expect(addedLine?.text).toBe('line 3');
});

test('removed line from the middle', () => {
  const old = 'line 1\nline 2\nline 3';
  const newText = 'line 1\nline 3';
  const diff = computeDiff(old, newText);
  const summary = summarizeDiff(diff);
  expect(summary.removed).toBe(1);
  expect(summary.added).toBe(0);
  expect(summary.unchanged).toBe(2);
  const removedLine = diff.find(dl => dl.type === 'removed');
  expect(removedLine?.text).toBe('line 2');
});

test('modified line in the middle', () => {
  const old = 'line 1\nold middle\nline 3';
  const newText = 'line 1\nnew middle\nline 3';
  const diff = computeDiff(old, newText);
  const summary = summarizeDiff(diff);
  expect(summary.removed).toBe(1);
  expect(summary.added).toBe(1);
  expect(summary.unchanged).toBe(2);
  const removed = diff.find(dl => dl.type === 'removed');
  const added = diff.find(dl => dl.type === 'added');
  expect(removed?.text).toBe('old middle');
  expect(added?.text).toBe('new middle');
});

test('empty old text produces all-added diff', () => {
  const diff = computeDiff('', 'a\nb\nc');
  const summary = summarizeDiff(diff);
  expect(summary.added).toBe(3);
  expect(summary.removed).toBe(0);
  expect(summary.unchanged).toBe(0);
});

test('empty new text produces all-removed diff', () => {
  const diff = computeDiff('a\nb\nc', '');
  const summary = summarizeDiff(diff);
  expect(summary.removed).toBe(3);
  expect(summary.added).toBe(0);
});

test('both empty produces empty diff', () => {
  const diff = computeDiff('', '');
  expect(diff.length).toBe(0);
});

test('line numbers are correctly assigned', () => {
  const old = 'a\nb\nc';
  const newText = 'a\nB\nc';
  const diff = computeDiff(old, newText);
  // Line 'a' is equal: old=1, new=1
  expect(diff[0].type).toBe('equal');
  expect(diff[0].oldLineNumber).toBe(1);
  expect(diff[0].newLineNumber).toBe(1);
  // Line 'b' is removed: old=2, new=0
  expect(diff[1].type).toBe('removed');
  expect(diff[1].oldLineNumber).toBe(2);
  expect(diff[1].newLineNumber).toBe(0);
  // Line 'B' is added: old=0, new=2
  expect(diff[2].type).toBe('added');
  expect(diff[2].oldLineNumber).toBe(0);
  expect(diff[2].newLineNumber).toBe(2);
  // Line 'c' is equal: old=3, new=3
  expect(diff[3].type).toBe('equal');
  expect(diff[3].oldLineNumber).toBe(3);
  expect(diff[3].newLineNumber).toBe(3);
});

test('diffToHtml produces valid HTML with diff classes', () => {
  const old = 'a\nb';
  const newText = 'a\nB';
  const diff = computeDiff(old, newText);
  const html = diffToHtml(diff);
  expect(html).toContain('diff-equal');
  expect(html).toContain('diff-removed');
  expect(html).toContain('diff-added');
  expect(html).toContain('line-num');
  expect(html).toContain('line-prefix');
});

test('HTML escaping in diffToHtml', () => {
  const old = '<script>';
  const newText = '<b>bold</b>';
  const diff = computeDiff(old, newText);
  const html = diffToHtml(diff);
  // The raw < and > should be escaped
  expect(html).toContain('&lt;script&gt;');
  expect(html).toContain('&lt;b&gt;');
  expect(html).not.toContain('<script>');
});

test('large inputs fall back to simple diff (no LCS)', () => {
  // Generate 6000 lines (over the 5000-line cap)
  const old = Array.from({ length: 6000 }, (_, i) => `old line ${i}`).join('\n');
  const newText = Array.from({ length: 6000 }, (_, i) => `new line ${i}`).join('\n');
  const diff = computeDiff(old, newText);
  // Should still produce a diff, just not LCS-based
  expect(diff.length).toBeGreaterThan(0);
  const summary = summarizeDiff(diff);
  expect(summary.added + summary.removed).toBeGreaterThan(0);
});
