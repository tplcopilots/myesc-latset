/**
 * Tests for the ESP32-S3 + A7672SA cellular kit template and sample.
 * Based on the ESP-S3-4G-DEV-Kit manual dimensions.
 */
import { test, expect } from 'bun:test';
import { generateEnclosureGeometry } from '../../src/enclosure/geometry';
import { TEMPLATES, defaultProject } from '../../src/enclosure/templates';
import { SAMPLE_PROJECTS } from '../../src/enclosure/templates/samples';
import type { EnclosureProject } from '../../src/enclosure/types';

test('esp32-s3-ec200u template exists and has correct dimensions', () => {
  const overrides = TEMPLATES['esp32-s3-ec200u']();
  expect(overrides.shape).toBe('esp32-s3-ec200u');
  expect(overrides.dimensions?.width).toBe(32);    // fits 25.4mm PCB + walls
  expect(overrides.dimensions?.depth).toBe(102);   // fits 97mm PCB + walls
  expect(overrides.dimensions?.height).toBe(16);
  expect(overrides.dimensions?.wallThickness).toBe(1.6);
  expect(overrides.dimensions?.cornerRadius).toBe(3);
});

test('esp32-s3-ec200u template has a PCB with 4 mounting holes at manual positions', () => {
  const overrides = TEMPLATES['esp32-s3-ec200u']();
  expect(overrides.pcbs).toBeDefined();
  expect(overrides.pcbs!.length).toBe(1);
  const pcb = overrides.pcbs![0];
  expect(pcb.width).toBe(25.4);   // 1 inch — from manual
  expect(pcb.height).toBe(97);    // from manual
  expect(pcb.thickness).toBe(1.6);
  expect(pcb.mountingHoles.length).toBe(4);
  // Mounting holes at (±10.16, ±43.18)mm from manual
  const xs = pcb.mountingHoles.map(h => h.x).sort((a,b) => a - b);
  const ys = pcb.mountingHoles.map(h => h.y).sort((a,b) => a - b);
  expect(xs[0]).toBeCloseTo(-10.16, 1);
  expect(xs[3]).toBeCloseTo(10.16, 1);
  expect(ys[0]).toBeCloseTo(-43.18, 1);
  expect(ys[3]).toBeCloseTo(43.18, 1);
  // Hole diameter = 3mm (M3 screws)
  expect(pcb.mountingHoles[0].diameter).toBe(3.0);
});

test('esp32-s3-ec200u template has cutouts for 2x USB-C, antenna, SIM, button, LED', () => {
  const overrides = TEMPLATES['esp32-s3-ec200u']();
  expect(overrides.cutouts).toBeDefined();
  expect(overrides.cutouts!.length).toBe(6);
  // Verify each cutout exists
  const names = overrides.cutouts!.map(c => c.name);
  expect(names).toContain('USB-C (ESP32)');
  expect(names).toContain('USB-C (4G Modem)');
  expect(names).toContain('Cellular Antenna');
  expect(names).toContain('SIM Card Slot');
  expect(names).toContain('Reset Button');
  expect(names).toContain('Status LED');
  // Verify faces
  const faces = overrides.cutouts!.map(c => c.face);
  expect(faces).toContain('right');    // 2x USB-C
  expect(faces).toContain('back');     // antenna + SIM
  expect(faces).toContain('front');    // button + LED
});

test('esp32-s3-ec200u template has snap-fit lid with X flex direction', () => {
  const overrides = TEMPLATES['esp32-s3-ec200u']();
  expect(overrides.lid?.type).toBe('snap-fit');
  expect(overrides.snapFit?.enabled).toBe(true);
  expect(overrides.snapFit?.count).toBe(2);
  expect(overrides.snapFit?.flexDirection).toBe('x');  // hooks on short walls
});

test('sample project exists in SAMPLE_PROJECTS', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u');
  expect(sample).toBeDefined();
  expect(sample!.name).toBe('ESP32-S3 + A7672SA Kit');
  expect(sample!.description).toContain('manual');
});

test('sample project loads correctly and generates geometry', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u');
  const project = sample!.project();
  expect(project.name).toBe('ESP32-S3 + A7672SA Cellular Kit');
  expect(project.shape).toBe('esp32-s3-ec200u');
  expect(project.dimensions.width).toBe(32);
  expect(project.dimensions.depth).toBe(102);
  expect(project.dimensions.height).toBe(16);
  expect(project.pcbs.length).toBe(1);
  expect(project.cutouts.length).toBe(6);
  expect(project.decorations?.length).toBe(2);

  // Generate geometry — should not throw.
  const result = generateEnclosureGeometry({ project });
  expect(result.parts.length).toBeGreaterThan(0);
  expect(result.triangleCount).toBeGreaterThan(0);
  // Verify bounding box matches the project dimensions
  const bb = result.boundingBox;
  expect(bb.max.x - bb.min.x).toBeCloseTo(32, 0);
  expect(bb.max.y - bb.min.y).toBeCloseTo(102, 0);
  expect(bb.max.z - bb.min.z).toBeGreaterThan(16); // includes lid
});

test('standoffs are generated for each PCB mounting hole', () => {
  const overrides = TEMPLATES['esp32-s3-ec200u']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'esp32-s3-ec200u' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const standoffs = result.parts.find(p => p.id === 'standoffs');
  expect(standoffs).toBeDefined();
  expect(standoffs!.meshes.length).toBe(4); // 4 mounting holes → 4 standoffs
});

test('all 6 cutouts are applied (visible in the bottom mesh)', () => {
  const overrides = TEMPLATES['esp32-s3-ec200u']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'esp32-s3-ec200u' } as EnclosureProject;
  const result1 = generateEnclosureGeometry({ project });
  const project2 = { ...project, cutouts: [] };
  const result2 = generateEnclosureGeometry({ project: project2 });
  // The version with cutouts should have MORE triangles (CSG adds triangles along cutout edges)
  expect(result1.triangleCount).toBeGreaterThan(result2.triangleCount);
});

test('decorations are present on the top face', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u');
  const project = sample!.project();
  expect(project.decorations).toBeDefined();
  expect(project.decorations!.length).toBe(2);
  for (const dec of project.decorations!) {
    expect(dec.kind).toBe('text');
    expect(dec.face).toBe('top');
  }
});
