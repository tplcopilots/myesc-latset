/**
 * Verify that exported STL has minimal open edges after repair.
 * Regression test for the bug where the user's slicer reported
 * "Surface area: NaN cm²" and 8,076 boundary edges.
 */
import { test, expect } from 'bun:test';
import * as THREE from 'three';
import { generateEnclosureGeometry } from '../../src/enclosure/geometry';
import { defaultProject, TEMPLATES } from '../../src/enclosure/templates';
import { exportSTL } from '../../src/enclosure/export/stl';
import { repairMeshes } from '../../src/enclosure/geometry/repair';
import { validateMeshes } from '../../src/enclosure/validation/meshValidation';
import type { EnclosureProject } from '../../src/enclosure/types';

// Avoid TS unused warning.
void THREE;

test('Arduino template: STL export has NO NaN in normals (no more "Surface area: NaN cm²")', async () => {
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  // Repair meshes (same as what the exporter does).
  const repaired = repairMeshes(allMeshes, 0.01);
  // Export as binary STL.
  const blob = exportSTL(repaired, true, 'arduino-test');
  const buf = new Uint8Array(await blob.arrayBuffer());
  const view = new DataView(buf.buffer);
  const triCount = view.getUint32(80, true);
  // Check every normal and vertex for NaN.
  let nanCount = 0;
  let offset = 84;
  for (let i = 0; i < triCount; i++) {
    // 12 floats per triangle (3 normal + 9 vertex = 12 floats × 4 bytes = 48 bytes)
    for (let f = 0; f < 12; f++) {
      const val = view.getFloat32(offset, true);
      if (!isFinite(val)) nanCount++;
      offset += 4;
    }
    offset += 2; // attribute byte count
  }
  expect(nanCount).toBe(0);
});

test('Arduino template: standoffs have 0 open edges (ExtrudeGeometry-based, no CSG)', () => {
  // OLD code used CSG subtraction (outer cylinder - inner hole) which
  // produced 291 open edges per standoff. NEW code uses ExtrudeGeometry
  // with an annulus shape (outer circle + inner hole) which produces a
  // clean closed tube with 0 open edges.
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const standoffs = result.parts.find(p => p.id === 'standoffs');
  expect(standoffs).toBeDefined();
  expect(standoffs!.meshes.length).toBeGreaterThan(0);
  for (const m of standoffs!.meshes) {
    m.updateMatrixWorld(true);
    const v = validateMeshes([{ name: 'standoff', mesh: m }]);
    expect(v.totalOpenEdges).toBe(0);
    expect(v.totalNonManifold).toBe(0);
    expect(v.totalDegenerate).toBe(0);
  }
});

test('Arduino template: lid is closed (0 open edges)', () => {
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const lid = result.parts.find(p => p.id === 'lid');
  expect(lid).toBeDefined();
  for (const m of lid!.meshes) {
    m.updateMatrixWorld(true);
    const v = validateMeshes([{ name: 'lid', mesh: m }]);
    expect(v.totalOpenEdges).toBe(0);
  }
});

test('Bare rectangular enclosure: repaired STL is closed (0 open edges after repair)', () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const repaired = repairMeshes(allMeshes, 0.01);
  const meshes = repaired.map(m => {
    m.updateMatrixWorld(true);
    return { name: 'repaired', mesh: m };
  });
  const v = validateMeshes(meshes);
  expect(v.totalOpenEdges).toBe(0);
  expect(v.totalNonManifold).toBe(0);
  expect(v.totalDegenerate).toBe(0);
});

test('Export with repair: file size matches header triangle count (no garbage tail)', async () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const repaired = repairMeshes(allMeshes, 0.01);
  const blob = exportSTL(repaired, true, 'test');
  const buf = new Uint8Array(await blob.arrayBuffer());
  const view = new DataView(buf.buffer);
  const triCount = view.getUint32(80, true);
  const expectedSize = 84 + triCount * 50;
  expect(blob.size).toBe(expectedSize);
});
