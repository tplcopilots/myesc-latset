/**
 * Geometry tests — verify generateEnclosureGeometry returns a bottom mesh
 * with a reasonable bounding box.
 */
import { test, expect } from 'bun:test';
import { generateEnclosureGeometry, meshVolume } from '../../src/enclosure/geometry';
import { defaultProject } from '../../src/enclosure/templates';
import * as THREE from 'three';

test('generates a bottom part with non-zero bounding box', () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const bottom = result.parts.find(p => p.id === 'bottom');
  expect(bottom).toBeDefined();
  expect(bottom!.meshes.length).toBeGreaterThan(0);
  const mesh = bottom!.meshes[0];
  mesh.geometry.computeBoundingBox();
  const bb = mesh.geometry.boundingBox!;
  expect(bb).toBeDefined();
  // Bounding box should match (or be close to) the outer dimensions.
  expect(bb.max.x - bb.min.x).toBeGreaterThan(0);
  expect(bb.max.y - bb.min.y).toBeGreaterThan(0);
  expect(bb.max.z - bb.min.z).toBeGreaterThan(0);
});

test('hollow enclosure has less material volume than a solid box of same outer dims', () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const bottom = result.parts.find(p => p.id === 'bottom');
  expect(bottom).toBeDefined();
  const mesh = bottom!.meshes[0];
  const vol = meshVolume(mesh);
  const { width, depth, height } = project.dimensions;
  const solidVol = width * depth * height;
  // Material volume should be strictly less than solid volume (it's hollowed).
  expect(vol).toBeGreaterThan(0);
  expect(vol).toBeLessThan(solidVol);
});

test('triangle count is positive', () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  expect(result.triangleCount).toBeGreaterThan(0);
});

test('bounding box volume is non-negative', () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  expect(result.boundingBoxVolume).toBeGreaterThanOrEqual(0);
});

test('does not throw on minimum dimensions', () => {
  const project = {
    ...defaultProject(),
    dimensions: {
      width: 5,
      depth: 5,
      height: 5,
      wallThickness: 1,
      cornerRadius: 0.5,
      floorThickness: 1,
    },
  };
  expect(() => generateEnclosureGeometry({ project })).not.toThrow();
});

test('handles zero corner radius (sharp corners)', () => {
  const project = {
    ...defaultProject(),
    dimensions: { ...defaultProject().dimensions, cornerRadius: 0 },
  };
  const result = generateEnclosureGeometry({ project });
  const bottom = result.parts.find(p => p.id === 'bottom');
  expect(bottom!.meshes.length).toBeGreaterThan(0);
});

void THREE;
