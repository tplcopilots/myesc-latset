/**
 * Verify that the exported mesh is closed (no open edges).
 * Regression test for the bug where shape decorations were placed 2×
 * too far from the wall, causing "open edges" warnings in slicers.
 */
import { test, expect } from 'bun:test';
import * as THREE from 'three';
import { generateEnclosureGeometry } from '../../src/enclosure/geometry';
import { validateMeshes } from '../../src/enclosure/validation/meshValidation';
import { defaultProject } from '../../src/enclosure/templates';
import type { EnclosureProject } from '../../src/enclosure/types';
import { createShapeDecoration, createTextDecoration } from '../../src/enclosure/geometry/decorations';

test('bare enclosure (no decorations) is closed and manifold', () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const meshes: { name: string; mesh: THREE.Mesh }[] = [];
  for (const part of result.parts) {
    for (const m of part.meshes) {
      m.updateMatrixWorld(true);
      meshes.push({ name: part.name, mesh: m });
    }
  }
  const v = validateMeshes(meshes);
  // The basic rectangular enclosure should be a closed solid.
  // (CSG may produce some degenerate triangles; we tolerate those but
  // require no open edges and no non-manifold edges.)
  expect(v.totalOpenEdges).toBe(0);
  expect(v.totalNonManifold).toBe(0);
});

test('enclosure with shape decoration: bottom is closed and shape is a closed separate shell', () => {
  const project: EnclosureProject = {
    ...defaultProject(),
    decorations: [
      createShapeDecoration({
        face: 'front',
        shape: 'circle',
        width: 6,
        height: 6,
        depth: 0.6,
        borderWidth: 0,
      }),
    ],
  };
  const result = generateEnclosureGeometry({ project });
  // Decorations are kept as separate closed-solid shells. Each shell
  // (bottom enclosure + each decoration) must be closed on its own.
  const bottom = result.parts.find(p => p.id === 'bottom');
  expect(bottom).toBeDefined();
  // Validate each mesh separately so we know which one has issues.
  for (const m of bottom!.meshes) {
    m.updateMatrixWorld(true);
    const v = validateMeshes([{ name: 'mesh', mesh: m }]);
    expect(v.totalOpenEdges).toBe(0);
    expect(v.totalNonManifold).toBe(0);
  }
});

test('shape decoration is placed at the wall surface, not 2× too far', () => {
  // Default dimensions: 120×80×40. The enclosure's outer front face is at
  // Y = -depth/2 = -40. The Status LED circle (depth=0.6) should be placed
  // with its outer edge ~0.6mm outside the wall (minus 0.15mm overlap into
  // the wall, so net extension ~0.45mm). Total Y extent should be ~80.45mm.
  // BEFORE the bug fix, it was 80 + 1.2 = 81.2mm.
  const project: EnclosureProject = {
    ...defaultProject(),
    decorations: [
      createShapeDecoration({
        face: 'front',
        shape: 'circle',
        width: 6,
        height: 6,
        depth: 0.6,
      }),
    ],
  };
  const result = generateEnclosureGeometry({ project });
  const bb = result.boundingBox;
  const yExtent = bb.max.y - bb.min.y;
  // Allow tolerance for CSG padding. After the fix, the shape extends
  // ~0.45mm outside the wall (depth - overlap = 0.6 - 0.15).
  // Total yExtent ~80.45.
  expect(yExtent).toBeLessThan(80.7);
  expect(yExtent).toBeGreaterThan(80.3);
});

test('text decoration produces a closed-solid plate (no open edges)', () => {
  const project: EnclosureProject = {
    ...defaultProject(),
    decorations: [
      createTextDecoration({
        text: 'TEST',
        face: 'top',
        fontSize: 5,
        depth: 0.4,
      }),
    ],
  };
  const result = generateEnclosureGeometry({ project });
  // Text decorations are kept as separate closed-solid plates.
  // The bottom part includes the text plate as an additional mesh.
  const bottom = result.parts.find(p => p.id === 'bottom');
  expect(bottom).toBeDefined();
  // Find the text plate mesh (smallest, has multi-material).
  const textMesh = bottom!.meshes.find(m =>
    Array.isArray(m.material) && (m.material as THREE.Material[]).length === 6
  );
  expect(textMesh).toBeDefined();
  textMesh!.updateMatrixWorld(true);
  const v = validateMeshes([{ name: 'text', mesh: textMesh! }]);
  expect(v.totalOpenEdges).toBe(0);
});
