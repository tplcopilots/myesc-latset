/**
 * Verify multi-part export produces origin-centered files.
 * Regression test for the bug where the lid was exported at Z=25mm (above
 * the bottom) instead of at Z=0 (on the build plate).
 */
import { test, expect } from 'bun:test';
import * as THREE from 'three';
import { generateEnclosureGeometry } from '../../src/enclosure/geometry';
import { defaultProject, TEMPLATES } from '../../src/enclosure/templates';
import { exportSTL } from '../../src/enclosure/export/stl';
import { exportMultiPart } from '../../src/enclosure/export';
import type { EnclosureProject, ExportOptions } from '../../src/enclosure/types';

// Helper: parse a binary STL and return the bbox.
async function stlBbox(blob: Blob): Promise<{ min: [number, number, number]; max: [number, number, number] }> {
  const buf = new Uint8Array(await blob.arrayBuffer());
  const view = new DataView(buf.buffer);
  const triCount = view.getUint32(80, true);
  const min: [number, number, number] = [+Infinity, +Infinity, +Infinity];
  const max: [number, number, number] = [-Infinity, -Infinity, -Infinity];
  let offset = 84;
  for (let i = 0; i < triCount; i++) {
    offset += 12; // skip normal
    for (let v = 0; v < 3; v++) {
      const x = view.getFloat32(offset, true); offset += 4;
      const y = view.getFloat32(offset, true); offset += 4;
      const z = view.getFloat32(offset, true); offset += 4;
      if (isFinite(x) && isFinite(y) && isFinite(z)) {
        if (x < min[0]) min[0] = x;
        if (y < min[1]) min[1] = y;
        if (z < min[2]) min[2] = z;
        if (x > max[0]) max[0] = x;
        if (y > max[1]) max[1] = y;
        if (z > max[2]) max[2] = z;
      }
    }
    offset += 2; // attribute
  }
  return { min, max };
}

test('multi-part export: each part is recentered to origin (bbox starts at 0,0,0)', async () => {
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const options: ExportOptions = {
    format: 'stl-binary',
    multiPart: true,
    includeLid: true,
    includeStandoffs: true,
    includeFeet: true,
  };
  const files = await exportMultiPart({ parts: result.parts, project, options });
  // Expect: bottom.stl, lid.stl, standoffs.stl, feet.stl (no feet for Arduino), + zip
  expect(files.length).toBeGreaterThanOrEqual(3);
  for (const file of files) {
    if (file.name.endsWith('.zip')) continue;
    const bbox = await stlBbox(file.blob);
    // Bbox should start at (0, 0, 0) — i.e., min should be approximately 0 in all axes.
    // Use a tolerance because recentering uses the actual mesh bbox, which might
    // have tiny floating-point errors.
    expect(bbox.min[0]).toBeGreaterThan(-0.01);
    expect(bbox.min[1]).toBeGreaterThan(-0.01);
    expect(bbox.min[2]).toBeGreaterThanOrEqual(-0.01); // Z starts at 0 (on the build plate)
  }
});

test('multi-part export: lid bbox Z is from 0 to lid thickness (NOT from bottom height)', async () => {
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const lidThickness = project.lid.thickness;
  const result = generateEnclosureGeometry({ project });
  const options: ExportOptions = {
    format: 'stl-binary',
    multiPart: true,
    includeLid: true,
    includeStandoffs: false,
    includeFeet: false,
  };
  const files = await exportMultiPart({ parts: result.parts, project, options });
  const lidFile = files.find(f => f.name.includes('lid'));
  expect(lidFile).toBeDefined();
  const bbox = await stlBbox(lidFile!.blob);
  // Z should be from ~0 to ~lidThickness (e.g., 0 to 2.5mm), NOT from 25 to 27.5.
  expect(bbox.min[2]).toBeGreaterThan(-0.01);
  expect(bbox.min[2]).toBeLessThan(0.1);
  expect(bbox.max[2]).toBeGreaterThan(0.5);
  expect(bbox.max[2]).toBeLessThan(lidThickness + 1); // ~lidThickness, not 25+
});

test('combined export: lid sits on top of bottom (NOT recentered)', async () => {
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  // Combined export = use exportSTL directly (no recenter).
  const blob = exportSTL(allMeshes, true, 'arduino-test');
  const bbox = await stlBbox(blob);
  // Combined bbox should start at Z=0 (bottom's floor) and extend to Z=27.5 (lid's top).
  // The lid sits at Z=25 to 27.5 (on top of the bottom).
  expect(bbox.min[2]).toBeGreaterThan(-0.01);
  expect(bbox.min[2]).toBeLessThan(0.1);
  // Lid is at Z=25 to 27.5 — combined bbox max Z should be > 25.
  expect(bbox.max[2]).toBeGreaterThan(25);
  expect(bbox.max[2]).toBeLessThan(28);
});

test('multi-part export: produces a ZIP containing all parts', async () => {
  const overrides = TEMPLATES['arduino']();
  const project: EnclosureProject = { ...defaultProject(), ...overrides, shape: 'arduino' } as EnclosureProject;
  const result = generateEnclosureGeometry({ project });
  const options: ExportOptions = {
    format: 'stl-binary',
    multiPart: true,
    includeLid: true,
    includeStandoffs: true,
    includeFeet: false,
  };
  const files = await exportMultiPart({ parts: result.parts, project, options });
  const zipFile = files.find(f => f.name.endsWith('.zip'));
  expect(zipFile).toBeDefined();
  expect(zipFile!.blob.size).toBeGreaterThan(1000); // non-empty ZIP
});
