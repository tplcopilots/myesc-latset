/**
 * PCB / standoff tests — verify standoffs are placed at the PCB hole
 * positions and at the correct height.
 */
import { test, expect } from 'bun:test';
import * as THREE from 'three';
import { generateStandoffs } from '../../src/enclosure/geometry/standoffs';
import { defaultProject } from '../../src/enclosure/templates';
import type { PCB } from '../../src/enclosure/types';

function makePCB(holes: { x: number; y: number; d: number }[]): PCB {
  return {
    id: 'pcb_test',
    name: 'Test PCB',
    width: 50,
    height: 30,
    thickness: 1.6,
    positionZ: 10,
    mountingHoles: holes.map(h => ({
      id: `hole_${Math.random().toString(36).slice(2)}`,
      x: h.x,
      y: h.y,
      diameter: h.d,
    })),
    standoffHeight: 6,
    standoffDiameter: 6,
    standoffHoleDiameter: 2.6,
    visible: true,
  };
}

test('standoffs are generated for each PCB hole', () => {
  const project = { ...defaultProject(), pcbs: [makePCB([
    { x: -10, y: -5, d: 2.6 },
    { x: 10, y: -5, d: 2.6 },
    { x: -10, y: 5, d: 2.6 },
    { x: 10, y: 5, d: 2.6 },
  ])] };
  const result = generateStandoffs(project);
  expect(result.meshes.length).toBe(4);
});

test('standoff position matches hole XY', () => {
  const project = { ...defaultProject(), pcbs: [makePCB([
    { x: -15, y: 7, d: 2.6 },
  ])] };
  const result = generateStandoffs(project);
  expect(result.meshes.length).toBe(1);
  const mesh = result.meshes[0];
  // CSG output geometry is in target-local frame; the result mesh carries the
  // target's world matrix, so applying matrixWorld to the bbox center gives
  // the world-space position.
  mesh.geometry.computeBoundingBox();
  const bb = mesh.geometry.boundingBox!;
  const localCenter = new THREE.Vector3(
    (bb.min.x + bb.max.x) / 2,
    (bb.min.y + bb.max.y) / 2,
    (bb.min.z + bb.max.z) / 2
  );
  const worldCenter = localCenter.applyMatrix4(mesh.matrixWorld);
  expect(worldCenter.x).toBeCloseTo(-15, 0);
  expect(worldCenter.y).toBeCloseTo(7, 0);
});

test('no standoffs generated when no PCBs', () => {
  const project = { ...defaultProject(), pcbs: [] };
  const result = generateStandoffs(project);
  expect(result.meshes.length).toBe(0);
});

test('holes outside the enclosure interior are skipped', () => {
  const project = {
    ...defaultProject(),
    dimensions: { width: 30, depth: 30, height: 30, wallThickness: 2, cornerRadius: 0, floorThickness: 2 },
    pcbs: [makePCB([
      { x: 100, y: 0, d: 2.6 }, // outside the interior
      { x: 0, y: 0, d: 2.6 },   // inside
    ])],
  };
  const result = generateStandoffs(project);
  expect(result.meshes.length).toBe(1);
});
