/**
 * Project file IO tests — serialize and deserialize round-trip.
 */
import { test, expect } from 'bun:test';
import { serializeProject, deserializeProject } from '../../src/enclosure/project/projectFile';
import { defaultProject } from '../../src/enclosure/templates';

test('serialize produces a JSON string', () => {
  const project = defaultProject();
  const json = serializeProject(project);
  expect(typeof json).toBe('string');
  const parsed = JSON.parse(json);
  expect(parsed.dimensions.width).toBe(project.dimensions.width);
});

test('round-trip preserves dimensions', () => {
  const project = defaultProject();
  project.dimensions.width = 200;
  const json = serializeProject(project);
  const loaded = deserializeProject(json);
  expect(loaded.dimensions.width).toBe(200);
});

test('round-trip preserves cutouts', () => {
  const project = defaultProject();
  project.cutouts = [
    {
      id: 'c1',
      name: 'USB',
      face: 'back',
      shape: 'rectangle',
      positionX: 10,
      positionY: 0,
      width: 13.5,
      height: 6.5,
      diameter: 0,
      cornerRadius: 0,
      rotation: 0,
      depth: 2.5,
      points: [],
      visible: true,
    },
  ];
  const json = serializeProject(project);
  const loaded = deserializeProject(json);
  expect(loaded.cutouts.length).toBe(1);
  expect(loaded.cutouts[0].width).toBe(13.5);
});

test('invalid JSON throws', () => {
  expect(() => deserializeProject('not json')).toThrow();
});

test('non-object root throws', () => {
  expect(() => deserializeProject('"string"')).toThrow();
});
