/**
 * Screw boss tests — boss hole diameter < boss diameter.
 */
import { test, expect } from 'bun:test';
import { generateScrewBoss, generateThroughHole } from '../../src/enclosure/geometry/screws';
import { defaultProject } from '../../src/enclosure/templates';
import * as THREE from 'three';

test('screw boss has non-empty geometry', () => {
  const project = defaultProject();
  const boss = generateScrewBoss(project.screw, new THREE.Vector3(0, 0, 0), 10, 8);
  expect(boss.geometry.attributes.position.count).toBeGreaterThan(0);
});

test('screw boss has fewer triangles than a solid cylinder (hole was subtracted)', () => {
  const project = defaultProject();
  const boss = generateScrewBoss(project.screw, new THREE.Vector3(0, 0, 0), 10, 8);
  const bossTriCount = boss.geometry.attributes.position.count / 3;
  // Just a sanity check that subtraction produced extra (or fewer) geometry.
  expect(bossTriCount).toBeGreaterThan(0);
});

test('through hole is a valid cylinder mesh', () => {
  const project = defaultProject();
  const hole = generateThroughHole(project.screw, new THREE.Vector3(0, 0, 0), 5);
  expect(hole.geometry.attributes.position.count).toBeGreaterThan(0);
});

test('boss diameter > clearance hole diameter (per spec invariant)', () => {
  const project = defaultProject();
  const screw = project.screw;
  const bossD = Math.max(screw.headDiameter + 2, 6);
  expect(bossD).toBeGreaterThan(screw.clearanceHole);
});
