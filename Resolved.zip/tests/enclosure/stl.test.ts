/**
 * STL export tests — verify the binary header and ASCII format.
 */
import { test, expect } from 'bun:test';
import { exportSTL } from '../../src/enclosure/export/stl';
import { generateEnclosureGeometry } from '../../src/enclosure/geometry';
import { defaultProject } from '../../src/enclosure/templates';

test('binary STL blob is non-empty', async () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const blob = exportSTL(allMeshes, true, 'test');
  expect(blob.size).toBeGreaterThan(0);
  expect(blob.size).toBeGreaterThanOrEqual(84); // header + tri count
});

test('binary STL starts with header bytes', async () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const blob = exportSTL(allMeshes, true, 'testname');
  const buf = new Uint8Array(await blob.arrayBuffer());
  // The first 80 bytes are the header. We embed "BINARY STL: testname" in it.
  let headerStr = '';
  for (let i = 0; i < 80; i++) {
    if (buf[i] === 0) break;
    headerStr += String.fromCharCode(buf[i]);
  }
  expect(headerStr.startsWith('BINARY STL')).toBe(true);
});

test('binary STL has correct triangle count in header', async () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const blob = exportSTL(allMeshes, true, 'test');
  const buf = new Uint8Array(await blob.arrayBuffer());
  const view = new DataView(buf.buffer);
  const triCount = view.getUint32(80, true);
  // Each triangle contributes 50 bytes after the header.
  const expectedFromSize = (blob.size - 84) / 50;
  expect(triCount).toBe(expectedFromSize);
  expect(triCount).toBe(result.triangleCount);
});

test('ASCII STL starts with "solid"', async () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const blob = exportSTL(allMeshes, false, 'test');
  const text = await blob.text();
  expect(text.startsWith('solid')).toBe(true);
  expect(text.includes('endsolid')).toBe(true);
});

test('ASCII STL contains facet normal lines', async () => {
  const project = defaultProject();
  const result = generateEnclosureGeometry({ project });
  const allMeshes = result.parts.flatMap(p => p.meshes);
  const blob = exportSTL(allMeshes, false, 'test');
  const text = await blob.text();
  expect(text.includes('facet normal')).toBe(true);
  expect(text.includes('vertex')).toBe(true);
});
