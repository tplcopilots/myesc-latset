/**
 * Undo/redo stack tests.
 *
 * Note: the store uses Zustand which requires a React rendering context for
 * some operations. We test by directly invoking actions through getState().
 */
import { test, expect, beforeEach } from 'bun:test';
import { useEnclosureStore } from '../../src/enclosure/store/enclosureStore';
import { defaultProject } from '../../src/enclosure/templates';

// Reset store before each test.
beforeEach(() => {
  useEnclosureStore.setState({
    project: defaultProject(),
    history: [],
    future: [],
    selectedPart: 'bottom',
    selectedCutoutId: null,
    selectedPCBId: null,
    dirty: true,
  });
});

test('initial state has no history and no future', () => {
  const s = useEnclosureStore.getState();
  expect(s.history.length).toBe(0);
  expect(s.future.length).toBe(0);
});

test('mutation pushes to history', () => {
  useEnclosureStore.getState().setDimensions({ width: 200 });
  const s = useEnclosureStore.getState();
  expect(s.history.length).toBe(1);
  expect(s.project.dimensions.width).toBe(200);
});

test('undo restores previous state', () => {
  useEnclosureStore.getState().setDimensions({ width: 200 });
  expect(useEnclosureStore.getState().project.dimensions.width).toBe(200);
  useEnclosureStore.getState().undo();
  expect(useEnclosureStore.getState().project.dimensions.width).toBe(defaultProject().dimensions.width);
});

test('redo restores undone state', () => {
  useEnclosureStore.getState().setDimensions({ width: 200 });
  useEnclosureStore.getState().undo();
  expect(useEnclosureStore.getState().project.dimensions.width).toBe(defaultProject().dimensions.width);
  useEnclosureStore.getState().redo();
  expect(useEnclosureStore.getState().project.dimensions.width).toBe(200);
});

test('history is capped', () => {
  // Set 200 dimensions — history should cap at 100.
  for (let i = 0; i < 200; i++) {
    useEnclosureStore.getState().setDimensions({ width: 50 + i });
  }
  const s = useEnclosureStore.getState();
  expect(s.history.length).toBeLessThanOrEqual(100);
});

test('new action after undo clears future', () => {
  useEnclosureStore.getState().setDimensions({ width: 200 });
  useEnclosureStore.getState().undo();
  // future should have one entry now.
  expect(useEnclosureStore.getState().future.length).toBe(1);
  // Perform another action — future should be cleared.
  useEnclosureStore.getState().setDimensions({ depth: 99 });
  expect(useEnclosureStore.getState().future.length).toBe(0);
});

test('addCutout pushes history and selects the new cutout', () => {
  useEnclosureStore.getState().addCutout({ name: 'Test' });
  const s = useEnclosureStore.getState();
  expect(s.history.length).toBe(1);
  expect(s.project.cutouts.length).toBe(1);
  expect(s.selectedCutoutId).not.toBeNull();
});

test('loadProject replaces project state', () => {
  const newP = defaultProject();
  newP.dimensions.width = 999;
  useEnclosureStore.getState().loadProject(newP);
  expect(useEnclosureStore.getState().project.dimensions.width).toBe(999);
});
