/**
 * Validation tests — parameter checks (negative dims, thin walls, etc.)
 */
import { test, expect } from 'bun:test';
import { validate } from '../../src/enclosure/validation/validator';
import { defaultProject } from '../../src/enclosure/templates';
import type { EnclosureProject } from '../../src/enclosure/types';

function withDimensions(overrides: Partial<EnclosureProject['dimensions']>): EnclosureProject {
  return {
    ...defaultProject(),
    dimensions: { ...defaultProject().dimensions, ...overrides },
  };
}

test('rejects negative width', () => {
  const p = withDimensions({ width: -10 });
  const issues = validate(p);
  const errors = issues.filter(i => i.severity === 'error' && i.category === 'negative-dimension');
  expect(errors.length).toBeGreaterThan(0);
});

test('rejects zero height', () => {
  const p = withDimensions({ height: 0 });
  const issues = validate(p);
  const errors = issues.filter(i => i.severity === 'error' && i.category === 'negative-dimension');
  expect(errors.length).toBeGreaterThan(0);
});

test('warns on thin walls (<0.8mm)', () => {
  const p = withDimensions({ wallThickness: 0.5 });
  const issues = validate(p);
  const warnings = issues.filter(i => i.severity === 'warning' && i.category === 'wall-thickness');
  expect(warnings.length).toBeGreaterThan(0);
});

test('errors on wall thickness >= smallest dim / 2', () => {
  const p = withDimensions({ width: 20, depth: 40, height: 30, wallThickness: 11 });
  const issues = validate(p);
  const errors = issues.filter(i => i.severity === 'error' && i.category === 'wall-thickness');
  expect(errors.length).toBeGreaterThan(0);
});

test('errors on corner radius too large', () => {
  const p = withDimensions({ width: 30, depth: 30, height: 30, wallThickness: 2, cornerRadius: 20 });
  const issues = validate(p);
  const errors = issues.filter(i => i.severity === 'error' && i.category === 'misc');
  expect(errors.length).toBeGreaterThan(0);
});

test('returns OK entry on a valid default project', () => {
  const issues = validate(defaultProject());
  // Either no issues, or at least one 'ok' entry, or zero 'error' entries.
  const errors = issues.filter(i => i.severity === 'error');
  expect(errors.length).toBe(0);
});
