/**
 * Tests for the ESP32-S3 + EC200U Walkie-Talkie (Cat-1) sample.
 */
import { test, expect } from 'bun:test';
import { generateEnclosureGeometry } from '../../src/enclosure/geometry';
import { SAMPLE_PROJECTS } from '../../src/enclosure/templates/samples';

test('walkie-talkie sample exists in SAMPLE_PROJECTS', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  expect(sample).toBeDefined();
  expect(sample!.name).toBe('ESP32-S3 + EC200U Walkie-Talkie (Cat-1)');
  expect(sample!.description).toContain('walkie-talkie');
  expect(sample!.description).toContain('PTT');
});

test('walkie-talkie has tall narrow form factor (70×35×110mm)', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  expect(project.dimensions.width).toBe(70);
  expect(project.dimensions.depth).toBe(35);
  expect(project.dimensions.height).toBe(110); // tall — walkie-talkie body
  expect(project.dimensions.cornerRadius).toBe(6); // rounded for comfort
});

test('walkie-talkie has ESP32-S3-EC200U PCB with 4 mounting holes', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  expect(project.pcbs.length).toBe(1);
  const pcb = project.pcbs[0];
  expect(pcb.name).toBe('ESP32-S3-EC200U');
  expect(pcb.width).toBe(66);
  expect(pcb.height).toBe(31);
  expect(pcb.mountingHoles.length).toBe(4);
});

test('walkie-talkie has all 11 cutouts (speaker, OLED, mic, LED, PTT, vol up/down, SIM, power, antenna, USB-C)', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  expect(project.cutouts.length).toBe(11);

  // Verify each cutout by name
  const names = project.cutouts.map(c => c.name);
  expect(names).toContain('Speaker Grille');
  expect(names).toContain('OLED Display');
  expect(names).toContain('Microphone');
  expect(names).toContain('Status LED');
  expect(names).toContain('PTT Button');
  expect(names).toContain('Volume Up');
  expect(names).toContain('Volume Down');
  expect(names).toContain('SIM Card Slot');
  expect(names).toContain('Power Button');
  expect(names).toContain('Cellular Antenna');
  expect(names).toContain('USB-C Charging');

  // Verify PTT is on the RIGHT side (thumb position for right-handed users)
  const ptt = project.cutouts.find(c => c.name === 'PTT Button');
  expect(ptt!.face).toBe('right');
  expect(ptt!.diameter).toBe(12); // large button
});

test('walkie-talkie has 4 decorative labels (PoC, Cat-1, PTT, model)', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  expect(project.decorations?.length).toBe(4);

  const texts = project.decorations!.map(d => d.text);
  expect(texts).toContain('PoC');
  expect(texts).toContain('Cat-1');
  expect(texts).toContain('PTT');
  expect(texts).toContain('ESP32-S3 + EC200U');
});

test('walkie-talkie sample generates valid geometry', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  const result = generateEnclosureGeometry({ project });
  expect(result.parts.length).toBeGreaterThan(0);
  expect(result.triangleCount).toBeGreaterThan(0);

  // Bounding box should match walkie-talkie dimensions (70×35×110 + decorations)
  const bb = result.boundingBox;
  expect(bb.max.x - bb.min.x).toBeGreaterThan(69);
  expect(bb.max.x - bb.min.x).toBeLessThan(72);
  expect(bb.max.y - bb.min.y).toBeGreaterThan(34);
  expect(bb.max.y - bb.min.y).toBeLessThan(37);
  expect(bb.max.z - bb.min.z).toBeGreaterThan(109);
  expect(bb.max.z - bb.min.z).toBeLessThan(115); // includes lid + decorations
});

test('walkie-talkie has snap-fit lid', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  expect(project.lid.type).toBe('snap-fit');
  expect(project.snapFit.enabled).toBe(true);
  expect(project.snapFit.flexDirection).toBe('y'); // hooks on long walls
});

test('walkie-talkie generates 4 standoffs (one per PCB hole)', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  const result = generateEnclosureGeometry({ project });
  const standoffs = result.parts.find(p => p.id === 'standoffs');
  expect(standoffs).toBeDefined();
  expect(standoffs!.meshes.length).toBe(4);
});

test('walkie-talkie PTT button is positioned at thumb height (upper-middle)', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  const ptt = project.cutouts.find(c => c.name === 'PTT Button');
  expect(ptt).toBeDefined();
  // positionY = 20 means 20mm above center, in the upper half — correct for thumb
  expect(ptt!.positionY).toBeGreaterThan(10);
  expect(ptt!.positionY).toBeLessThan(30);
});

test('walkie-talkie speaker is at the top, microphone at the bottom', () => {
  const sample = SAMPLE_PROJECTS.find(s => s.id === 'esp32-s3-ec200u-walkie-talkie');
  const project = sample!.project();
  const speaker = project.cutouts.find(c => c.name === 'Speaker Grille');
  const mic = project.cutouts.find(c => c.name === 'Microphone');
  expect(speaker).toBeDefined();
  expect(mic).toBeDefined();
  // Speaker should be in the upper half (positive Y), mic in the lower half (negative Y)
  expect(speaker!.positionY).toBeGreaterThan(0);
  expect(mic!.positionY).toBeLessThan(0);
});
